package com.generalnegentropics.archis.universe;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

import java.util.List;
import java.util.Map;
import com.generalnegentropics.archis.Simulation;
import com.generalnegentropics.archis.life.Cell;

/**
 * <p>A condition defines some aspect of the universe relative to cells</p>
 *
 * <p>Typically, conditions will implement one of the subclasses:
 * EnvironmentalCondition, Catastrophe, or RewardFunction.</p>
 *
 * <p>Conditions should contain a public static String called
 * CONDITION_DESCRIPTION that carries a description of the condition.</p>
 *
 * @author Adam Ierymenko
 * @version 2.0
 */

public interface Condition
{
  /**
   * Gets a Map containing available parameters and their descriptions
   *
   * @return Map containing parameter names as keys and descriptions as values (all Strings)
   */
  Map getParameters();

  /**
   * Gets the value of a parameter
   *
   * @param name Name of parameter
   * @return Object An object, usually a String or a Number
   */
  Object getParameter(String name);

  /**
   * Sets a parameter, making conversions if possible (does nothing if name not valid)
   *
   * @param name Name of parameter
   * @param value New value of parameter
   */
  void setParameter(String name,Object value);

  /**
   * Called by the universe whenever a new cell is added/created
   *
   * @param parent Parent cell or null if synthetic or random
   * @param newCell New cell
   * @return Should new cell be allowed to be created? true/false
   */
  boolean newCellNotify(Cell parent,Cell newCell);

  /**
   * Called by the universe whenever a cell dies
   *
   * @param deadCell Cell that died
   * @param reason Reason for death
   */
  void deathNotify(Cell deadCell,String reason);

  /**
   * <p>Called before each cell execution</p>
   *
   * <p>This method may kill the cell, and this will prevent execution
   * but will not prevent preExecutionNotify from being called for other
   * cells.  When doing other things, alive() should be checked in the
   * cell first to save processing time.</p>
   *
   * @param l Cell to create input for
   */
  void preExecutionNotify(Cell l);

  /**
   * Called by universe when added to universe
   *
   * @param universe Universe we exist within
   * @param simulation Simulation currently running
   */
  void init(Universe universe,Simulation simulation);

  /**
   * Called by universe after init() for every existing cell to notify
   * of pre-existing cells.
   *
   * @param cell Cell that currently exists
   */
  void initCellNotify(Cell cell);

  /**
   * Called by universe when removed from universe (always!)
   */
  void destroy();

  /**
   * Called before every tick begins
   *
   * @throws ConditionExpirationException Condition should be removed from chain
   */
  void preTickNotify()
    throws ConditionExpirationException;

  /**
   * Called after every tick ends
   *
   * @throws ConditionExpirationException Condition should be removed from chain
   */
  void postTickNotify()
    throws ConditionExpirationException;

  /**
   * <p>Called in each thread to process batches of cells concurrently post-tick</p>
   *
   * <p>(Called before postTickNotify())</p>
   *
   * <p>The List given as the parameter is not modifiable.  Note that anything
   * done here must be synchronized as the whole point of this method is to
   * enable multithreaded post-tick processing within conditions.  Also note
   * that this will be called for each thread, and so might be called more
   * than once on multi-CPU machines.  Do things that must be done only once
   * in postTickNotify.</p>
   *
   * @param cells List of cells to process
   */
  void postTickProcessCells(List cells);
}
