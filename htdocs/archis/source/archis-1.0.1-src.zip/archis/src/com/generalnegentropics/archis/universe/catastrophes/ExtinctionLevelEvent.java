package com.generalnegentropics.archis.universe.catastrophes;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

import java.util.*;
import com.generalnegentropics.archis.universe.*;
import com.generalnegentropics.archis.life.Cell;
import com.generalnegentropics.archis.utils.*;
import com.generalnegentropics.archis.*;

/**
 * A universal condition that runs for one clock cycle that kills many cells
 *
 * @author Adam Ierymenko
 * @version 2.0
 */

public class ExtinctionLevelEvent implements Catastrophe
{
  /**
   * Description of condition
   */
  public static final String CONDITION_DESCRIPTION = "Kills many cells in a single tick.";

  private static Map parameters;
  static
  {
    parameters = new HashMap();
    parameters.put("deathPercentage","Percentage of cells to kill");
    parameters.put("destroyEnergy","Zero energy of killed cells");
    parameters = Collections.unmodifiableMap(parameters);
  }

  private float deathPercentage;
  private boolean destroyEnergy;
  private Simulation simulation;

  /**
   * Constructs a new extinction level event
   */
  public ExtinctionLevelEvent()
  {
    deathPercentage = 0.75F;
    destroyEnergy = false;
  }

  public Map getParameters()
  {
    return parameters;
  }

  public Object getParameter(String name)
  {
    if ("deathPercentage".equals(name))
      return new Float(deathPercentage);
    else if ("destroyEnergy".equals(name))
      return (destroyEnergy ? Boolean.TRUE : Boolean.FALSE);
    return null;
  }

  public void setParameter(String name,Object value)
  {
    if ("deathPercentage".equals(name))
      deathPercentage = ParameterValueParser.getFloat(value);
    else if ("destroyEnergy".equals(name))
      destroyEnergy = ParameterValueParser.getBoolean(value);
  }

  public void init(Universe universe,Simulation simulation)
  {
    this.simulation = simulation;
  }

  public void destroy()
  {
  }

  public void preTickNotify()
    throws ConditionExpirationException
  {
  }

  public void postTickNotify()
    throws ConditionExpirationException
  {
    throw new ConditionExpirationException();
  }

  public void postTickProcessCells(List cells)
  {
  }

  public void preExecutionNotify(Cell cell)
  {
    if (simulation.randomSource().randomEvent(deathPercentage))
      cell.kill(destroyEnergy,"ExtinctionLevelEvent");
  }

  public void deathNotify(Cell deadCell,String reason)
  {
  }

  public boolean newCellNotify(Cell parent,Cell newCell)
  {
    return true;
  }

  public void initCellNotify(Cell cell)
  {
  }
}
