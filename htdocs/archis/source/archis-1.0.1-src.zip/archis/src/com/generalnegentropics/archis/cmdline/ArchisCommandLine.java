package com.generalnegentropics.archis.cmdline;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

import java.io.*;
import java.util.*;
import java.net.*;
import java.text.NumberFormat;
import java.text.DecimalFormat;
import com.generalnegentropics.archis.*;
import com.generalnegentropics.archis.universe.*;
import com.generalnegentropics.archis.life.*;
import com.generalnegentropics.archis.utils.ParameterValueParser;

/**
 * Simple Archis command line interface
 *
 * @author Adam Ierymenko
 * @version 1.0
 */

public class ArchisCommandLine
{
  private Simulation simulation;
  private Universe universe;
  private NumberFormat decimalFormat,integerFormat;

  /**
   * Constructs a new command line interface
   *
   * @param simulation Simulation to connect to
   */
  public ArchisCommandLine(Simulation simulation)
  {
    this.simulation = simulation;
    this.universe = simulation.universe();
    decimalFormat = DecimalFormat.getNumberInstance();
    decimalFormat.setGroupingUsed(false);
    decimalFormat.setMaximumFractionDigits(8);
    decimalFormat.setMinimumFractionDigits(1);
    decimalFormat.setMaximumIntegerDigits(32);
    decimalFormat.setMinimumIntegerDigits(1);
    integerFormat = NumberFormat.getIntegerInstance();
    integerFormat.setMaximumFractionDigits(0);
    integerFormat.setMinimumFractionDigits(0);
    integerFormat.setGroupingUsed(false);
    integerFormat.setMaximumIntegerDigits(32);
    integerFormat.setMinimumIntegerDigits(1);
  }

  /**
   * Executes a command
   *
   * @param command Command to execute
   * @param responseStream PrintStream to send response(s) to
   * @throws IOException I/O error writing to PrintStream
   */
  public void exec(String command,PrintStream responseStream)
    throws IOException
  {
    // Split command into a string array
    ArrayList commandSplit = new ArrayList(16);
    char[] wordBuf = new char[command.length()];
    int wordPtr = 0;
    boolean escapeState = false;
    boolean quoteState = false;
    for(int i=0;i<wordBuf.length;i++) {
      char c = command.charAt(i);
      if (escapeState) {
        wordBuf[wordPtr++] = c;
        escapeState = false;
      } else if (quoteState) {
        if (c == '\\')
          escapeState = true;
        else if (c == '\"')
          quoteState = false;
        else wordBuf[wordPtr++] = c;
      } else if (c == '\\')
        escapeState = true;
      else if (c == '\"')
        quoteState = true;
      else if (c == ' ') {
        if (wordPtr > 0) {
          commandSplit.add(new String(wordBuf,0,wordPtr));
          wordPtr = 0;
        }
      } else wordBuf[wordPtr++] = c;
    }
    if (wordPtr > 0)
      commandSplit.add(new String(wordBuf,0,wordPtr));

    // Execute command (if there is one)
    if (commandSplit.size() > 0) {
      String cmd = ((String)commandSplit.get(0)).toUpperCase();
      if ("HELP".equals(cmd)) {
        responseStream.print("Archis Command Line Version ");
        responseStream.println(Archis.ARCHIS_VERSION);
        responseStream.println();
        responseStream.println("Available Simulation/Universe Control Commands:");
        responseStream.println("  help - View this help message");
        responseStream.println("  version - Version information");
        responseStream.println("  isrunning - Is simulation running?");
        responseStream.println("  start - Start the simulation");
        responseStream.println("  stop - Stop the simulation");
        responseStream.println("  step - Step forward one tick");
        responseStream.println("  tick - View tick counter");
        responseStream.println("  stats - View statistics and tick counter");
        responseStream.println("  lsconditions - List conditions available");
        responseStream.println("  lsprobes - List probes available");
        responseStream.println("  addcondition <class> - Add a condition (not activate)");
        responseStream.println("  addprobe <class> - Add a probe (not activate)");
        responseStream.println("  activatecondition <condition name> - Activate a condition");
        responseStream.println("  activateprobe <probe name> - Activate a probe");
        responseStream.println("  deactivatecondition <condition name> - Deactivate a condition");
        responseStream.println("  deactivateprobe <probe name> - Deactivate a probe");
        responseStream.println("  connected - Get NetServer connection information");
        responseStream.println("  connect <host> <port> - Connect to a NetServer");
        responseStream.println("  disconnect - Disconnect from any NetServer");
        responseStream.println("  addcell <'genome'/'file'> <genome type> <energy> <genome or file> - Introduce a cell");
        responseStream.println("  set [<parameter>] [<value>] - View/set simulation parameters");
        responseStream.println("  quit - Quit this simulation");
        responseStream.println();
        responseStream.println("Available Commands for Configuring Probes and Conditions:");
        responseStream.println("  cset <condition name> [<parameter>] [<value>] - View/set condition parameter");
        responseStream.println("  pset <probe name> [<parameter>] [<value>] - View/set probe parameter");
        responseStream.println();
      } else if ("VERSION".equals(cmd)) {
        responseStream.println();
        responseStream.println("Archis Cellular Artificial Life Simulator Version "+Archis.ARCHIS_VERSION);
        responseStream.println("(c)2001-2003 Adam Ierymenko, all rights reserved");
        responseStream.println();
        responseStream.println("Archis is distributed under the terms of the GNU General Public License.");
        responseStream.println("To see a copy of this license, check the 'about' dialog in the Archis");
        responseStream.println("graphical user interface.");
        responseStream.println();
        responseStream.println("Visit http://www.generalnegentropics.com/archis for the latest version,");
        responseStream.println("screenshots, documentation, and source code.");
        responseStream.println();
      } else if ("ISRUNNING".equals(cmd)) {
        responseStream.println(simulation.isRunning() ? "Simulation is running." : "Simulation is stopped.");
      } else if ("START".equals(cmd)) {
        if (simulation.isRunning())
          responseStream.println("Simulation is already running.");
        else {
          simulation.start();
          responseStream.println("Simulation started.");
        }
      } else if ("STOP".equals(cmd)) {
        if (simulation.isRunning()) {
          responseStream.print("Waiting for tick to finish... ");
          responseStream.flush();
          simulation.stop(true);
          responseStream.println("Stopped.");
        } else responseStream.println("Simulation is not running.");
      } else if ("STEP".equals(cmd)) {
        if (simulation.isRunning())
          responseStream.println("Simulation is running... stop to single step.");
        else {
          simulation.step();
          responseStream.println(Long.toString(universe.clock()));
        }
      } else if ("TICK".equals(cmd)) {
        responseStream.println(Long.toString(universe.clock()));
      } else if ("STATS".equals(cmd)) {
        SortedMap stats = simulation.getStatistics();
        if (stats.size() > 0) {
          for(Iterator i=stats.entrySet().iterator();i.hasNext();) {
            Map.Entry ent = (Map.Entry)i.next();
            responseStream.print(ent.getKey().toString().substring(4));
            responseStream.print(" : ");
            responseStream.println(ent.getValue().toString());
          }
        } else responseStream.println("No statistics available yet.");
      } else if ("LSCONDITIONS".equals(cmd)) {
        Map rewardFunctions = simulation.getRewardFunctions();
        Map catastrophes = simulation.getCatastrophes();
        Map environmentalConditions = simulation.getEnvironmentalConditions();
        responseStream.println("Environmental Condition                  Active  Description");
        responseStream.println("-----------------------                  ------  -----------");
        for(Iterator i=environmentalConditions.entrySet().iterator();i.hasNext();) {
          Map.Entry ent = (Map.Entry)i.next();
          String cn = simulation.getShortClassName((Class)ent.getKey());
          responseStream.println(padString(cn,40)+" "+(universe.hasCondition((Class)ent.getKey()) ? "1" : "0")+"       "+((ent.getValue() == null) ? "" : ent.getValue().toString()));
        }
        responseStream.println();
        responseStream.println("Reward Function                          Active  Description");
        responseStream.println("-----------------------                  ------  -----------");
        for(Iterator i=rewardFunctions.entrySet().iterator();i.hasNext();) {
          Map.Entry ent = (Map.Entry)i.next();
          String cn = simulation.getShortClassName((Class)ent.getKey());
          responseStream.println(padString(cn,40)+" "+(universe.hasCondition((Class)ent.getKey()) ? "1" : "0")+"       "+((ent.getValue() == null) ? "" : ent.getValue().toString()));
        }
        responseStream.println();
        responseStream.println("Catastrophe                              Active  Description");
        responseStream.println("-----------------------                  ------  -----------");
        for(Iterator i=catastrophes.entrySet().iterator();i.hasNext();) {
          Map.Entry ent = (Map.Entry)i.next();
          String cn = simulation.getShortClassName((Class)ent.getKey());
          responseStream.println(padString(cn,40)+" "+(universe.hasCondition((Class)ent.getKey()) ? "1" : "0")+"       "+((ent.getValue() == null) ? "" : ent.getValue().toString()));
        }
      } else if ("LSPROBES".equals(cmd)) {
        responseStream.println("Probe                                    Active  Description");
        responseStream.println("-----------------------                  ------  -----------");
        for(Iterator i=simulation.getProbes().entrySet().iterator();i.hasNext();) {
          Map.Entry ent = (Map.Entry)i.next();
          String cn = simulation.getShortClassName((Class)ent.getKey());
          responseStream.println(padString(cn,40)+" "+(universe.hasProbe((Class)ent.getKey()) ? "1" : "0")+"       "+((ent.getValue() == null) ? "" : ent.getValue().toString()));
        }
      } else if ("ADDCONDITION".equals(cmd)) {
        responseStream.println("(not implemented yet)");
      } else if ("ADDPROBE".equals(cmd)) {
        responseStream.println("(not implemented yet)");
      } else if ("ACTIVATECONDITION".equals(cmd)) {
        if (commandSplit.size() < 2)
          responseStream.println("Usage: activatecondition <condition name>");
        else {
          Class condition = simulation.getEnvironmentalCondition((String)commandSplit.get(1));
          if (condition != null)
            responseStream.println("Found Environmental Condition: "+condition.getName());
          else {
            condition = simulation.getRewardFunction((String)commandSplit.get(1));
            if (condition != null)
              responseStream.println("Found Reward Function: "+condition.getName());
            else {
              condition = simulation.getCatastrophe((String)commandSplit.get(1));
              if (condition != null)
                responseStream.println("Found Catastrophe: "+condition.getName());
              else responseStream.println("Could not find condition '"+(String)commandSplit.get(1)+"'");
            }
          }
          if (condition != null) {
            try {
              universe.addCondition((Condition)condition.newInstance());
              responseStream.println("Condition added: "+condition.getName());
            } catch (Throwable t) {
              responseStream.println("Error instantiating condition: "+t.toString());
            }
          }
        }
      } else if ("ACTIVATEPROBE".equals(cmd)) {
        if (commandSplit.size() != 2)
          responseStream.println("Usage: activateprobe <probe name>");
        else {
          Class probe = simulation.getProbe((String)commandSplit.get(1));
          if (probe == null)
            responseStream.println("Could not find probe '"+(String)commandSplit.get(1)+"'");
          else {
            responseStream.println("Found Probe: "+probe.getName());
            try {
              universe.addProbe((Probe)probe.newInstance());
              responseStream.println("Probe added: "+probe.getName());
            } catch (Throwable t) {
              responseStream.println("Error instantiating probe: "+t.toString());
            }
          }
        }
      } else if ("DEACTIVATECONDITION".equals(cmd)) {
        if (commandSplit.size() != 2)
          responseStream.println("Usage: activatecondition <condition name>");
        else {
          Class condition = simulation.getEnvironmentalCondition((String)commandSplit.get(1));
          if (condition != null)
            responseStream.println("Found Environmental Condition: "+condition.getName());
          else {
            condition = simulation.getRewardFunction((String)commandSplit.get(1));
            if (condition != null)
              responseStream.println("Found Reward Function: "+condition.getName());
            else {
              condition = simulation.getCatastrophe((String)commandSplit.get(1));
              if (condition != null)
                responseStream.println("Found Catastrophe: "+condition.getName());
              else responseStream.println("Could not find condition '"+(String)commandSplit.get(1)+"'");
            }
          }
          if (condition != null) {
            Set universeConditions = universe.getConditions();
            Condition found = null;
            String cn = condition.getName();
            for(Iterator i=universeConditions.iterator();i.hasNext();) {
              Condition c = (Condition)i.next();
              if (c.getClass().getName().equals(cn)) {
                found = c;
                break;
              }
            }
            if (found == null)
              responseStream.println("That condition was not present in the universe.");
            else {
              universe.removeCondition(found);
              responseStream.println("Condition removed from universe.");
            }
          }
        }
      } else if ("DEACTIVATEPROBE".equals(cmd)) {
        if (commandSplit.size() != 2)
          responseStream.println("Usage: activateprobe <probe name>");
        else {
          Class probe = simulation.getProbe((String)commandSplit.get(1));
          if (probe == null)
            responseStream.println("Could not find probe '"+(String)commandSplit.get(1)+"'");
          else {
            responseStream.println("Found Probe: "+probe.getName());
            Set universeProbes = universe.getProbes();
            Probe found = null;
            String cn = probe.getName();
            for(Iterator i=universeProbes.iterator();i.hasNext();) {
              Probe p = (Probe)i.next();
              if (p.getClass().getName().equals(cn)) {
                found = p;
                break;
              }
            }
            if (found == null)
              responseStream.println("That probe was not present in the universe.");
            else {
              universe.removeProbe(found);
              responseStream.println("Probe removed from universe.");
            }
          }
        }
      } else if ("CONNECTED".equals(cmd)) {
        responseStream.println(simulation.getConnectionInfo());
      } else if ("CONNECT".equals(cmd)) {
        if (simulation.isConnected())
          responseStream.println("Already connected.");
        else {
          if (commandSplit.size() != 3)
            responseStream.println("Usage: connect <host> <port");
          else {
            try {
              simulation.connect(InetAddress.getByName((String)commandSplit.get(1)),Integer.parseInt((String)commandSplit.get(2)));
            } catch (NumberFormatException e) {
              responseStream.println("Port must be a positive integer.");
            } catch (UnknownHostException e) {
              responseStream.println("Unknown host: "+(String)commandSplit.get(1));
            } catch (Throwable t) {
              responseStream.println("Error connecting: "+t.toString());
            }
          }
        }
      } else if ("DISCONNECT".equals(cmd)) {
        if (simulation.isConnected()) {
          responseStream.println("Disconnecting...");
          simulation.disconnect();
        } else responseStream.println("Not connected.");
      } else if ("ADDCELL".equals(cmd)) {
        if (commandSplit.size() != 5)
          responseStream.println("Usage: addcell <'genome'/'file'> <genome type> <energy> <genome or file>");
        else {
          if ("genome".equalsIgnoreCase((String)commandSplit.get(1))) {
            try {
              Genome genome = GenomeFactory.create(Integer.parseInt((String)commandSplit.get(2)),simulation.randomSource(),(String)commandSplit.get(4));
              long id;
              universe.addCell(null,new Cell(universe,(id = simulation.nextCellId()),simulation.getName(),0L,0L,Integer.parseInt((String)commandSplit.get(3)),genome));
              responseStream.println("Cell #"+id+" created (genome size="+genome.size()+").");
            } catch (Throwable t) {
              responseStream.println("Error creating new cell: "+t.toString());
            }
          } else if ("file".equalsIgnoreCase((String)commandSplit.get(1))) {
            try {
              File f = new File((String)commandSplit.get(4));
              FileInputStream in = new FileInputStream(f);
              byte[] buf = new byte[(int)f.length()];
              in.read(buf);
              in.close();
              String gs = new String(buf,0,buf.length);
              Genome genome = GenomeFactory.create(Integer.parseInt((String)commandSplit.get(2)),simulation.randomSource(),gs);
              long id;
              universe.addCell(null,new Cell(universe,(id = simulation.nextCellId()),simulation.getName(),0L,0L,Integer.parseInt((String)commandSplit.get(3)),genome));
              responseStream.println("Cell #"+id+" created (genome size="+genome.size()+").");
            } catch (Throwable t) {
              responseStream.println("Error creating new cell: "+t.toString());
            }
          }
        }
      } else if ("CSET".equals(cmd)) {
        if (commandSplit.size() < 2)
          responseStream.println("Usage: cset <condition name> [<parameter>] [<value>]");
        else {
          Class condition = simulation.getEnvironmentalCondition((String)commandSplit.get(1));
          if (condition == null) {
            condition = simulation.getRewardFunction((String)commandSplit.get(1));
            if (condition == null) {
              condition = simulation.getCatastrophe((String)commandSplit.get(1));
              if (condition == null)
                responseStream.println("Could not find condition '"+(String)commandSplit.get(1)+"'");
            }
          }
          if (condition != null) {
            Set universeConditions = universe.getConditions();
            Condition found = null;
            String cn = condition.getName();
            for(Iterator i=universeConditions.iterator();i.hasNext();) {
              Condition c = (Condition)i.next();
              if (c.getClass().getName().equals(cn)) {
                found = c;
                break;
              }
            }
            if (found == null)
              responseStream.println("That condition was not present in the universe.");
            else {
              if (commandSplit.size() == 2) {
                responseStream.println("Parameter                                                 Value");
                responseStream.println("---------                                                 -----");
                for(Iterator i=found.getParameters().keySet().iterator();i.hasNext();) {
                  String pn = (String)i.next();
                  responseStream.println(padString(pn,58)+objectToString(found.getParameter(pn)));
                }
              } else if (commandSplit.size() == 3) {
                responseStream.println((String)commandSplit.get(2)+": "+objectToString(found.getParameter((String)commandSplit.get(2))));
              } else if (commandSplit.size() == 4) {
                found.setParameter((String)commandSplit.get(2),commandSplit.get(3));
                responseStream.println((String)commandSplit.get(2)+": "+objectToString(found.getParameter((String)commandSplit.get(2))));
              }
            }
          }
        }
      } else if ("PSET".equals(cmd)) {
        responseStream.println("(not implemented yet)");
      } else if ("SET".equals(cmd)) {
        if (commandSplit.size() == 1) {
          responseStream.println("Parameter                                                 Value");
          responseStream.println("---------                                                 -----");
          responseStream.println("allowRemoteCommands                                       "+simulation.getAllowRemoteCommands());
          responseStream.println("stopPoint                                                 "+simulation.getStopPoint());
          responseStream.println("rewardEnergy                                              "+universe.getEnergyReward());
        } else if (commandSplit.size() == 2) {
          if ("allowRemoteCommands".equals((String)commandSplit.get(1))) {
            responseStream.println("allowRemoteCommands: "+simulation.getAllowRemoteCommands());
          } else if ("stopPoint".equals((String)commandSplit.get(1))) {
            responseStream.println("stopPoint: "+simulation.getStopPoint());
          } else if ("rewardEnergy".equals((String)commandSplit.get(1))) {
            responseStream.println("rewardEnergy: "+universe.getEnergyReward());
          } else responseStream.println("Unknown parameter: "+(String)commandSplit.get(1));
        } else if (commandSplit.size() >= 3) {
          if ("allowRemoteCommands".equals((String)commandSplit.get(1))) {
            simulation.setAllowRemoteCommands(ParameterValueParser.getBoolean(commandSplit.get(2)));
            responseStream.println("allowRemoteCommands: "+simulation.getAllowRemoteCommands());
          } else if ("stopPoint".equals((String)commandSplit.get(1))) {
            simulation.setStopPoint(ParameterValueParser.getLong(commandSplit.get(2)));
            responseStream.println("stopPoint: "+simulation.getStopPoint());
          } else if ("rewardEnergy".equals((String)commandSplit.get(1))) {
            universe.setEnergyReward(ParameterValueParser.getLong(commandSplit.get(2)));
            responseStream.println("rewardEnergy: "+universe.getEnergyReward());
          } else responseStream.println("Unknown parameter: "+(String)commandSplit.get(1));
        }
      } else if ("QUIT".equals(cmd)) {
        responseStream.println("Goodbye!");
        simulation.kill();
      } else responseStream.println("Unrecognized command.");
    }
  }

  /**
   * Pads a string to a certain length with spaces
   *
   * @param s String
   * @param length Length to pad to
   * @return Padded string
   */
  private String padString(String s,int length)
  {
    int l = s.length();
    if (l >= length)
      return s;
    char[] r = new char[length];
    int n = 0;
    for(int i=0;i<l;i++)
      r[n++] = s.charAt(i);
    for(;n<length;n++)
      r[n] = ' ';
    return new String(r);
  }

  /**
   * Formats objects based on their type
   *
   * @param o Object
   * @return String
   */
  private String objectToString(Object o)
  {
    if (o == null)
      return "";
    if ((o instanceof Double)||(o instanceof Float))
      return decimalFormat.format(((Number)o).doubleValue());
    if ((o instanceof Integer)||(o instanceof Long))
      return integerFormat.format(((Number)o).longValue());
    return o.toString();
  }
}
