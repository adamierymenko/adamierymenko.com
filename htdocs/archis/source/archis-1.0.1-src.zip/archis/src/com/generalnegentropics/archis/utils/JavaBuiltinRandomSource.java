package com.generalnegentropics.archis.utils;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

import java.util.Random;

/**
 * A RandomSource using java.util.Random
 *
 * @author Adam Ierymenko
 * @version 1.0
 */

public class JavaBuiltinRandomSource implements RandomSource
{
  private Random random;
  private static char[] rclist = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".toCharArray();

  public JavaBuiltinRandomSource(long seed)
  {
    random = new Random(seed);
  }

  public int randomInteger()
  {
    synchronized(random) {
      return random.nextInt();
    }
  }

  public int randomPositiveInteger()
  {
    synchronized(random) {
      int n = random.nextInt();
      return ((n >= 0) ? n : ((n == Integer.MIN_VALUE) ? Integer.MAX_VALUE : Math.abs(n)));
    }
  }

  public long randomLong()
  {
    synchronized(random) {
      return random.nextLong();
    }
  }

  public long randomPositiveLong()
  {
    synchronized(random) {
      long n = random.nextLong();
      return ((n >= 0L) ? n : ((n == Long.MIN_VALUE) ? Long.MAX_VALUE : Math.abs(n)));
    }
  }

  public char randomChar()
  {
    synchronized(random) {
      return (char)random.nextInt();
    }
  }

  public char randomLetterOrNumber()
  {
    return rclist[randomPositiveInteger() % rclist.length];
  }

  public byte randomByte()
  {
    synchronized(random) {
      return (byte)random.nextInt();
    }
  }

  public short randomShort()
  {
    synchronized(random) {
      return (short)random.nextInt();
    }
  }

  public boolean randomBoolean()
  {
    synchronized(random) {
      return random.nextBoolean();
    }
  }

  public boolean randomEvent(float probability)
  {
    synchronized(random) {
      return (random.nextFloat() <= probability);
    }
  }

  public boolean randomEvent(double probability)
  {
    synchronized(random) {
      return (random.nextDouble() <= probability);
    }
  }

  public double randomDouble()
  {
    synchronized(random) {
      return random.nextDouble();
    }
  }

  public float randomFloat()
  {
    synchronized(random) {
      return random.nextFloat();
    }
  }
}
