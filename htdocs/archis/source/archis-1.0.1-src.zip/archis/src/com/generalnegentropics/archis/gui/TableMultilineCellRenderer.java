package com.generalnegentropics.archis.gui;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;
import java.awt.Component;

public class TableMultilineCellRenderer implements TableCellRenderer
{
  private JTextArea ta;
  private EmptyBorder border;

  /**
   * Default constructor
   */
  public TableMultilineCellRenderer()
  {
    ta = new JTextArea();
    ta.setLineWrap(true);
    ta.setWrapStyleWord(true);
    ta.setOpaque(true);
    border = new EmptyBorder(1, 2, 1, 2);
  }

  public synchronized Component getTableCellRendererComponent(JTable table,Object value,boolean isSelected,boolean hasFocus,int row,int column)
  {
    if (isSelected)
      ta.setForeground(table.getSelectionForeground());
    else ta.setForeground(table.getForeground());
    if (isSelected)
      ta.setBackground(table.getSelectionBackground());
    else ta.setBackground(table.getBackground());
    ta.setFont(table.getFont());
    ta.setBorder(border);
    ta.setText((value == null) ? "" : value.toString());
    if (value != null) {
      int sw = ta.getFontMetrics(ta.getFont()).stringWidth(value.toString());
      int w = table.getCellRect(row,column,false).width;
      if (sw > w) {
        sw /= w;
        int rh = table.getRowHeight();
        sw *= rh;
        sw += rh; sw += rh;
        if (table.getRowHeight(row) != sw)
          table.setRowHeight(row,sw);
      }
    }
    ta.setSelectedTextColor(ta.getForeground());
    ta.setSelectionColor(ta.getBackground());

    return ta;
  }
}
