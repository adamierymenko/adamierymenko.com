package com.generalnegentropics.archis.gui.conditions;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import com.generalnegentropics.archis.*;
import com.generalnegentropics.archis.universe.environmentalconditions.*;

public class Landscape2DBulkAddEnergyWindow extends JFrame
{
  private Landscape2D landscape;
  JPanel contentPane;
  GridBagLayout gridBagLayout1 = new GridBagLayout();
  JLabel jLabel1 = new JLabel();
  JTextField energyToAddTextField = new JTextField();
  JLabel jLabel2 = new JLabel();
  JTextField densityTextField = new JTextField();
  JButton okButton = new JButton();
  JButton cancelButton = new JButton();

  public Landscape2DBulkAddEnergyWindow(Simulation simulation,Landscape2D landscape)
  {
    simulation.newFrameNotify(this);
    this.landscape = landscape;
    try {
      jbInit();
    }
    catch (Exception e) {
      e.printStackTrace();
    }

    this.setSize(500,175);
    Dimension ss = this.getToolkit().getScreenSize();
    this.setLocation((ss.width / 2) - (this.getWidth() / 2),(ss.height / 2) - (this.getHeight() / 2));
    this.setIconImage(Archis.ICON);
    this.setTitle("[" + simulation.getName() + "] Bulk Add Energy");
  }
  private void jbInit() throws Exception {
    contentPane = (JPanel)this.getContentPane();
    jLabel1.setHorizontalAlignment(SwingConstants.RIGHT);
    jLabel1.setHorizontalTextPosition(SwingConstants.RIGHT);
    jLabel1.setText("Energy to Add:");
    contentPane.setLayout(gridBagLayout1);
    energyToAddTextField.setText("10000000");
    jLabel2.setHorizontalAlignment(SwingConstants.RIGHT);
    jLabel2.setHorizontalTextPosition(SwingConstants.RIGHT);
    jLabel2.setText("Energy Density (max energy per x,y):");
    densityTextField.setText("100000");
    okButton.setText("Bulk Add Energy");
    okButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        okButton_actionPerformed(e);
      }
    });
    cancelButton.setText("Cancel");
    cancelButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        cancelButton_actionPerformed(e);
      }
    });
    this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    contentPane.add(jLabel1,  new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 5, 5), 0, 0));
    contentPane.add(energyToAddTextField,   new GridBagConstraints(1, 0, 1, 1, 1.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 0, 5, 5), 0, 0));
    contentPane.add(jLabel2,    new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, 5, 5, 5), 0, 0));
    contentPane.add(densityTextField,   new GridBagConstraints(1, 1, 1, 1, 1.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 5, 5), 0, 0));
    contentPane.add(okButton,   new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(10, 5, 5, 5), 0, 0));
    contentPane.add(cancelButton,   new GridBagConstraints(1, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(10, 5, 5, 5), 0, 0));
  }

  void okButton_actionPerformed(ActionEvent e) {
    String _energy = energyToAddTextField.getText().trim();
    String _density = densityTextField.getText().trim();
    if ((_energy.length() > 0)&&(_density.length() > 0)) {
      try {
        long energy = Long.parseLong(_energy);
        int density = Integer.parseInt(_density);
        if ((energy < 0L)||(density < 0))
          JOptionPane.showMessageDialog(this,"Energy to add and density must be positive integers","Illegal Entry",JOptionPane.ERROR_MESSAGE);
        landscape.bulkAddEnergy(energy,density);
        this.setVisible(false);
        this.dispose();
      } catch (NumberFormatException ex) {
        JOptionPane.showMessageDialog(this,"Energy to add and density must be positive integers","Illegal Entry",JOptionPane.ERROR_MESSAGE);
      }
    } else JOptionPane.showMessageDialog(this,"Energy to add and density must be positive integers","Illegal Entry",JOptionPane.ERROR_MESSAGE);
  }

  void cancelButton_actionPerformed(ActionEvent e) {
    this.setVisible(false);
    this.dispose();
  }
}
