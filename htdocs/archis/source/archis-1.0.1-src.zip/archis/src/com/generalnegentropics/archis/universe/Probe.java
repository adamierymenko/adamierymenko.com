package com.generalnegentropics.archis.universe;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

import com.generalnegentropics.archis.*;
import com.generalnegentropics.archis.life.Cell;

/**
 * A class enabling cells to be examined every tick
 *
 * @author Adam Ierymenko
 * @version 1.0
 */

public interface Probe
{
  /**
   * Shows Swing or AWT graphical user interface if any
   */
  void showGUI();

  /**
   * Called by universe when probe is added
   *
   * @param universe Universe probe belongs to
   * @param simulation Simulation Simulation probe belongs to
   */
  void init(Universe universe,Simulation simulation);

  /**
   * Called by universe when probe is removed
   */
  void destroy();

  /**
   * Called before each tick
   */
  void preTickNotify();

  /**
   * Called after each tick
   */
  void postTickNotify();

  /**
   * <p>Called each tick for each cell so stats can be detected</p>
   *
   * <p>Note that this can be called by multiple threads concurrently and
   * so anything it does should be properly synchronized.</p>
   *
   * @param cell Cell to scan
   */
  void probeScanCell(Cell cell);

  /**
   * Called when a new cell is created
   *
   * @param parent Parent or null if none
   * @param newCell New cell
   */
  void probeNewCell(Cell parent,Cell newCell);
}
