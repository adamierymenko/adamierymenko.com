package com.generalnegentropics.archis.life.vms;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

import java.util.*;
import java.io.*;
import java.lang.ref.*;
import java.text.NumberFormat;
import java.text.DecimalFormat;
import com.generalnegentropics.archis.utils.*;
import com.generalnegentropics.archis.universe.*;
import com.generalnegentropics.archis.*;
import com.generalnegentropics.archis.life.*;

/**
 * <p>Register machine genome implementation</p>
 *
 * <p>
 * The genome is made up of a series of 6-bit codons that are executed against
 * a memory array contained within the state information of a cell.
 * </p>
 *
 * <p>
 * This virtual machine is a simple register machine with a memory pointer and
 * a single 'accumulator' register. The instructions that are coded for by
 * codons in the genome are in the table below.  Note that the result of
 * <i>add, mul, div, and, or, </i>and<i> xor</i> are stored back into the
 * accumulator.  The <i>go</i> instruction doubles as a start codon.  Note
 * that as the first instruction with the accumulator as zero this has no
 * effect.  Gaps between stop and start codons can constitute noncoding
 * regions between "genes."  Genes could regulate each other by modifying
 * memory, could be regulated by data read from a channel, or could be always
 * on.
 * </p>
 *
 * <p>
 * There is a limit to how many instructions will be executed in a single tick,
 * and any exceeding of this limit will cause a DeathException to be thrown.
 * This also occurs if the loop/rep tracking stack is overflowed, which
 * indicates a certain kind of nested infinite loop.  The per-tick limit is
 * (genomeSize^2 * (loops+1)) where genomeSize is the size of the genome in
 * codons and loops is the number of LOOP instructions in the genome.
 * </p>
 *
 * <p>
 * <table border=0 cellpadding=4 cellspacing=0>
 * <tr><td><b>Instruction</b></td><td><b>Shorthand</b></td><td><b>Effect</b></td></tr>
 * <tr><td>fwd</td><td>f</td><td>Move memory pointer forward</td></tr>
 * <tr><td>back</td><td>b</td><td>Move memory pointer backward</td></tr>
 * <tr><td>go</td><td>g</td><td>Move memory pointer to location stored in accumulator (wraps if out of bounds)</td></tr>
 * <tr><td>add</td><td>+</td><td>Add memory value at pointer to accumulator</td></tr>
 * <tr><td>mul</td><td>*</td><td>Multiply memory value at pointer with accumulator</td></tr>
 * <tr><td>div</td><td>/</td><td>Divide memory value at pointer with accumulator</td></tr>
 * <tr><td>and</td><td>&amp;</td><td>AND memory value at pointer with accumulator</td></tr>
 * <tr><td>or</td><td>|</td><td>OR memory value at pointer with accumulator</td></tr>
 * <tr><td>xor</td><td>^</td><td>XOR memory value at pointer with accumulator</td></tr>
 * <tr><td>shl</td><td>[</td><td>Bitwise left shift accumulator</td></tr>
 * <tr><td>shr</td><td>]</td><td>Bitwise right shift accumulator</td></tr>
 * <tr><td>inc</td><td>&gt;</td><td>Increment accumulator</td></tr>
 * <tr><td>dec</td><td>&lt;</td><td>Decrement accumulator</td></tr>
 * <tr><td>sta</td><td>#</td><td>Store accumulator to memory at current pointer location and zero accumulator</td></tr>
 * <tr><td>cmp</td><td>?</td><td>Set accumulator to -1, 0, or 1 depending on whether memory at pointer is less than, equal to, or greater than accumulator</td></tr>
 * <tr><td>loop</td><td>{</td><td>Jump to matching <i>rep</i> if accumulator is zero</td></tr>
 * <tr><td>rep</td><td>}</td><td>Jump back to mactching <i>loop</i> if accumulator is nonzero</td></tr>
 * <tr><td>read</td><td>r</td><td>Read from current channel to accumulator</td></tr>
 * <tr><td>write</td><td>w</td><td>Write accumulator to current channel</td></tr>
 * <tr><td>sch</td><td>s</td><td>Set current channel to accumulator (wraps if out of bounds)</td></tr>
 * <tr><td>stop</td><td>!</td><td>Stops execution until start codon is reached; zero accumulator, memory pointer, and channel</td></tr>
 * </table>
 * </p>
 *
 * @author Adam Ierymenko
 * @version 3.0
 */

public class RegisterMachineGenome implements Genome
{
  //
  // Human-readable codes for codons
  //
  public static final char CODON_FWD = 'f';
  public static final char CODON_BACK = 'b';
  public static final char CODON_GO = 'g';
  public static final char CODON_ADD = '+';
  public static final char CODON_MUL = '*';
  public static final char CODON_DIV = '/';
  public static final char CODON_AND = '&';
  public static final char CODON_OR = '|';
  public static final char CODON_XOR = '^';
  public static final char CODON_SHL = '[';
  public static final char CODON_SHR = ']';
  public static final char CODON_INC = '>';
  public static final char CODON_DEC = '<';
  public static final char CODON_STA = '#';
  public static final char CODON_CMP = '?';
  public static final char CODON_LOOP = '{';
  public static final char CODON_REP = '}';
  public static final char CODON_READ = 'r';
  public static final char CODON_WRITE = 'w';
  public static final char CODON_SCH = 's';
  public static final char CODON_STOP = '!';

  //
  // Mappings of codons to the top 6 bits of a series of bytes
  //
  // This mapping had a score of 18.5 and was the best after over 4 billion
  // trials of the csearch.c hill climbing search program.
  //
  private static final char[] CODON_MAPPING = {
    CODON_CMP,    // 0x00
    CODON_DIV,    // 0x01
    CODON_SHR,    // 0x02
    CODON_SHR,    // 0x03
    CODON_XOR,    // 0x04
    CODON_XOR,    // 0x05
    CODON_XOR,    // 0x06
    CODON_XOR,    // 0x07
    CODON_CMP,    // 0x08
    CODON_DIV,    // 0x09
    CODON_SHR,    // 0x0a
    CODON_SHR,    // 0x0b
    CODON_SHL,    // 0x0c
    CODON_SHL,    // 0x0d
    CODON_SHL,    // 0x0e
    CODON_SHL,    // 0x0f
    CODON_DEC,    // 0x10
    CODON_INC,    // 0x11
    CODON_REP,    // 0x12
    CODON_SCH,    // 0x13
    CODON_DEC,    // 0x14
    CODON_INC,    // 0x15
    CODON_REP,    // 0x16
    CODON_SCH,    // 0x17
    CODON_DEC,    // 0x18
    CODON_INC,    // 0x19
    CODON_STOP,   // 0x1a
    CODON_REP,    // 0x1b
    CODON_DEC,    // 0x1c
    CODON_INC,    // 0x1d
    CODON_STOP,   // 0x1e
    CODON_REP,    // 0x1f
    CODON_OR,     // 0x20
    CODON_OR,     // 0x21
    CODON_OR,     // 0x22
    CODON_OR,     // 0x23
    CODON_ADD,    // 0x24
    CODON_ADD,    // 0x25
    CODON_MUL,    // 0x26
    CODON_MUL,    // 0x27
    CODON_READ,   // 0x28
    CODON_READ,   // 0x29
    CODON_STA,    // 0x2a
    CODON_AND,    // 0x2b
    CODON_ADD,    // 0x2c
    CODON_ADD,    // 0x2d
    CODON_STA,    // 0x2e
    CODON_AND,    // 0x2f
    CODON_BACK,   // 0x30
    CODON_GO,     // 0x31
    CODON_WRITE,  // 0x32
    CODON_FWD,    // 0x33
    CODON_BACK,   // 0x34
    CODON_GO,     // 0x35
    CODON_WRITE,  // 0x36
    CODON_FWD,    // 0x37
    CODON_BACK,   // 0x38
    CODON_BACK,   // 0x39
    CODON_LOOP,   // 0x3a
    CODON_FWD,    // 0x3b
    CODON_BACK,   // 0x3c
    CODON_BACK,   // 0x3d
    CODON_LOOP,   // 0x3e
    CODON_FWD };  // 0x3f

  // Maximum value of codons (top 6 bits of byte)
  public static final byte CODON_VALUE_MAX = (byte)0x3f;

  // Map containing codon values by character meaning-- used by the synthetic
  // genome constructor.
  private static Map characterToCodeMap = null;

  // Static weak reference to canonical genomes (they get cleaned up if there
  // are no more instances of this class)
  private static WeakReference static_canonicalGenomes = null;

  /**
   * <p>ThreadLocal to return copies of the stack for each thread</p>
   *
   * <p>To save memory, only one copy of the stack is kept for each running
   * thread as a ThreadLocal variable.</p>
   *
   * @author Adam Ierymenko
   * @version 1.0
   */
  private static class ThreadLocalPositionInformationStack extends ThreadLocal
  {
    protected Object initialValue()
    {
      return new int[262144];
    }
  }

  /**
   * ThreadLocal stack instance
   */
  private static ThreadLocalPositionInformationStack threadLocalStack = new ThreadLocalPositionInformationStack();

  // -------------------------------------------------------------------------

  // Integer array for bit field
  private byte[] instructions;

  // Hash code (cached after first calcuation in hashCode())
  private int hashCode;

  // Internal database of canonicalized genomes
  private WeakHashMap canonicalGenomes;

  //
  // Externalizable methods for networked object transfer
  //
  public void writeExternal(ObjectOutput out)
    throws IOException
  {
    out.writeInt(instructions.length);
    for(int i=0;i<instructions.length;i++)
      out.writeByte(instructions[i]);
  }
  public void readExternal(ObjectInput in)
    throws IOException, ClassNotFoundException
  {
    instructions = new byte[in.readInt()];
    for(int i=0;i<instructions.length;i++)
      instructions[i] = in.readByte();
  }

  /**
   * Main method: run this class to benchmark it
   *
   * @param argv Arguments (not used)
   */
  public static void main(String[] argv)
  {
    try {
      System.out.println("Benchmarking RegisterMachineGenome2...");
      System.out.println();

      Compiler.compileClass(Class.forName("com.generalnegentropics.archis.life.vms.RegisterMachineGenome2"));
      Thread.sleep(1000L);
      System.gc();

      IntegerInput[] noInput = new IntegerInput[0];
      int[] memory = new int[Archis.CELL_STATE_MEMORY_SIZE];
      RegisterMachineGenome test = new RegisterMachineGenome(new MersenneTwisterRandomSource(System.currentTimeMillis()),"ggggg?????>[[[{<}>[[[{<}>[[[{<}>[[[{<}>[[[{<}>[[[{<}>[[[[[[#+++++{<<}");
      long ni = 0L;
      for(int i=0;i<1000;i++)
        test.execute(noInput,null,null,memory,1000000000);

      System.gc();

      long start = System.currentTimeMillis();
      for(int i=0;i<500000;i++)
        ni += (long)test.execute(noInput,null,null,memory,1000000000);
      long end = System.currentTimeMillis();

      NumberFormat df = DecimalFormat.getNumberInstance();
      df.setMaximumFractionDigits(2);
      df.setMinimumFractionDigits(2);
      df.setMinimumIntegerDigits(1);
      df.setMaximumIntegerDigits(16384);
      df.setGroupingUsed(false);
      System.out.println("Instructions Executed: "+ni);
      System.out.println("Execution Time: "+df.format((double)(end-start) / 1000.0)+"sec");
      System.out.println("Instructions/Second: "+df.format((double)ni / ((double)(end-start) / 1000.0)));
    } catch (Throwable t) {
      t.printStackTrace();
    }
  }

  /**
   * For internal and serialization use only; DO NOT USE
   */
  public RegisterMachineGenome()
  {
    if (static_canonicalGenomes == null) {
      canonicalGenomes = new WeakHashMap(131072,0.75F);
      static_canonicalGenomes = new WeakReference(canonicalGenomes);
    } else {
      canonicalGenomes = (WeakHashMap)static_canonicalGenomes.get();
      if (canonicalGenomes == null) {
        canonicalGenomes = new WeakHashMap(131072,0.75F);
        static_canonicalGenomes = new WeakReference(canonicalGenomes);
      }
    }

    hashCode = -1;
  }

  /**
   * <p>Constructs a genome from a byte array of codons in 8-bit representation</p>
   *
   * <p>Each byte holds a single 6-bit codon.  Only the topmost 6 bits of each
   * byte are significant.  The first 2 bits are ignored.</p>
   *
   * @param codons Codons to place in genome
   * @param start Where to start in array
   * @param length Length of array
   */
  public RegisterMachineGenome(byte[] codons,int start,int length)
  {
    this();

    instructions = new byte[length];
    for(int i=0;i<length;i++)
      instructions[i] = (byte)(codons[i+start] & CODON_VALUE_MAX);
  }

  public Genome createNew(byte[] codons,int start,int length)
  {
    return new RegisterMachineGenome(codons,start,length);
  }

  /**
   * <p>Constructs a genome from a byte array of codons in 8-bit representation</p>
   *
   * <p>Each byte holds a single 6-bit codon.  Only the topmost 6 bits of each
   * byte are significant.  The first 2 bits are ignored.</p>
   *
   * @param codons Codons to place in genome
   */
  public RegisterMachineGenome(byte[] codons)
  {
    this(codons,0,codons.length);
  }

  public Genome createNew(byte[] codons)
  {
    return new RegisterMachineGenome(codons,0,codons.length);
  }

  /**
   * <p>Constructs a genome from a genome in character notation.</p>
   *
   * <p>In cases in which there is more than one code for an instruction,
   * an equivalent code will be chosen randomly from those available.</p>
   *
   * <p>Invalid characters such as spaces and carriage returns are ignored.</p>
   *
   * @param randomSource Random source for randomly selecting codons for instructions
   * @param syntheticGenome Genome in human-readable character notation
   */
  public RegisterMachineGenome(RandomSource randomSource,String syntheticGenome)
  {
    this();

    // Create static character to code map if it doesn't exist already
    if (characterToCodeMap == null) {
      characterToCodeMap = new HashMap(128,0.99F);
      for(int i=0;i<CODON_MAPPING.length;i++) {
        Character c = new Character(CODON_MAPPING[i]);
        ArrayList byteValues = (ArrayList)characterToCodeMap.get(c);
        if (byteValues == null) {
          byteValues = new ArrayList(64);
          characterToCodeMap.put(c,byteValues);
        }
        byteValues.add(new Byte((byte)i));
      }
      for(Iterator i=characterToCodeMap.values().iterator();i.hasNext();)
        ((ArrayList)i.next()).trimToSize();
    }

    // Create an array of codon translations from the string
    byte[] rawinst = new byte[syntheticGenome.length()];
    int cptr = 0;
    int loops = 0;
    for(int i=0;i<rawinst.length;i++) {
      ArrayList possibleCodons = (ArrayList)characterToCodeMap.get(new Character(syntheticGenome.charAt(i)));
      if (possibleCodons != null) {
        Byte codon = (Byte)possibleCodons.get(randomSource.randomPositiveInteger() % possibleCodons.size());
        if (codon != null) {
          if (CODON_MAPPING[rawinst[cptr++] = codon.byteValue()] == CODON_LOOP)
            ++loops;
        }
      }
    }

    // Create instructions array
    instructions = new byte[cptr];
    for(int i=0;i<cptr;i++)
      instructions[i] = rawinst[i];
  }

  public Genome createNew(RandomSource randomSource,String syntheticGenome)
  {
    return new RegisterMachineGenome(randomSource,syntheticGenome);
  }

  /**
   * <p>Constructs a random genome with the given mean size +/- up to the given
   * size deviation.</p>
   *
   * @param randomSource Source for random numbers to generate genome
   * @param meanSize Mean size of genome in codons
   * @param sizeDeviation Maximum random deviation (+ or -) from size
   */
  public RegisterMachineGenome(RandomSource randomSource,int meanSize,int sizeDeviation)
  {
    this();

    // Figure out what the genome size should be
    int genomeSize;
    if (randomSource.randomBoolean())
      genomeSize = meanSize + (randomSource.randomPositiveInteger() % sizeDeviation);
    else genomeSize = meanSize - (randomSource.randomPositiveInteger() % sizeDeviation);
    if (genomeSize <= 0)
      genomeSize = meanSize;

    // Create random instructions
    instructions = new byte[genomeSize];
    for(int i=0;i<genomeSize;i++)
      instructions[i] = (byte)(randomSource.randomByte() & CODON_VALUE_MAX);
  }

  public Genome createNew(RandomSource randomSource,int meanSize,int sizeDeviation)
  {
    return new RegisterMachineGenome(randomSource,meanSize,sizeDeviation);
  }

  public Genome canonicalize()
  {
    WeakReference r;
    Genome g;
    if (canonicalGenomes == null)
      canonicalGenomes = new WeakHashMap(131072,0.75F);
    synchronized(canonicalGenomes) {
      r = (WeakReference)canonicalGenomes.get(this);
      if (r == null) {
        canonicalGenomes.put(this,new WeakReference(this));
        return this;
      } else if ((g = (Genome)r.get()) == null) {
        canonicalGenomes.put(this,new WeakReference(this));
        return this;
      }
    }
    return g;
  }

  /**
   * Returns a hash code for this genome
   *
   * @return Hash code
   */
  public int hashCode()
  {
    if (hashCode == -1) {
      // This is the same kind of hashing algorithm used by java.lang.String
      hashCode = 0;
      for(int i=0;i<instructions.length;i++)
        hashCode += ((int)instructions[i] * 31) ^ (instructions.length-(i+1));
    }
    return hashCode;
  }

  /**
   * Returns whether or not an object is equal to this genome object
   *
   * @param o Object to compare against
   * @return Equal?
   */
  public boolean equals(Object o)
  {
    if (o != null) {
      if (o == this)
        return true;
      else if (o instanceof RegisterMachineGenome) {
         if (((RegisterMachineGenome)o).instructions.length == instructions.length) {
           for(int i=0;i<instructions.length;i++) {
             if (((RegisterMachineGenome)o).instructions[i] != instructions[i])
               return false;
           }
           return true;
         }
      }
    }
    return false;
  }

  public Genome pointMutation(RandomSource randomSource)
  {
    RegisterMachineGenome newGenome = new RegisterMachineGenome();
    newGenome.instructions = new byte[instructions.length];
    int mutateByte = randomSource.randomPositiveInteger() % instructions.length;
    for(int i=0;i<instructions.length;i++) {
      if (i == mutateByte)
        newGenome.instructions[i] = (byte)(instructions[i] ^ (0x01 << (randomSource.randomPositiveInteger() % 6)));
      else newGenome.instructions[i] = instructions[i];
    }
    return newGenome;
  }

  public Genome insertionMutation(RandomSource randomSource)
  {
    RegisterMachineGenome newGenome = new RegisterMachineGenome();
    newGenome.instructions = new byte[instructions.length+1];
    int insertPos = randomSource.randomPositiveInteger() % instructions.length;
    int c = 0;
    for(int i=0;i<instructions.length;i++) {
      if (i == insertPos)
        newGenome.instructions[c++] = (byte)(randomSource.randomByte() & CODON_VALUE_MAX);
      newGenome.instructions[c++] = instructions[i];
    }
    return newGenome;
  }

  public Genome deletionMutation(RandomSource randomSource)
  {
    if (instructions.length <= 1)
      return this;
    RegisterMachineGenome newGenome = new RegisterMachineGenome();
    newGenome.instructions = new byte[instructions.length-1];
    int deletePos = randomSource.randomPositiveInteger() % instructions.length;
    int c = 0;
    for(int i=0;i<instructions.length;i++) {
      if (i != deletePos)
        newGenome.instructions[c++] = instructions[i];
    }
    return newGenome;
  }

  public Genome duplicationMutation(RandomSource randomSource)
  {
    int dupPos = randomSource.randomPositiveInteger() % instructions.length;
    if (dupPos == instructions.length-1)
      return this;
    int dupLen = randomSource.randomPositiveInteger() % (instructions.length-dupPos);
    if (dupLen <= 0)
      return this;
    RegisterMachineGenome newGenome = new RegisterMachineGenome();
    newGenome.instructions = new byte[instructions.length+dupLen];
    int c = 0;
    for(int i=0;i<instructions.length;i++) {
      if (i == dupPos) {
        for(int j=0;j<dupLen;j++)
          newGenome.instructions[c++] = instructions[i+j];
      }
      newGenome.instructions[c++] = instructions[i];
    }
    return newGenome;
  }

  public Genome concat(Genome genome)
    throws IncompatibleGenomeException
  {
    if (genome == null)
      return this;
    else if (genome instanceof RegisterMachineGenome) {
      // Create destination buffer for new codons
      byte[] buf = new byte[instructions.length + ((RegisterMachineGenome)genome).instructions.length];
      int ptr = 0;

      // Copy this genome's codons into buffer
      for(int i=0;i<instructions.length;i++)
        buf[ptr++] = instructions[i];

      // Copy other genome's codons into buffer
      for(int i=0;i<((RegisterMachineGenome)genome).instructions.length;i++)
        buf[ptr++] = ((RegisterMachineGenome)genome).instructions[i];

      // Return new genome from buffer
      return new RegisterMachineGenome(buf);
    } else throw new IncompatibleGenomeException();
  }

  /**
   * Returns a human-readable String of the instruction sequence of this genome
   *
   * @return Human-readable string
   */
  public String toString()
  {
    char[] r = new char[instructions.length];
    for(int i=0;i<instructions.length;i++)
      r[i] = CODON_MAPPING[instructions[i]];
    return new String(r);
  }

  public int writeTo(OutputStream out)
    throws IOException
  {
    out.write(instructions);
    return instructions.length;
  }

  public byte[] toUnmodifiableByteArray()
  {
    return instructions;
  }

  public int getCodonCount()
  {
    return 64;
  }

  public void getCodonDistribution(long[] codonCounts)
  {
    for(int i=0;i<instructions.length;i++)
      ++codonCounts[instructions[i] & CODON_VALUE_MAX];
  }

  public int checksum()
  {
    return hashCode();
  }

  public int size()
  {
    return instructions.length;
  }

  public int sizeBytes()
  {
    // Return instructions.length + 4 bytes each for hashCode and
    // maxInstructions integers
    return instructions.length+8;
  }

  public int execute(IntegerInput[] input,Universe output,Cell cell,int[] memory,int maxInstructions)
  {
    // State of virtual machine
    int a = 0;
    int p = 0;
    int channel = 0;

    // Instruction execution counter
    int ictr = 0;

    // Are we inside an intron?
    boolean betweenGenes = true;

    // Depth of false LOOPs
    int falseLoopDepth = 0;

    // Get the stack for storing loop returns
    int[] loopStack = (int[])threadLocalStack.get();
    if (loopStack.length < (instructions.length*4)) {
      loopStack = new int[instructions.length * 2];
      threadLocalStack.set(loopStack);
    }
    int stackPtr = 0;

    // Execute genome by stepping through bitmap six-bits by six-bits
    int mv = 0;
    for(int i=0;i<instructions.length;i++) {
      if (betweenGenes) {
        // If we're between genes, look for GO which is the start codon as well
        if (CODON_MAPPING[instructions[i]] == CODON_GO)
          betweenGenes = false;
      } else if (falseLoopDepth > 0) {
        // If we've passed a LOOP and a==0, keep tracing through LOOP/REP
        // pairs until matching REP is found
        switch(CODON_MAPPING[instructions[i]]) {
          case CODON_LOOP:
            ++falseLoopDepth;
            break;
          case CODON_REP:
            --falseLoopDepth;
            break;
          case CODON_STOP:
            a = 0;
            channel = 0;
            p = 0;
            stackPtr = 0;
            falseLoopDepth = 0;
            betweenGenes = true;
            break;
        }
      } else {
        // Each instruction actually executed costs one point (return if
        // cell dies)
        if (cell != null) {
          if (!cell.decEnergy())
            return ictr;
        }

        // Increment instructions executed counter and check for overflow
        if (++ictr > maxInstructions)
          return ictr;

        // Execute codon instruction
        switch (CODON_MAPPING[instructions[i]]) {
          case CODON_ADD:
            a += ((p >= 0) ? memory[p % memory.length] : instructions[(-p-1) % instructions.length]);
            break;
          case CODON_AND:
            a &= ((p >= 0) ? memory[p % memory.length] : instructions[(-p-1) % instructions.length]);
            break;
          case CODON_BACK:
            if (--p == -2147483648)
              p = 2147483647;
            break;
          case CODON_CMP:
            mv = ((p >= 0) ? memory[p % memory.length] : instructions[(-p-1) % instructions.length]);
            a = ((a < mv) ? -1 : ((a == mv) ? 0 : 1));
            break;
          case CODON_DEC:
            --a;
            break;
          case CODON_DIV:
            mv = ((p >= 0) ? memory[p % memory.length] : instructions[(-p-1) % instructions.length]);
            if (mv == 0)
              a = 0;
            else a /= mv;
            break;
          case CODON_FWD:
            if (++p == -2147483648)
              p = 2147483647;
            break;
          case CODON_GO:
            p = ((a == -2147483648) ? 2147483647 : a);
            break;
          case CODON_INC:
            ++a;
            break;
          case CODON_LOOP:
            // Push position if 'a' is nonzero
            if (a == 0)
              ++falseLoopDepth;
            else {
              loopStack[stackPtr++] = i;
              if (stackPtr >= loopStack.length)
                return ictr;
            }
            break;
          case CODON_MUL:
            a *= ((p >= 0) ? memory[p % memory.length] : instructions[(-p-1) % instructions.length]);
            break;
          case CODON_OR:
            a |= ((p >= 0) ? memory[p % memory.length] : instructions[(-p-1) % instructions.length]);
            break;
          case CODON_READ:
            a = ((input == null) ? 0 : ((input[channel] == null) ? 0 : input[channel].read()));
            break;
          case CODON_REP:
            if (stackPtr > 0) {
              if (a != 0) {
                // Restore position of matching LOOP if 'a' is nonzero
                i = loopStack[--stackPtr]-1;
              } else {
                // Drop it off the stack and move on if a == 0
                --stackPtr;
              }
            }
            break;
          case CODON_SCH:
            channel = ((a == -2147483648) ? 2147483647 : ((a < 0) ? -a : a)) % Archis.CHANNEL_COUNT;
            break;
          case CODON_SHL:
            a <<= 1;
            break;
          case CODON_SHR:
            a >>>= 1;
            break;
          case CODON_STA:
            if (p >= 0) {
              // Set memory value at location
              memory[p % memory.length] = a;
            } else {
              // Set genome value at location
              instructions[(-p-1) % instructions.length] = (byte)(a & CODON_VALUE_MAX);
            }
            a = 0;
            break;
          case CODON_STOP:
            a = 0;
            channel = 0;
            p = 0;
            stackPtr = 0;
            betweenGenes = true;
            break;
          case CODON_WRITE:
            if (output != null)
              output.evaluateOutput(cell,channel,a);
            break;
          case CODON_XOR:
            a ^= ((p >= 0) ? memory[p % memory.length] : instructions[(-p-1) % instructions.length]);
            break;
        }
      }
    }

    return ictr;
  }
}
