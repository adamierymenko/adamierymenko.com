package com.generalnegentropics.archis.universe.environmentalconditions;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

import java.util.*;
import com.generalnegentropics.archis.universe.*;
import com.generalnegentropics.archis.life.*;
import com.generalnegentropics.archis.*;
import com.generalnegentropics.archis.utils.ParameterValueParser;

/**
 * Kills cells after a specified age is reached
 *
 * @author Adam Ierymenko
 * @version 1.0
 */

public class LifespanCondition implements EnvironmentalCondition
{
  /**
   * Description of condition
   */
  public static final String CONDITION_DESCRIPTION = "Kills cells after a specified life span.";

  private static Map parameters;
  static
  {
    parameters = new HashMap();
    parameters.put("lifespan","Maximum age of cells in ticks before they are killed");
    parameters = Collections.unmodifiableMap(parameters);
  }

  private long lifespan;
  private volatile long cellsKilled;
  private Simulation simulation;

  public Map getParameters()
  {
    return parameters;
  }

  public Object getParameter(String name)
  {
    if ("lifespan".equals(name))
      return new Long(lifespan);
    return null;
  }

  public void setParameter(String name,Object value)
  {
    if ("lifespan".equals(name))
      lifespan = ParameterValueParser.getLong(value);
  }

  /**
   * Construct a new LifespanCondition
   */
  public LifespanCondition()
  {
    lifespan = 200L;
    cellsKilled = 0L;
  }

  public boolean newCellNotify(Cell parent, Cell newCell)
  {
    return true;
  }

  public void deathNotify(Cell deadCell, String reason)
  {
  }

  public void preExecutionNotify(Cell l)
  {
    if (l.alive()&&(l.age() > lifespan)) {
      l.kill(false,"Life span reached");
      ++cellsKilled;
    }
  }

  public void init(Universe universe, Simulation simulation)
  {
    this.simulation = simulation;
  }

  public void initCellNotify(Cell cell)
  {
  }

  public void destroy()
  {
  }

  public void preTickNotify() throws ConditionExpirationException
  {
  }

  public void postTickNotify() throws ConditionExpirationException
  {
    simulation.setStatistic("LSC LifeSpanCondition.totalCellsKilled",cellsKilled);
  }

  public void postTickProcessCells(List cells)
  {
  }

  public String getChannelDescription(int channel)
  {
    return null;
  }

  public void evaluateOutput(Cell l, int channel, int value)
  {
  }
}

