package com.generalnegentropics.archis.universe.environmentalconditions;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

import java.util.*;
import com.generalnegentropics.archis.life.*;
import com.generalnegentropics.archis.universe.*;
import com.generalnegentropics.archis.*;
import com.generalnegentropics.archis.utils.*;

/**
 * <p>A condition to induce genesis in an empty universe containing no life.</p>
 *
 * @author Adam Ierymenko
 * @version 2.0
 */

public class GenesisCondition implements EnvironmentalCondition
{
  /**
   * Description of condition
   */
  public static final String CONDITION_DESCRIPTION = "Generates cells with random genomes to create genesis from randomness.";

  private static Map parameters;
  static
  {
    parameters = new HashMap();
    parameters.put("createCellsPerTick","Number of cells to create per tick");
    parameters.put("genomeMeanSize","Mean size of new cell genomes");
    parameters.put("genomeSizeDeviation","Deviation +/- mean for cell genome sizes");
    parameters.put("newCellEnergy","Energy to give to new cells");
    parameters.put("genomeType","Type of new genome");
    parameters = Collections.unmodifiableMap(parameters);
  }

  private Universe universe;
  private Simulation simulation;
  private RandomSource randomSource;
  private int createCellsPerTick;
  private int genomeMeanSize;
  private int genomeSizeDeviation;
  private int genomeType;
  private int newCellEnergy;
  private long totalCellsCreated;

  public GenesisCondition()
  {
    totalCellsCreated = 0L;
    newCellEnergy = 10000;
    genomeMeanSize = 100;
    genomeSizeDeviation = 50;
    createCellsPerTick = 10;
    genomeType = GenomeFactory.GENOME_TYPE_RANDOM;
  }

  public Map getParameters()
  {
    return parameters;
  }

  public Object getParameter(String name)
  {
    if ("createCellsPerTick".equals(name))
      return new Integer(createCellsPerTick);
    else if ("genomeMeanSize".equals(name))
      return new Integer(genomeMeanSize);
    else if ("genomeSizeDeviation".equals(name))
      return new Integer(genomeSizeDeviation);
    else if ("newCellEnergy".equals(name))
      return new Integer(newCellEnergy);
    else if ("genomeType".equals(name))
      return new Integer(genomeType);
    return null;
  }

  public void setParameter(String name,Object value)
  {
    if ("createCellsPerTick".equals(name))
      createCellsPerTick = ParameterValueParser.getInt(value);
    else if ("genomeMeanSize".equals(name))
      genomeMeanSize = ParameterValueParser.getInt(value);
    else if ("genomeSizeDeviation".equals(name))
      genomeSizeDeviation = ParameterValueParser.getInt(value);
    else if ("newCellEnergy".equals(name))
      newCellEnergy = ParameterValueParser.getInt(value);
    else if ("genomeType".equals(name))
      genomeType = ParameterValueParser.getInt(value);
  }

  public void init(Universe universe,Simulation simulation)
  {
    this.universe = universe;
    this.simulation = simulation;
    randomSource = simulation.randomSource();
  }

  public void destroy()
  {
  }

  public void preTickNotify()
    throws ConditionExpirationException
  {
  }

  public void postTickNotify()
    throws ConditionExpirationException
  {
    for(int i=0;i<createCellsPerTick;i++) {
      universe.addCell(null,new Cell(universe,simulation.nextCellId(),simulation.getName(),0L,0L,newCellEnergy,GenomeFactory.create(genomeType,randomSource,genomeMeanSize,genomeSizeDeviation)));
      ++totalCellsCreated;
    }

    simulation.setStatistic("GC1 GenesisCondition.randomCellsCreated",totalCellsCreated);
  }

  public void postTickProcessCells(List cells)
  {
  }

  public void preExecutionNotify(Cell cell)
  {
  }

  public void evaluateOutput(Cell l, int channel, int value)
  {
  }

  public void deathNotify(Cell deadCell,String reason)
  {
  }

  public boolean newCellNotify(Cell parent,Cell newCell)
  {
    return true;
  }

  public void initCellNotify(Cell cell)
  {
  }

  public String getChannelDescription(int channel)
  {
    return null;
  }
}
