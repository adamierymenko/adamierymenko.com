package com.generalnegentropics.archis.gui;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

import java.util.*;
import java.lang.reflect.*;
import javax.swing.event.*;
import javax.swing.table.*;
import com.generalnegentropics.archis.universe.*;
import com.generalnegentropics.archis.universe.environmentalconditions.*;
import com.generalnegentropics.archis.gui.conditions.*;
import com.generalnegentropics.archis.*;

/**
 * A table model for the tables of conditions in the main simulation dialog
 *
 * @author Adam Ierymenko
 * @version 1.0
 */

public class ConditionListTableModel implements TableModel
{
  private HashSet tableModelListeners;
  private TreeMap conditions;
  private HashSet conditionsEnabled;
  private HashMap descriptions;
  private Object[] conditionsArray;
  private Universe universe;
  private Simulation simulation;
  private TableModelEvent allChangedEvent;

  public ConditionListTableModel(Simulation simulation,Universe universe)
  {
    this.universe = universe;
    this.simulation = simulation;
    tableModelListeners = new HashSet(32,0.75F);
    conditions = new TreeMap();
    conditionsEnabled = new HashSet(64,0.75F);
    descriptions = new HashMap(64,0.75F);
    conditionsArray = new Object[0];
    allChangedEvent = new TableModelEvent(this);
    for(Iterator i=universe.getConditions().iterator();i.hasNext();) {
      String cn = i.next().getClass().getName();
      int tmp = cn.lastIndexOf('.');
      if (tmp > 0)
        cn = cn.substring(tmp+1);
      conditionsEnabled.add(cn);
    }
  }

  public void addCondition(Class condition)
  {
    String desc = "No description available";
    try {
      Field df = condition.getField("CONDITION_DESCRIPTION");
      if (Modifier.isStatic(df.getModifiers())&&Modifier.isPublic(df.getModifiers())) {
        Object tmp = df.get(null);
        desc = tmp.toString();
      }
    } catch (NoSuchFieldException e) {
      desc = "No description available";
    } catch (IllegalAccessException e) {
      desc = "No description available";
    }
    synchronized(conditions) {
      String cn = condition.getName();
      int tmp = cn.lastIndexOf('.');
      if (tmp > 0)
        cn = cn.substring(tmp+1);
      conditions.put(cn,condition);
      descriptions.put(cn,desc);
      conditionsArray = conditions.keySet().toArray();
      for(Iterator i=tableModelListeners.iterator();i.hasNext();) {
        TableModelListener l = (TableModelListener)i.next();
        l.tableChanged(allChangedEvent);
      }
    }
  }

  public void activateCondition(String name)
    throws IllegalAccessException,InstantiationException
  {
    Class cond = (Class)conditions.get(name);
    if (cond != null) {
      Condition nc = (Condition)cond.newInstance();
      conditionsEnabled.add(name);
      universe.addCondition(nc);
      if (nc instanceof Landscape2D)
        new Landscape2DWindow(simulation,(Landscape2D)nc).setVisible(true);
      else new GeneralConditionWindow(simulation,nc).setVisible(true);
    }
    for(Iterator i=tableModelListeners.iterator();i.hasNext();) {
      TableModelListener l = (TableModelListener)i.next();
      l.tableChanged(allChangedEvent);
    }
  }

  public boolean hasCondition(String name)
  {
    synchronized(conditions) {
      return conditions.containsKey(name);
    }
  }

  public void inactivateCondition(String name)
  {
    Class condition = (Class)conditions.get(name);
    if (condition != null) {
      Set uc = universe.getConditions();
      Object c = null;
      for(Iterator i=uc.iterator();i.hasNext();) {
        Object tmp = i.next();
        if (tmp.getClass().getName().equals(condition.getName())) {
          c = tmp;
          break;
        }
      }
      if (c != null) {
        universe.removeCondition((Condition)c);
        conditionsEnabled.remove(name);
      }
      for(Iterator i=tableModelListeners.iterator();i.hasNext();) {
        TableModelListener l = (TableModelListener)i.next();
        l.tableChanged(allChangedEvent);
      }
    }
  }

  public int getRowCount()
  {
    return conditionsArray.length;
  }

  public int getColumnCount()
  {
    return 3;
  }

  public String getColumnName(int columnIndex)
  {
    switch(columnIndex) {
      case 0:
        return "Active";
      case 1:
        return "Name";
      case 2:
        return "Description";
    }
    return "error";
  }

  public Class getColumnClass(int columnIndex)
  {
    if (columnIndex == 0)
      return Boolean.TRUE.getClass();
    return "".getClass();
  }

  public boolean isCellEditable(int rowIndex, int columnIndex)
  {
    return false;
  }

  public Object getValueAt(int rowIndex, int columnIndex)
  {
    switch(columnIndex) {
      case 0:
        return (conditionsEnabled.contains(conditionsArray[rowIndex]) ? Boolean.TRUE : Boolean.FALSE);
      case 1:
        return conditionsArray[rowIndex];
      case 2:
        return descriptions.get(conditionsArray[rowIndex]);
    }
    return "";
  }

  public void setValueAt(Object aValue, int rowIndex, int columnIndex)
  {
  }

  public void addTableModelListener(TableModelListener l)
  {
    tableModelListeners.add(l);
  }

  public void removeTableModelListener(TableModelListener l)
  {
    tableModelListeners.remove(l);
  }
}
