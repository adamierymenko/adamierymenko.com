package com.generalnegentropics.archis.utils;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

import java.util.*;
import java.io.*;

/**
 * <p>Math Expression</p>
 *
 * <p>
 * This class implements a mathematical expression evaluator that allows
 * expressions consisting of simple variables, numbers, and operators to
 * be evaluated.  When instantiated it precompiles the expression and then
 * can be executed repeatedly for different sets of variables.  It is an
 * immutable class like String and Number so it can be shared and used from
 * multiple threads.  The evaluate method is thread safe.
 * </p>
 *
 * <p>
 * This parser is fully conscious of the order of operations: parentheses,
 * exponents, multiplication, division, addition, subtraction.
 * </p>
 *
 * <p>
 * Allowed operators are: +, -, *, /, and ^ (anything else will be considered
 * part of a variable name).
 * </p>
 *
 * @author Adam Ierymenko
 * @version 1.0
 */

public class MathExpression implements Externalizable
{
  private static String[] orderOfOperations = { "^","*/","+-" };
  private String stringExpression;
  private String[] variableNames;
  private ArrayList compiledExpression;
  private int myHashCode;

  //
  // Serializability functions
  //
  public void writeExternal(ObjectOutput out)
    throws IOException
  {
    char[] tmp = stringExpression.toCharArray();
    for(int i=0;i<tmp.length;i++)
      out.writeChar(tmp[i]);
    out.writeChar((char)0);
  }
  public void readExternal(ObjectInput in)
    throws IOException,ClassNotFoundException
  {
    StringBuffer tmp = new StringBuffer(128);
    char x;
    while ((x = in.readChar()) != (char)0)
      tmp.append(x);
    precompile(tmp.toString());
  }

  /**
   * Constructor for implementing Externalizable; do not use!
   */
  public MathExpression()
  {
  }

  /**
   * Constructs a new math expression
   *
   * @param expression Expression to compile
   */
  public MathExpression(String expression)
  {
    precompile(expression);
  }

  //
  // Internal precompilation function
  //
  private void precompile(String expression)
  {
    //
    // Here we compile the expression into a linked list.  The list consists
    // of a series of either Number objects or Strings (variables) or other
    // ArrayList objects representing nested (parentheses) expressions.  These
    // are alternated between Character objects representing operators.
    //
    // This is a really complex parser.  Look at how it works before you
    // screw with it.
    //
    HashSet variableNameList = new HashSet(32,0.75F);
    ArrayList currentList = new ArrayList(32);
    myHashCode = 0x1be31337;
    Stack previousLists = new Stack();
    StringBuffer currentVar = new StringBuffer(64);
    char c,lastChar = (char)0,lastChar2 = (char)0;
    boolean varNameParenState = false;
    for(int i=0,l=expression.length();i<l;i++) {
      c = expression.charAt(i);
      switch(c) {
        case ' ':
        case '\r':
        case '\n':
        case '\t':
        case (char)0:
          // Ignore junk... note that this means that spaces have no meaning.
          // This is OK but has the implication that "7 00" is "700".  This
          // should never be a problem.
          break;
        case '-':
        case '+':
          // Get - or + as part of the current number or variable if it is
          // a sign or scientific notation-- otherwise count it as an operator.
          if (("+-*^/(".indexOf(lastChar) >= 0)||(lastChar == (char)0)) {
            // It's a sign if it follows an operator or begins the expression
            // or a parentheses subexpression.  The + sign is omitted since
            // numbers are assumed to be positive without a - sign.
            if (c != '+')
              currentVar.append(c);
            break;
          } else if (((lastChar == 'e')||(lastChar == 'E'))&&("0123456789".indexOf(lastChar2) >= 0)) {
            // It's part of a scientific notation expression if it follows E
            // and the character preceding E is a number.
            currentVar.append(c);
            break;
          }
        case '*':
        case '/':
        case '^':
          if (currentVar.length() > 0) {
            String tmp = currentVar.toString();
            myHashCode += tmp.hashCode();
            if (isNumber(tmp))
              currentList.add(new Double(tmp));
            else {
              currentList.add(tmp);
              variableNameList.add(tmp);
            }
            currentVar.delete(0,currentVar.length());
          }
          currentList.add(new Character(c));
          myHashCode *= (int)c;
          break;
        case '(':
          if (("+-*/^".indexOf(lastChar) >= 0)||(lastChar == (char)0)) {
            if (currentVar.length() > 0) {
              String tmp = currentVar.toString();
              myHashCode += tmp.hashCode();
              if (isNumber(tmp))
                currentList.add(new Double(tmp));
              else {
                currentList.add(tmp);
                variableNameList.add(tmp);
              }
              currentVar.delete(0,currentVar.length());
            }
            previousLists.push(currentList);
            currentList = new ArrayList(16);
            myHashCode ^= 0xdeadbeef;
          } else {
            varNameParenState = true;
            currentVar.append(c);
          }
          break;
        case ')':
          if (varNameParenState) {
            currentVar.append(c);
            varNameParenState = false;
          } else {
            if (currentVar.length() > 0) {
              String tmp = currentVar.toString();
              myHashCode += tmp.hashCode();
              if (isNumber(tmp))
                currentList.add(new Double(tmp));
              else {
                currentList.add(tmp);
                variableNameList.add(tmp);
              }
              currentVar.delete(0,currentVar.length());
            }
            ArrayList saved = currentList;
            currentList = (ArrayList)(previousLists.isEmpty() ? null : previousLists.pop());
            if (currentList == null)
              currentList = saved; // Extra closing parens do nothing
            else currentList.add(saved);
            myHashCode ^= 0xbeefdead;
          }
          break;
        default:
          currentVar.append(c);
          break;
      }
      lastChar2 = lastChar;
      lastChar = c;
    }
    if (currentVar.length() > 0) {
      String tmp = currentVar.toString();
      myHashCode += tmp.hashCode();
      if (isNumber(tmp))
        currentList.add(new Double(tmp));
      else {
        currentList.add(tmp);
        variableNameList.add(tmp);
      }
    }

    compiledExpression = currentList;
    stringExpression = reformString(compiledExpression);
    int nll = variableNameList.size();
    variableNames = new String[nll];
    Iterator nl = variableNameList.iterator();
    int i=0;
    while (nl.hasNext())
      variableNames[i++] = (String)nl.next();
    Arrays.sort(variableNames);
  }

  //
  // This is a recursive function used above to reformulate a reduced
  // version of the original string.  The string generated by this is the
  // version returned by toString() and used for serialization.
  //
  private String reformString(ArrayList v)
  {
    StringBuffer r = new StringBuffer(v.size() * 32);
    Object tmp;
    String tmp2;
    for(int i=0,l=v.size();i<l;i++) {
      tmp = v.get(i);
      if (tmp instanceof ArrayList) {
        r.append('(');
        r.append(reformString((ArrayList)tmp));
        r.append(')');
      } else {
        tmp2 = tmp.toString();
        if (isNumber(tmp2))
          r.append(trimDecimal(tmp2));
        else r.append(tmp2);
      }
    }
    return r.toString();
  }

  //
  // This is our own isNumber function that also counts E and - as being
  // possible parts of a number.
  //
  private boolean isNumber(String s)
  {
    // Otherwise look for non-numeric characters in which numeric characters
    // are any number, + and - (signs), e (exponent), and . (decimal).
    boolean hasNumber = false;
    for(int i=0,l=s.length();i<l;i++) {
      switch(s.charAt(i)) {
        case '0':
        case '1':
        case '2':
        case '3':
        case '4':
        case '5':
        case '6':
        case '7':
        case '8':
        case '9':
        case '.':
          hasNumber = true;
          break;
        case '-':
        case '+':
        case 'e':
        case 'E':
          // Scientific notation-- it only returns true in this case if it also
          // has a number in it.
          break;
        default:
          return false;
      }
    }
    return hasNumber;
  }

  //
  // Trims trailing zeros in decimal numbers
  //
  private String trimDecimal(String s)
  {
    // Return zero for nulls
    if (s == null)
      return "0";

    // Don't do anything to non-decimal numbers
    if (s.indexOf('.') < 0)
      return s;

    // Find last occurrence of non-zero and non-decimal-point
    int i;
    char c;
    for(i=s.length()-1;i>=0;i--) {
      c = s.charAt(i);
      if ((c != '.')&&(c != '0'))
        break;
      else if (c == '.') {
        --i;
        break;
      }
    }

    // This shouldn't happen unless it's like 0.000000 or something
    if (i < 0)
      return "0";

    return s.substring(0,i+1);
  }

  /**
   * Gets a hash code for this MathExpression
   *
   * @return Hash code
   */
  public int hashCode()
  {
    // Code is generated inside compile code above
    return myHashCode;
  }

  /**
   * Tests for equality with another object
   *
   * @param o Object to test against
   * @return Is object equal to this one?
   */
  public boolean equals(Object o)
  {
    try {
      return compiledExpression.equals(((MathExpression)o).compiledExpression);
    } catch (ClassCastException e) {}
    return false;
  }

  /**
   * Returns a string expression of this math expression
   *
   * @return Math expression
   */
  public String toString()
  {
    return stringExpression;
  }

  //
  // This is just a quick method to fetch a number from a variable map
  // (Used internally)
  //
  private double getNumFromMap(Map variables,Object key)
  {
    if (key == null)
      return 0.0;
    Object tmp = variables.get(key);
    try {
      if (tmp != null)
        return ((Number)tmp).doubleValue();
    } catch (ClassCastException e) {
      try {
        return Double.parseDouble(tmp.toString());
      } catch (NumberFormatException e2) {}
    }
    return 0.0;
  }

  //
  // This gets the result, evaluating it if necessary
  //
  private double getResult(ArrayList segment,Map variables)
    throws MathExpressionException
  {
    if (segment.size() <= 0)
      return 0.0;
    Object tmp = segment.get(0);
    if (tmp instanceof ArrayList) {
      ArrayList vt = (ArrayList)((ArrayList)tmp).clone();
      for(int i=0;i<orderOfOperations.length;i++)
        __evaluate(orderOfOperations[i],vt,variables);
      return getResult(vt,variables);
    } else {
      try {
        return ((Number)tmp).doubleValue();
      } catch (ClassCastException e) {
        return getNumFromMap(variables,tmp);
      }
    }
  }

  //
  // This performs an evaluation cycle for a given operation on a given
  // segment, recursing if necessary.  The segment is mangled, so clone()'s
  // should always be used.
  //
  private void __evaluate(String currentOperations,ArrayList segment,Map variables)
    throws MathExpressionException,ArithmeticException
  {
    int tmp,idx,idxStart = 0;
    Object p1,p2,p3;
    char op;
    double t1,t2;
    for(;;) {
      idx = idxStart;
      tmp = segment.size();
      if (idx >= tmp)
        break;
      else p1 = segment.get(idx++);
      if (idx >= tmp)
        break;
      else p2 = segment.get(idx++);
      if (idx >= tmp)
        throw new MathExpressionException("Insufficient number of terms or operators");
      else p3 = segment.get(idx);
      try {
        op = ((Character)p2).charValue();
      } catch (ClassCastException e) {
        throw new MathExpressionException("Missing operator or two operators in a row without a term between");
      }
      if (currentOperations.indexOf(op) >= 0) {
        // If this is the op we are doing right now, do it
        segment.remove(idxStart);
        segment.remove(idxStart);
        segment.remove(idxStart);
        if (p1 instanceof String)
          t1 = getNumFromMap(variables,p1);
        else if (p1 instanceof ArrayList) {
          ArrayList vt = (ArrayList)((ArrayList)p1).clone();
          for(int i=0;i<orderOfOperations.length;i++)
            __evaluate(orderOfOperations[i],vt,variables);
          t1 = getResult(vt,variables);
        } else t1 = ((Number)p1).doubleValue();
        if (p3 instanceof String)
          t2 = getNumFromMap(variables,p3);
        else if (p3 instanceof ArrayList) {
          ArrayList vt = (ArrayList)((ArrayList)p3).clone();
          for(int i=0;i<orderOfOperations.length;i++)
            __evaluate(orderOfOperations[i],vt,variables);
          t2 = getResult(vt,variables);
        } else t2 = ((Number)p3).doubleValue();
        double result;
        // This is where the actual math is done
        switch(op) {
          case '+':
            result = t1 + t2;
            break;
          case '-':
            result = t1 - t2;
            break;
          case '^':
            result = Math.pow(t1,t2);
            break;
          case '*':
            result = t1 * t2;
            break;
          case '/':
            result = t1 / t2;
            break;
          default:
            result = 0.0;
        }
        segment.add(idxStart,new Double(result));
      } else {
        // Else skip this segment of the op
        idxStart = idx;
      }
    }
  }

  /**
   * <p>Evaluates a math expression</p>
   *
   * <p>
   * This evaluates this MathExpression for a given specific set of variables.
   * The variables map can contain either Number objects or String objects.
   * If it contains String objects the strings will be parsed into numeric
   * values.  Anything else or an invalid numeric string will evaluate to 0.
   * </p>
   *
   * @param variables Map containing variable values
   * @throws MathExpressionException Math expression was not valid
   * @throws ArithmeticException An arithmatic error (e.g. division by zero) occurred
   * @return double Result of evaluation
   */
  public double evaluate(Map variables)
    throws MathExpressionException,ArithmeticException
  {
    ArrayList vt = (ArrayList)compiledExpression.clone();
    for(int i=0;i<orderOfOperations.length;i++)
      __evaluate(orderOfOperations[i],vt,variables);
    return getResult(vt,variables);
  }
}
