package com.generalnegentropics.archis.universe;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

/**
 * <p>Interface for classes providing a reward function.</p>
 *
 * <p>
 * A reward function provides a reward to cells that provide a certain
 * output when given a certain input.  This is different from a 'fitness
 * function' in what I refer to as 'theistic' genetic programming implementations
 * in that good performance in the reward function is not a requirement for
 * survival.  Instead, the reward function should simply reward organisms that
 * provide good output.
 * </p>
 *
 * <p>
 * In nature, photosynthesis is analogous to a reward function.  Plants solve
 * the problem of capturing photons and are rewarded with energy.  In this
 * simulator, the reward function can be used to give the entire simulation a
 * problem to solve in order to measure how well it evolves.  A reward function
 * can also be a means of linking the simulator to some practical application of
 * machine learning, as can be seen in StockMarketRewardFunction.
 * </p>
 *
 * <p>
 * A reward function at the moment is just an environmental element with some
 * statistics gathering methods.
 * </p>
 *
 * @author Adam Ierymenko
 * @version 2.0
 */

public interface RewardFunction extends Condition,IOHandler
{
}
