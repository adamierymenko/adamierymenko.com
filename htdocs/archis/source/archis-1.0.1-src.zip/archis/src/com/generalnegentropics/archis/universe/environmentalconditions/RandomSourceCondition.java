package com.generalnegentropics.archis.universe.environmentalconditions;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

import java.util.*;
import com.generalnegentropics.archis.universe.EnvironmentalCondition;
import com.generalnegentropics.archis.universe.ConditionExpirationException;
import com.generalnegentropics.archis.utils.RandomIntegerInput;
import com.generalnegentropics.archis.life.Cell;
import com.generalnegentropics.archis.universe.Universe;
import com.generalnegentropics.archis.Simulation;

/**
 * An environmental condition that gives all cells a source of random numbers
 * on channel 1.
 *
 * @author Adam Ierymenko
 * @version 1.0
 */

public class RandomSourceCondition implements EnvironmentalCondition
{
  /**
   * Description of condition
   */
  public static final String CONDITION_DESCRIPTION = "Provides cells with a source of random numbers.";

  private Universe universe;
  private RandomIntegerInput rii;

  public void init(Universe universe,Simulation simulation)
  {
    this.universe = universe;
    rii = new RandomIntegerInput(simulation.randomSource());
    universe.assignChannel(1,this);
  }

  public Map getParameters()
  {
    return Collections.EMPTY_MAP;
  }

  public Object getParameter(String name)
  {
    return null;
  }

  public void setParameter(String name,Object value)
  {
  }

  public void destroy()
  {
    universe.unassignChannel(1);
  }

  public String getChannelDescription(int channel)
  {
    if (channel == 1)
      return "Random number source for cells";
    return null;
  }

  public void preTickNotify()
    throws ConditionExpirationException
  {
  }

  public void postTickNotify()
    throws ConditionExpirationException
  {
  }

  public void postTickProcessCells(List cells)
  {
  }

  public boolean newCellNotify(Cell parent, Cell newCell)
  {
    return true;
  }

  public void initCellNotify(Cell cell)
  {
  }

  public void deathNotify(Cell deadCell, String reason)
  {
  }

  public void preExecutionNotify(Cell l)
  {
    l.setInput(1,rii);
  }

  public void evaluateOutput(Cell l, int channel, int value)
  {
  }
}
