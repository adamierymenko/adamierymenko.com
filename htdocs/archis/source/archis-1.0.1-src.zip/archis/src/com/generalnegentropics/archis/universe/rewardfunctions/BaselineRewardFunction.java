package com.generalnegentropics.archis.universe.rewardfunctions;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

import java.util.*;
import com.generalnegentropics.archis.*;
import com.generalnegentropics.archis.life.*;
import com.generalnegentropics.archis.universe.*;

/**
 * Maintains a certain level of living cell energy in the universe by
 * rewarding all cells equally.
 *
 * @author Adam Ierymenko
 * @version 1.0
 */

public class BaselineRewardFunction implements RewardFunction
{
  /**
   * Description of condition
   */
  public static final String CONDITION_DESCRIPTION = "Distributes one point to each cell per tick.";

  private Universe universe;
  private Simulation simulation;

  /**
   * Constructs a new baseline reward function
   */
  public BaselineRewardFunction()
  {
  }

  public Map getParameters()
  {
    return Collections.EMPTY_MAP;
  }

  public Object getParameter(String name)
  {
    return null;
  }

  public void setParameter(String name,Object value)
  {
  }

  public String getChannelDescription(int channel)
  {
    return null;
  }

  public boolean newCellNotify(Cell parent, Cell newCell)
  {
    return true;
  }

  public void initCellNotify(Cell cell)
  {
  }

  public void deathNotify(Cell deadCell, String reason)
  {
  }

  public void preExecutionNotify(Cell l)
  {
    if (l.alive())
      l.incPoints(1);
  }

  public void evaluateOutput(Cell l,int channel,int value)
  {
  }

  public void init(Universe universe,Simulation simulation)
  {
    this.universe = universe;
    this.simulation = simulation;
  }

  public void destroy()
  {
  }

  public void preTickNotify()
    throws ConditionExpirationException
  {
  }

  public void postTickNotify()
    throws ConditionExpirationException
  {
  }

  public void postTickProcessCells(List cells)
  {
  }
}
