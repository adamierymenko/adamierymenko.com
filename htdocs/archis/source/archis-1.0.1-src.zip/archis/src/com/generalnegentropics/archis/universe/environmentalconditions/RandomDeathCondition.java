package com.generalnegentropics.archis.universe.environmentalconditions;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

import java.util.*;
import com.generalnegentropics.archis.universe.*;
import com.generalnegentropics.archis.life.*;
import com.generalnegentropics.archis.utils.*;
import com.generalnegentropics.archis.*;

/**
 * A condition that randomly kills cells
 *
 * @author Adam Ierymenko
 * @version 2.0
 */

public class RandomDeathCondition implements EnvironmentalCondition
{
  /**
   * Description of condition
   */
  public static final String CONDITION_DESCRIPTION = "Randomly kills cells with a given probability.";

  private static Map parameters;
  static
  {
    parameters = new HashMap();
    parameters.put("randomDeathProbability","Probability of random death per cell per tick");
    parameters = Collections.unmodifiableMap(parameters);
  }

  private Simulation simulation;
  private RandomSource randomSource;
  private float randomDeathProbability;
  private volatile int randomDeathsThisTick;
  private volatile long totalRandomDeaths;

  /**
   * Constructs a new random death condition
   */
  public RandomDeathCondition()
  {
    randomDeathProbability = 0.005F;
    randomDeathsThisTick = 0;
    totalRandomDeaths = 0L;
  }

  public Map getParameters()
  {
    return parameters;
  }

  public Object getParameter(String name)
  {
    if ("randomDeathProbability".equals(name))
      return new Float(randomDeathProbability);
    return null;
  }

  public void setParameter(String name,Object value)
  {
    if ("randomDeathProbability".equals(name))
      randomDeathProbability = ParameterValueParser.getFloat(value);
  }

  public void init(Universe universe,Simulation simulation)
  {
    this.simulation = simulation;
    randomSource = simulation.randomSource();
  }

  public void destroy()
  {
  }

  public void preTickNotify()
    throws ConditionExpirationException
  {
    randomDeathsThisTick = 0;
  }

  public void postTickNotify()
    throws ConditionExpirationException
  {
    simulation.setStatistic("RD1 RandomDeathCondition.cellsKilled",randomDeathsThisTick);
    simulation.setStatistic("RD2 RandomDeathCondition.totalCellsKilled",totalRandomDeaths);
  }

  public void postTickProcessCells(List cells)
  {
  }

  public void preExecutionNotify(Cell cell)
  {
    if (randomSource.randomEvent(randomDeathProbability)) {
      ++randomDeathsThisTick;
      ++totalRandomDeaths;
      cell.kill(false,"RandomDeathCondition");
    }
  }

  public void evaluateOutput(Cell l, int channel, int value)
  {
  }

  public void deathNotify(Cell deadCell,String reason)
  {
  }

  public boolean newCellNotify(Cell parent,Cell newCell)
  {
    return true;
  }

  public void initCellNotify(Cell cell)
  {
  }

  public String getChannelDescription(int channel)
  {
    return null;
  }
}

