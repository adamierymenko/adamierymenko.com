package com.generalnegentropics.archis.utils;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

/**
 * A control random source that is not random; it simply increments the seed
 *
 * @author Adam Ierymenko
 * @version 1.0
 */

public class NonRandomRandomSource implements RandomSource
{
  private long s;
  private static char[] rclist = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".toCharArray();

  /**
   * Constructs a new MersenneTwisterRandomSource
   *
   * @param seed Seed value
   */
  public NonRandomRandomSource(long seed)
  {
    s = seed;
  }

  public synchronized int randomInteger()
  {
    return (int)++s;
  }

  public synchronized int randomPositiveInteger()
  {
    return Math.abs((int)++s);
  }

  public synchronized long randomLong()
  {
    return ++s;
  }

  public synchronized long randomPositiveLong()
  {
    return Math.abs(++s);
  }

  public synchronized char randomChar()
  {
    return (char)++s;
  }

  public char randomLetterOrNumber()
  {
    return rclist[randomPositiveInteger() % rclist.length];
  }

  public synchronized byte randomByte()
  {
    return (byte)++s;
  }

  public synchronized short randomShort()
  {
    return (short)++s;
  }

  public synchronized boolean randomBoolean()
  {
    return (((s & 1L) == 0L) ? true : false);
  }

  public boolean randomEvent(float probability)
  {
    return ((s % (long)Math.round(10.0F / probability)) <= 10L);
  }

  public boolean randomEvent(double probability)
  {
    return ((s % (long)Math.round(10.0 / probability)) <= 10L);
  }

  public synchronized double randomDouble()
  {
    double blah = (double)++s;
    if (blah < 0.0)
      blah = -blah;
    while (blah > 1.0)
      blah /= 10.0;
    int n = (int)s % 7;
    for(int i=0;i<n;i++)
      blah /= 10.0;
    return blah;
  }

  public float randomFloat()
  {
    return (float)randomDouble();
  }
}
