package com.generalnegentropics.archis.universe.rewardfunctions;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

import com.generalnegentropics.archis.*;
import com.generalnegentropics.archis.life.*;
import com.generalnegentropics.archis.universe.*;
import java.util.*;

public class FibonacciSequenceRewardFunction implements RewardFunction
{
  /**
   * Description of condition
   */
  public static final String CONDITION_DESCRIPTION = "Rewards cells 10 points per correct fibonacci number output to channel 16.";

  // Cell info field for it's current output sequence length and previous answer
  private static final Object CELL_INFO_FSSEQLEN = new Integer(0x22220001);

  // Universe and simulation data
  private Universe universe;
  private Simulation simulation;

  // Number of total right answers that have been given
  private long totalRightAnswers;

  // Number of cells that have ever answered
  private long totalScorers;

  // Counter to maintain what tick a score is for
  private int counter;

  // Highest score this run
  private int highScore;

  /**
   * Constructs a new baseline reward function
   */
  public FibonacciSequenceRewardFunction()
  {
    totalRightAnswers = 0L;
    counter = 0;
    highScore = 0;
  }

  public Map getParameters()
  {
    return Collections.EMPTY_MAP;
  }

  public Object getParameter(String name)
  {
    return null;
  }

  public void setParameter(String name,Object value)
  {
  }

  public String getChannelDescription(int channel)
  {
    if (channel == 16)
      return "Cell fibonacci sequence output";
    return null;
  }

  public boolean newCellNotify(Cell parent, Cell newCell)
  {
    return true;
  }

  public void initCellNotify(Cell cell)
  {
  }

  public void deathNotify(Cell deadCell, String reason)
  {
  }

  public void preExecutionNotify(Cell l)
  {
  }

  public void evaluateOutput(Cell l,int channel,int value)
  {
    if (channel == 16) {
      // Get score from cell and add score field if not present
      int[] sl = (int[])l.getMetaInfo(CELL_INFO_FSSEQLEN);
      if (sl == null) {
        sl = new int[4];
        // [0] - counter
        // [1] - sequence length
        // [2] - last value
        // [3] - value before that
        l.setMetaInfo(CELL_INFO_FSSEQLEN,sl);
      }

      // Zero score for each new counter tick
      if (sl[0] != counter) {
        sl[0] = counter;
        sl[1] = 0;
        sl[2] = 0;
        sl[3] = 0;
      }

      // Increment score and update stats if this is another right answer
      if (sl[1] >= 0) {
        if ((sl[2] + sl[3]) == value) {
          if (sl[1] == 0)
            sl[2] = 1;
          else if (sl[1] > 1) {
            sl[3] = sl[2];
            sl[2] = value;
          }
          ++sl[1];
          if (sl[1] > highScore)
            highScore = sl[1];
          ++totalRightAnswers;
        } else sl[1] = -1;
      }
    }
  }

  public void init(Universe universe,Simulation simulation)
  {
    this.universe = universe;
    this.simulation = simulation;
    universe.assignChannel(16,this);
  }

  public void destroy()
  {
    universe.unassignChannel(16);
  }

  public void preTickNotify()
    throws ConditionExpirationException
  {
    ++counter;
    totalRightAnswers = 0L;
    highScore = 0;
  }

  public void postTickNotify()
    throws ConditionExpirationException
  {
    if (totalRightAnswers > 0L) {
      int highScorers = 0;
      int scorers = 0;

      for (Iterator i = universe.populationIterator();i.hasNext();) {
        Cell c = (Cell)i.next();
        int[] sl = (int[])c.getMetaInfo(CELL_INFO_FSSEQLEN);
        if (sl != null) {
          if ((sl[0] == counter) && (sl[1] > 0)) {
            c.incPoints(sl[1]*10);
            ++scorers;
            if (sl[1] == highScore)
              ++highScorers;
          }
        }
      }
      totalScorers += (long)scorers;

      simulation.setStatistic("FS1 FibonacciSequenceRewardFunction.highScore",((scorers == 0) ? 0 : highScore));
      simulation.setStatistic("FS2 FibonacciSequenceRewardFunction.highScorers",highScorers);
      simulation.setStatistic("FS3 FibonacciSequenceRewardFunction.scorers",scorers);
    } else {
      simulation.setStatistic("FS1 FibonacciSequenceRewardFunction.highScore",0);
      simulation.setStatistic("FS2 FibonacciSequenceRewardFunction.highScorers",0);
      simulation.setStatistic("FS3 FibonacciSequenceRewardFunction.scorers",0);
    }
    simulation.setStatistic("FS4 FibonacciSequenceRewardFunction.totalScorers",totalScorers);
  }

  public void postTickProcessCells(List cells)
  {
  }
}
