package com.generalnegentropics.archis.gui.conditions;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.*;
import java.text.NumberFormat;
import java.text.DecimalFormat;
import com.generalnegentropics.archis.*;
import com.generalnegentropics.archis.universe.environmentalconditions.*;
import com.generalnegentropics.archis.life.*;
import com.generalnegentropics.archis.gui.*;

public class Landscape2DWindow extends JFrame
{
  public Landscape2D landscape;
  public Object browser;
  private boolean mouseInViewPanel,mousePressedInViewPanel;
  private Cell selectedCell;
  private String simulationName;
  private Simulation simulation;
  private ScrollerThread scrollerThread;
  private boolean northPressed,southPressed,eastPressed,westPressed;
  private NumberFormat probabilityFormat;
  Icon UP_ICON = new ImageIcon(this.getClass().getClassLoader().getResource("com/generalnegentropics/archis/resources/Up24.gif"));
  Icon DOWN_ICON = new ImageIcon(this.getClass().getClassLoader().getResource("com/generalnegentropics/archis/resources/Down24.gif"));
  Icon LEFT_ICON = new ImageIcon(this.getClass().getClassLoader().getResource("com/generalnegentropics/archis/resources/Back24.gif"));
  Icon RIGHT_ICON = new ImageIcon(this.getClass().getClassLoader().getResource("com/generalnegentropics/archis/resources/Forward24.gif"));
  JPanel contentPane;
  GridBagLayout gridBagLayout1 = new GridBagLayout();
  JPanel viewPanel = new JPanel();
  JPanel navigatePanel = new JPanel();
  BorderLayout borderLayout1 = new BorderLayout();
  GridBagLayout gridBagLayout2 = new GridBagLayout();
  JPanel navButtonPanel = new JPanel();
  BorderLayout borderLayout2 = new BorderLayout();
  JButton westButton = new JButton();
  JButton southButton = new JButton();
  JButton eastButton = new JButton();
  JButton northButton = new JButton();
  JPanel navZoomAndInfoPanel = new JPanel();
  GridBagLayout gridBagLayout3 = new GridBagLayout();
  JSlider zoomSlider = new JSlider();
  JLabel jLabel1 = new JLabel();
  JLabel locationLabel = new JLabel();
  JLabel jLabel3 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JLabel pointerLocationLabel = new JLabel();
  JLabel jLabel4 = new JLabel();
  JLabel selectedCellLabel = new JLabel();
  JTabbedPane jTabbedPane1 = new JTabbedPane();
  JButton examineGenomeButton = new JButton();
  JPanel settingsPanel = new JPanel();
  GridBagLayout gridBagLayout4 = new GridBagLayout();
  TitledBorder titledBorder2;
  GridBagLayout gridBagLayout5 = new GridBagLayout();
  JLabel jLabel5 = new JLabel();
  JLabel jLabel6 = new JLabel();
  JLabel jLabel8 = new JLabel();
  JLabel jLabel9 = new JLabel();
  JPanel jPanel1 = new JPanel();
  JLabel jLabel7 = new JLabel();
  GridBagLayout gridBagLayout6 = new GridBagLayout();
  JTextField maintainEnergyTextField = new JTextField();
  JPanel settingsButtonPanel = new JPanel();
  JButton bulkAddEnergyButton = new JButton();
  GridBagLayout gridBagLayout7 = new GridBagLayout();
  JButton jButton3 = new JButton();
  ButtonGroup repaintButtonGroup = new ButtonGroup();
  JLabel jLabel11 = new JLabel();
  JTextField energyDensityTextField = new JTextField();
  private JPanel cspOptionsPanel = new JPanel();
  private JPanel positiveCspPanel = new JPanel();
  private JPanel zeroCspPanel = new JPanel();
  private JPanel negativeCspPanel = new JPanel();
  private TitledBorder negativeCspTitle;
  private TitledBorder zeroCspTitle;
  private TitledBorder positiveCspTitle;
  private GridLayout gridLayout1 = new GridLayout();
  private GridBagLayout gridBagLayout8 = new GridBagLayout();
  private GridBagLayout gridBagLayout9 = new GridBagLayout();
  private GridBagLayout gridBagLayout10 = new GridBagLayout();
  private JCheckBox cspNegativeCommunicationCheckbox = new JCheckBox();
  private JCheckBox cspNegativeGenomeTransferCheckbox = new JCheckBox();
  private JCheckBox cspNegativeEnergyTransferCheckbox = new JCheckBox();
  private JCheckBox cspNegativeAdhesionCheckbox = new JCheckBox();
  private JCheckBox cspZeroAdhesionCheckbox = new JCheckBox();
  private JCheckBox cspZeroEnergyTransferCheckbox = new JCheckBox();
  private JCheckBox cspZeroGenomeTransferCheckbox = new JCheckBox();
  private JCheckBox cspZeroCommunicationCheckbox = new JCheckBox();
  private JCheckBox cspPositiveAdhesionCheckbox = new JCheckBox();
  private JCheckBox cspPositiveEnergyTransferCheckbox = new JCheckBox();
  private JCheckBox cspPositiveGenomeTransferCheckbox = new JCheckBox();
  private JCheckBox cspPositiveCommunicationCheckbox = new JCheckBox();
  private JLabel jLabel10 = new JLabel();
  private JTextField maxGenomeTransferTextField = new JTextField();

  private class ScrollerThread extends Thread
  {
    public boolean die;

    public ScrollerThread()
    {
      super("Landscape2DWindow Scroller Thread");
      super.setPriority(Thread.MIN_PRIORITY);
      super.setDaemon(true);
      die = false;
      super.start();
    }

    public void run()
    {
      for(;;) {
        try {
          sleep(100L);
        } catch (Throwable t) {}

        if (die)
          return;

        if (northPressed)
          ((Landscape2DBrowserJComponent)browser).scrollY(-10);

        if (southPressed)
          ((Landscape2DBrowserJComponent)browser).scrollY(10);

        if (eastPressed)
          ((Landscape2DBrowserJComponent)browser).scrollX(10);

        if (westPressed)
          ((Landscape2DBrowserJComponent)browser).scrollX(-10);

        if (northPressed||southPressed||eastPressed||westPressed)
          locationLabel.setText(Integer.toString(((Landscape2DBrowserJComponent)browser).getTopX())+","+Integer.toString(((Landscape2DBrowserJComponent)browser).getTopY()));
      }
    }
  }

  public Landscape2DWindow(Simulation simulation,Landscape2D landscape)
  {
    probabilityFormat = DecimalFormat.getNumberInstance();
    probabilityFormat.setMinimumFractionDigits(1);
    probabilityFormat.setMaximumFractionDigits(6);
    probabilityFormat.setMinimumIntegerDigits(1);
    probabilityFormat.setMaximumIntegerDigits(16384);
    probabilityFormat.setGroupingUsed(false);

    simulation.newFrameNotify(this);
    this.landscape = landscape;
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }

    this.setSize(660,640);
    Dimension ss = this.getToolkit().getScreenSize();
    this.setLocation((ss.width/2)-(this.getWidth()/2),(ss.height/2)-(this.getHeight()/2));
    this.setIconImage(Archis.ICON);
    northPressed = southPressed = eastPressed = westPressed = false;
    scrollerThread = new ScrollerThread();

    simulationName = simulation.getName();
    this.simulation = simulation;
    this.setTitle("["+simulationName+"] Landscape2D");
    browser = new Landscape2DBrowserJComponent(simulation,landscape,1);
    viewPanel.add((Component)browser,BorderLayout.CENTER);
    zoomSlider.setValue(1);
    viewPanel.setCursor(Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR));
    mouseInViewPanel = false;
    mousePressedInViewPanel = false;
    selectedCell = null;
    ((JComponent)browser).addMouseMotionListener(new browser_viewPanel_mouseMotionAdapter(this));
    ((JComponent)browser).addMouseListener(new browser_viewPanel_mouseAdapter(this));
    maintainEnergyTextField.setText(Long.toString(landscape.getMaintainEnergy()));
    energyDensityTextField.setText(Long.toString(landscape.getEnergyDensity()));
    updateCspCheckboxes();
    maxGenomeTransferTextField.setText(Integer.toString(landscape.getMaxGeneTransfer()));
    if (!landscape.isInitialized())
      new InitializeLandscapeWindow(simulation,landscape,(JComponent)browser).setVisible(true);
  }

  private void jbInit() throws Exception {
    contentPane = (JPanel)this.getContentPane();
    titledBorder2 = new TitledBorder("");
    negativeCspTitle = new TitledBorder("");
    zeroCspTitle = new TitledBorder("");
    positiveCspTitle = new TitledBorder("");
    contentPane.setLayout(gridBagLayout1);
    this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
    this.addWindowListener(new Landscape2DWindow_this_windowAdapter(this));
    viewPanel.setBorder(BorderFactory.createEtchedBorder());
    viewPanel.setRequestFocusEnabled(true);
    viewPanel.setLayout(borderLayout1);
    navigatePanel.setBorder(BorderFactory.createEtchedBorder());
    navigatePanel.setLayout(gridBagLayout2);
    navButtonPanel.setLayout(borderLayout2);
    northButton.setIcon(UP_ICON);
    northButton.addMouseListener(new Landscape2DWindow_northButton_mouseAdapter(this));
    southButton.setIcon(DOWN_ICON);
    southButton.addMouseListener(new Landscape2DWindow_southButton_mouseAdapter(this));
    eastButton.setIcon(RIGHT_ICON);
    eastButton.addMouseListener(new Landscape2DWindow_eastButton_mouseAdapter(this));
    westButton.setIcon(LEFT_ICON);
    westButton.addMouseListener(new Landscape2DWindow_westButton_mouseAdapter(this));
    navZoomAndInfoPanel.setLayout(gridBagLayout3);
    zoomSlider.setOrientation(JSlider.HORIZONTAL);
    zoomSlider.setMajorTickSpacing(1);
    zoomSlider.setMaximum(4);
    zoomSlider.setMinimum(1);
    zoomSlider.setMinorTickSpacing(1);
    zoomSlider.setPaintLabels(false);
    zoomSlider.setPaintTicks(true);
    zoomSlider.setPaintTrack(true);
    zoomSlider.addKeyListener(new Landscape2DWindow_zoomSlider_keyAdapter(this));
    zoomSlider.addMouseListener(new Landscape2DWindow_zoomSlider_mouseAdapter(this));
    jLabel1.setHorizontalAlignment(SwingConstants.CENTER);
    jLabel1.setHorizontalTextPosition(SwingConstants.CENTER);
    jLabel1.setText("Zoom");
    locationLabel.setFont(new java.awt.Font("Dialog", 1, 14));
    locationLabel.setText("0,0");
    jLabel3.setFont(new java.awt.Font("Dialog", 0, 14));
    jLabel3.setHorizontalAlignment(SwingConstants.RIGHT);
    jLabel3.setHorizontalTextPosition(SwingConstants.RIGHT);
    jLabel3.setText("Window:");
    jLabel2.setFont(new java.awt.Font("Dialog", 0, 14));
    jLabel2.setHorizontalAlignment(SwingConstants.RIGHT);
    jLabel2.setHorizontalTextPosition(SwingConstants.RIGHT);
    jLabel2.setText("Cursor:");
    pointerLocationLabel.setFont(new java.awt.Font("Dialog", 1, 14));
    pointerLocationLabel.setText("-,-");
    jLabel4.setFont(new java.awt.Font("Dialog", 0, 14));
    jLabel4.setHorizontalAlignment(SwingConstants.RIGHT);
    jLabel4.setHorizontalTextPosition(SwingConstants.RIGHT);
    jLabel4.setText("Selected Cell:");
    selectedCellLabel.setFont(new java.awt.Font("Dialog", 1, 14));
    selectedCellLabel.setRequestFocusEnabled(true);
    selectedCellLabel.setHorizontalAlignment(SwingConstants.LEADING);
    selectedCellLabel.setText("none");
    examineGenomeButton.setFont(new java.awt.Font("Dialog", 0, 10));
    examineGenomeButton.setText("Examine Cell");
    examineGenomeButton.addActionListener(new Landscape2DWindow_examineGenomeButton_actionAdapter(this));
    examineGenomeButton.setEnabled(false);
    settingsPanel.setLayout(gridBagLayout4);
    titledBorder2.setTitle("Garden of Eden");
    jLabel5.setHorizontalAlignment(SwingConstants.RIGHT);
    jLabel5.setHorizontalTextPosition(SwingConstants.RIGHT);
    jLabel5.setText("Center:");
    jLabel6.setHorizontalAlignment(SwingConstants.RIGHT);
    jLabel6.setHorizontalTextPosition(SwingConstants.RIGHT);
    jLabel6.setText("Radius:");
    jLabel8.setText("X");
    jLabel9.setText("Y");
    jPanel1.setBorder(BorderFactory.createEtchedBorder());
    jPanel1.setLayout(gridBagLayout6);
    jLabel7.setHorizontalAlignment(SwingConstants.RIGHT);
    jLabel7.setHorizontalTextPosition(SwingConstants.RIGHT);
    jLabel7.setText("Maintain Energy in Universe:");
    maintainEnergyTextField.setText("0");
    maintainEnergyTextField.addKeyListener(new Landscape2DWindow_maintainEnergyTextField_keyAdapter(this));
    bulkAddEnergyButton.setText("Bulk Add Energy");
    bulkAddEnergyButton.addActionListener(new Landscape2DWindow_bulkAddEnergyButton_actionAdapter(this));
    settingsButtonPanel.setLayout(gridBagLayout7);
    jButton3.setText("Repaint Now");
    jButton3.addActionListener(new Landscape2DWindow_jButton3_actionAdapter(this));
    jLabel11.setHorizontalAlignment(SwingConstants.RIGHT);
    jLabel11.setHorizontalTextPosition(SwingConstants.RIGHT);
    jLabel11.setText("Energy Density:");
    energyDensityTextField.setText("0");
    energyDensityTextField.addKeyListener(new Landscape2DWindow_energyDensityTextField_keyAdapter(this));
    negativeCspPanel.setBorder(negativeCspTitle);
    negativeCspPanel.setLayout(gridBagLayout8);
    negativeCspTitle.setTitle("Negative Cell Surface Proteins");
    zeroCspPanel.setBorder(zeroCspTitle);
    zeroCspPanel.setDebugGraphicsOptions(0);
    zeroCspPanel.setLayout(gridBagLayout9);
    zeroCspTitle.setTitle("Zero Cell Surface Proteins");
    positiveCspTitle.setTitle("Positive Cell Surface Proteins");
    positiveCspPanel.setBorder(positiveCspTitle);
    positiveCspPanel.setLayout(gridBagLayout10);
    cspOptionsPanel.setLayout(gridLayout1);
    cspNegativeCommunicationCheckbox.setText("Communication");
    cspNegativeCommunicationCheckbox.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        cspNegativeCommunicationCheckbox_actionPerformed(e);
      }
    });
    cspNegativeGenomeTransferCheckbox.setText("Genome Transfer");
    cspNegativeGenomeTransferCheckbox.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        cspNegativeGenomeTransferCheckbox_actionPerformed(e);
      }
    });
    cspNegativeEnergyTransferCheckbox.setText("Energy Transfer");
    cspNegativeEnergyTransferCheckbox.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        cspNegativeEnergyTransferCheckbox_actionPerformed(e);
      }
    });
    cspNegativeAdhesionCheckbox.setText("Adhesion");
    cspNegativeAdhesionCheckbox.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        cspNegativeAdhesionCheckbox_actionPerformed(e);
      }
    });
    cspZeroAdhesionCheckbox.setText("Adhesion");
    cspZeroAdhesionCheckbox.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        cspZeroAdhesionCheckbox_actionPerformed(e);
      }
    });
    cspZeroEnergyTransferCheckbox.setText("Energy Transfer");
    cspZeroEnergyTransferCheckbox.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        cspZeroEnergyTransferCheckbox_actionPerformed(e);
      }
    });
    cspZeroGenomeTransferCheckbox.setText("Genome Transfer");
    cspZeroGenomeTransferCheckbox.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        cspZeroGenomeTransferCheckbox_actionPerformed(e);
      }
    });
    cspZeroCommunicationCheckbox.setText("Communication");
    cspZeroCommunicationCheckbox.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        cspZeroCommunicationCheckbox_actionPerformed(e);
      }
    });
    cspPositiveAdhesionCheckbox.setText("Adhesion");
    cspPositiveAdhesionCheckbox.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        cspPositiveAdhesionCheckbox_actionPerformed(e);
      }
    });
    cspPositiveEnergyTransferCheckbox.setText("Energy Transfer");
    cspPositiveEnergyTransferCheckbox.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        cspPositiveEnergyTransferCheckbox_actionPerformed(e);
      }
    });
    cspPositiveGenomeTransferCheckbox.setText("Genome Transfer");
    cspPositiveGenomeTransferCheckbox.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        cspPositiveGenomeTransferCheckbox_actionPerformed(e);
      }
    });
    cspPositiveCommunicationCheckbox.setText("Communication");
    cspPositiveCommunicationCheckbox.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        cspPositiveCommunicationCheckbox_actionPerformed(e);
      }
    });
    jLabel10.setText("Max Genome Transfer:");
    maxGenomeTransferTextField.setText("0");
    maxGenomeTransferTextField.addKeyListener(new java.awt.event.KeyAdapter() {
      public void keyReleased(KeyEvent e) {
        maxGenomeTransferTextField_keyReleased(e);
      }
    });
    contentPane.add(viewPanel,        new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(2, 2, 0, 2), 0, 0));
    jTabbedPane1.add(navigatePanel,  "Navigate");
    navigatePanel.add(navButtonPanel,        new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(5, 5, 0, 0), 0, 0));
    navButtonPanel.add(eastButton,  BorderLayout.EAST);
    navButtonPanel.add(southButton, BorderLayout.SOUTH);
    navButtonPanel.add(westButton, BorderLayout.WEST);
    navButtonPanel.add(northButton, BorderLayout.NORTH);
    navigatePanel.add(navZoomAndInfoPanel,        new GridBagConstraints(1, 0, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 5, 0, 5), 0, 0));
    navZoomAndInfoPanel.add(zoomSlider,                               new GridBagConstraints(2, 1, 1, 2, 0.5, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, 2, 2, 2), 0, 0));
    navZoomAndInfoPanel.add(locationLabel,                        new GridBagConstraints(1, 0, 1, 1, 1.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(2, 2, 0, 2), 0, 0));
    navZoomAndInfoPanel.add(jLabel3,                    new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, 2, 0, 2), 0, 0));
    navZoomAndInfoPanel.add(jLabel2,                     new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, 2, 0, 2), 0, 0));
    navZoomAndInfoPanel.add(pointerLocationLabel,                              new GridBagConstraints(1, 1, 1, 1, 1.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 2, 0, 2), 0, 0));
    navZoomAndInfoPanel.add(selectedCellLabel,                      new GridBagConstraints(1, 2, 1, 1, 1.0, 0.0
            ,GridBagConstraints.NORTHWEST, GridBagConstraints.NONE, new Insets(0, 2, 2, 2), 0, 0));
    navZoomAndInfoPanel.add(jLabel4,            new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.NORTHEAST, GridBagConstraints.HORIZONTAL, new Insets(0, 2, 2, 2), 0, 0));
    navZoomAndInfoPanel.add(jLabel1,  new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.SOUTH, GridBagConstraints.HORIZONTAL, new Insets(4, 3, 0, 1), 0, 0));
    navigatePanel.add(examineGenomeButton,    new GridBagConstraints(1, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(2, 5, 2, 5), 0, 0));
    jTabbedPane1.add(settingsPanel,  "Settings");
    contentPane.add(jTabbedPane1,   new GridBagConstraints(0, 1, 1, 1, 1.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(2, 2, 2, 2), 0, 0));
    settingsPanel.add(jPanel1,  new GridBagConstraints(0, 0, 1, 1, 1.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(2, 2, 2, 2), 0, 0));
    jPanel1.add(jLabel7,             new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 0, 5), 0, 0));
    jPanel1.add(maintainEnergyTextField,             new GridBagConstraints(1, 0, 1, 1, 1.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 0, 0, 5), 0, 0));
    jPanel1.add(settingsButtonPanel,             new GridBagConstraints(0, 2, 4, 1, 1.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 5, 5, 5), 0, 0));
    settingsButtonPanel.add(bulkAddEnergyButton,              new GridBagConstraints(4, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 5, 0, 0), 0, 0));
    settingsButtonPanel.add(jButton3,      new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    jPanel1.add(jLabel11,         new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(2, 5, 2, 5), 0, 0));
    jPanel1.add(energyDensityTextField,         new GridBagConstraints(3, 0, 1, 1, 1.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(2, 0, 2, 5), 0, 0));
    jPanel1.add(cspOptionsPanel,        new GridBagConstraints(0, 1, 4, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 2, 2, 2), 0, 0));
    cspOptionsPanel.add(negativeCspPanel, null);
    negativeCspPanel.add(cspNegativeCommunicationCheckbox,        new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
    negativeCspPanel.add(cspNegativeGenomeTransferCheckbox,      new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
    negativeCspPanel.add(cspNegativeEnergyTransferCheckbox,    new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
    negativeCspPanel.add(cspNegativeAdhesionCheckbox,  new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
    cspOptionsPanel.add(zeroCspPanel, null);
    zeroCspPanel.add(cspZeroAdhesionCheckbox,  new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
    zeroCspPanel.add(cspZeroEnergyTransferCheckbox,  new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
    zeroCspPanel.add(cspZeroGenomeTransferCheckbox,  new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
    zeroCspPanel.add(cspZeroCommunicationCheckbox,  new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
    cspOptionsPanel.add(positiveCspPanel, null);
    positiveCspPanel.add(cspPositiveAdhesionCheckbox,   new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
    positiveCspPanel.add(cspPositiveEnergyTransferCheckbox,   new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
    positiveCspPanel.add(cspPositiveGenomeTransferCheckbox,   new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
    positiveCspPanel.add(cspPositiveCommunicationCheckbox,   new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
    settingsButtonPanel.add(jLabel10,    new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 2, 0, 0), 0, 0));
    settingsButtonPanel.add(maxGenomeTransferTextField,    new GridBagConstraints(1, 0, 1, 1, 1.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, 5, 0, 15), 0, 0));
  }

  protected void finalize()
    throws Throwable
  {
    try {
      scrollerThread.die = true;
    } catch (Throwable t) {}
  }

  void zoomSlider_mouseReleased(MouseEvent e) {
    ((Landscape2DBrowserJComponent)browser).setMagnification(zoomSlider.getValue());
  }

  void zoomSlider_keyReleased(KeyEvent e) {
    ((Landscape2DBrowserJComponent)browser).setMagnification(zoomSlider.getValue());
  }

  void examineGenomeButton_actionPerformed(ActionEvent e) {
    if (selectedCell != null)
      new ExamineGenomeWindow(simulation,selectedCell,"["+simulationName+"] Cell #"+selectedCell.id()).setVisible(true);
  }

  void browser_mouseEntered(MouseEvent e) {
    mouseInViewPanel = true;
    pointerLocationLabel.setText(Integer.toString(((Landscape2DBrowserJComponent)browser).getMouseX())+","+Integer.toString(((Landscape2DBrowserJComponent)browser).getMouseY()));
  }

  void browser_mouseExited(MouseEvent e) {
    mouseInViewPanel = false;
    pointerLocationLabel.setText("-,-");
  }

  void browser_mouseMoved(MouseEvent e) {
    if (mouseInViewPanel)
      pointerLocationLabel.setText(Integer.toString(((Landscape2DBrowserJComponent)browser).getMouseX())+","+Integer.toString(((Landscape2DBrowserJComponent)browser).getMouseY()));
    if (mousePressedInViewPanel) {
      selectedCell = landscape.getCell(((Landscape2DBrowserJComponent)browser).getMouseX()+((Landscape2DBrowserJComponent)browser).getTopX(),((Landscape2DBrowserJComponent)browser).getMouseY()+((Landscape2DBrowserJComponent)browser).getTopY());
      if (selectedCell == null) {
        selectedCellLabel.setText("none");
        examineGenomeButton.setEnabled(false);
      } else {
        selectedCellLabel.setText("#" + Long.toString(selectedCell.id()));
        examineGenomeButton.setEnabled(true);
      }
    }
  }

  void browser_mousePressed(MouseEvent e) {
    mousePressedInViewPanel = true;
    selectedCell = landscape.getCell(((Landscape2DBrowserJComponent)browser).getMouseX(),((Landscape2DBrowserJComponent)browser).getMouseY());
    if (selectedCell == null) {
      selectedCellLabel.setText("none");
      examineGenomeButton.setEnabled(false);
    } else {
      selectedCellLabel.setText("#" + Long.toString(selectedCell.id()));
      examineGenomeButton.setEnabled(true);
    }
  }

  void browser_mouseReleased(MouseEvent e) {
    mousePressedInViewPanel = false;
  }

  public void showInitializeWindow()
  {
    new InitializeLandscapeWindow(simulation,landscape,(JComponent)browser).setVisible(true);
  }

  void closeButton_actionPerformed(ActionEvent e) {
    scrollerThread.die = true;
    this.setVisible(false);
    this.dispose();
  }

  void bulkAddEnergyButton_actionPerformed(ActionEvent e) {
    new Landscape2DBulkAddEnergyWindow(simulation,landscape).setVisible(true);
  }

  void maintainEnergyTextField_keyReleased(KeyEvent e) {
    try {
      landscape.setMaintainEnergy(Long.parseLong(maintainEnergyTextField.getText().trim()));
    } catch (NumberFormatException ex) {
      JOptionPane.showMessageDialog(this,"Energy to Maintain Must be an Integer","Invalid Parameter",JOptionPane.ERROR_MESSAGE);
    }
  }

  void jButton3_actionPerformed(ActionEvent e) {
    // repaint now
    ((JComponent)browser).repaint();
  }

  void this_windowClosing(WindowEvent e) {
    scrollerThread.die = true;
    landscape.setObserver(null);
    this.setVisible(false);
    this.dispose();
  }

  void northButton_mousePressed(MouseEvent e) {
    northPressed = true;
    scrollerThread.interrupt();
  }

  void southButton_mousePressed(MouseEvent e) {
    southPressed = true;
    scrollerThread.interrupt();
  }

  void eastButton_mousePressed(MouseEvent e) {
    eastPressed = true;
    scrollerThread.interrupt();
  }

  void westButton_mousePressed(MouseEvent e) {
    westPressed = true;
    scrollerThread.interrupt();
  }

  void northButton_mouseReleased(MouseEvent e) {
    northPressed = false;
  }

  void southButton_mouseReleased(MouseEvent e) {
    southPressed = false;
  }

  void eastButton_mouseReleased(MouseEvent e) {
    eastPressed = false;
  }

  void westButton_mouseReleased(MouseEvent e) {
    westPressed = false;
  }

  void northButton_mouseExited(MouseEvent e) {
    northPressed = false;
  }

  void southButton_mouseExited(MouseEvent e) {
    southPressed = false;
  }

  void westButton_mouseExited(MouseEvent e) {
    westPressed = false;
  }

  void eastButton_mouseExited(MouseEvent e) {
    eastPressed = false;
  }

  void energyDensityTextField_keyReleased(KeyEvent e) {
    String v = energyDensityTextField.getText().trim();
    if (v.length() > 0) {
      try {
        landscape.setEnergyDensity(Integer.parseInt(v));
        energyDensityTextField.setText(Long.toString(landscape.getEnergyDensity()));
      } catch (NumberFormatException ex) {
        JOptionPane.showMessageDialog(this,"Value must be a real number","Invalid Value",JOptionPane.ERROR_MESSAGE);
      }
    }
  }

  void cspNegativeAdhesionCheckbox_actionPerformed(ActionEvent e) {
    landscape.cspSetNegativeCellSurfaceProteinAdhesion(cspNegativeAdhesionCheckbox.isSelected());
    updateCspCheckboxes();
  }

  void cspNegativeEnergyTransferCheckbox_actionPerformed(ActionEvent e) {
    landscape.cspSetNegativeCellSurfaceProteinEnergyTransfer(cspNegativeEnergyTransferCheckbox.isSelected());
    updateCspCheckboxes();
  }

  void cspNegativeGenomeTransferCheckbox_actionPerformed(ActionEvent e) {
    landscape.cspSetNegativeCellSurfaceProteinGenomeTransfer(cspNegativeGenomeTransferCheckbox.isSelected());
    updateCspCheckboxes();
  }

  void cspNegativeCommunicationCheckbox_actionPerformed(ActionEvent e) {
    landscape.cspSetNegativeCellSurfaceProteinCommunication(cspNegativeCommunicationCheckbox.isSelected());
    updateCspCheckboxes();
  }

  void cspZeroAdhesionCheckbox_actionPerformed(ActionEvent e) {
    landscape.cspSetZeroCellSurfaceProteinAdhesion(cspZeroAdhesionCheckbox.isSelected());
    updateCspCheckboxes();
  }

  void cspZeroEnergyTransferCheckbox_actionPerformed(ActionEvent e) {
    landscape.cspSetZeroCellSurfaceProteinEnergyTransfer(cspZeroEnergyTransferCheckbox.isSelected());
    updateCspCheckboxes();
  }

  void cspZeroGenomeTransferCheckbox_actionPerformed(ActionEvent e) {
    landscape.cspSetZeroCellSurfaceProteinGenomeTransfer(cspZeroGenomeTransferCheckbox.isSelected());
    updateCspCheckboxes();
  }

  void cspZeroCommunicationCheckbox_actionPerformed(ActionEvent e) {
    landscape.cspSetZeroCellSurfaceProteinCommunication(cspZeroCommunicationCheckbox.isSelected());
    updateCspCheckboxes();
  }

  void cspPositiveAdhesionCheckbox_actionPerformed(ActionEvent e) {
    landscape.cspSetPositiveCellSurfaceProteinAdhesion(cspPositiveAdhesionCheckbox.isSelected());
    updateCspCheckboxes();
  }

  void cspPositiveEnergyTransferCheckbox_actionPerformed(ActionEvent e) {
    landscape.cspSetPositiveCellSurfaceProteinEnergyTransfer(cspPositiveEnergyTransferCheckbox.isSelected());
    updateCspCheckboxes();
  }

  void cspPositiveGenomeTransferCheckbox_actionPerformed(ActionEvent e) {
    landscape.cspSetPositiveCellSurfaceProteinGenomeTransfer(cspPositiveGenomeTransferCheckbox.isSelected());
    updateCspCheckboxes();
  }

  void cspPositiveCommunicationCheckbox_actionPerformed(ActionEvent e) {
    landscape.cspSetPositiveCellSurfaceProteinCommunication(cspPositiveCommunicationCheckbox.isSelected());
    updateCspCheckboxes();
  }

  private void updateCspCheckboxes()
  {
    cspNegativeAdhesionCheckbox.setSelected(landscape.cspGetNegativeCellSurfaceProteinAdhesion());
    cspNegativeEnergyTransferCheckbox.setSelected(landscape.cspGetNegativeCellSurfaceProteinEnergyTransfer());
    cspNegativeGenomeTransferCheckbox.setSelected(landscape.cspGetNegativeCellSurfaceProteinGenomeTransfer());
    cspNegativeCommunicationCheckbox.setSelected(landscape.cspGetNegativeCellSurfaceProteinCommunication());
    cspZeroAdhesionCheckbox.setSelected(landscape.cspGetZeroCellSurfaceProteinAdhesion());
    cspZeroEnergyTransferCheckbox.setSelected(landscape.cspGetZeroCellSurfaceProteinEnergyTransfer());
    cspZeroGenomeTransferCheckbox.setSelected(landscape.cspGetZeroCellSurfaceProteinGenomeTransfer());
    cspZeroCommunicationCheckbox.setSelected(landscape.cspGetZeroCellSurfaceProteinCommunication());
    cspPositiveAdhesionCheckbox.setSelected(landscape.cspGetPositiveCellSurfaceProteinAdhesion());
    cspPositiveEnergyTransferCheckbox.setSelected(landscape.cspGetPositiveCellSurfaceProteinEnergyTransfer());
    cspPositiveGenomeTransferCheckbox.setSelected(landscape.cspGetPositiveCellSurfaceProteinGenomeTransfer());
    cspPositiveCommunicationCheckbox.setSelected(landscape.cspGetPositiveCellSurfaceProteinCommunication());
  }

  void maxGenomeTransferTextField_keyReleased(KeyEvent e) {
    String v = maxGenomeTransferTextField.getText().trim();
    if (v.length() > 0) {
      try {
        landscape.setMaxGeneTransfer(Integer.parseInt(v));
      } catch (NumberFormatException ex) {
        JOptionPane.showMessageDialog(this,"Maximum genome transfer must be a positive integer","Invalid Value",JOptionPane.ERROR_MESSAGE);
      }
    }
  }
}

class Landscape2DWindow_zoomSlider_mouseAdapter extends java.awt.event.MouseAdapter {
  Landscape2DWindow adaptee;

  Landscape2DWindow_zoomSlider_mouseAdapter(Landscape2DWindow adaptee) {
    this.adaptee = adaptee;
  }
  public void mouseReleased(MouseEvent e) {
    adaptee.zoomSlider_mouseReleased(e);
  }
}

class Landscape2DWindow_zoomSlider_keyAdapter extends java.awt.event.KeyAdapter {
  Landscape2DWindow adaptee;

  Landscape2DWindow_zoomSlider_keyAdapter(Landscape2DWindow adaptee) {
    this.adaptee = adaptee;
  }
  public void keyReleased(KeyEvent e) {
    adaptee.zoomSlider_keyReleased(e);
  }
}

class browser_viewPanel_mouseAdapter extends java.awt.event.MouseAdapter {
  Landscape2DWindow adaptee;

  browser_viewPanel_mouseAdapter(Landscape2DWindow adaptee) {
    this.adaptee = adaptee;
  }
  public void mouseEntered(MouseEvent e) {
    adaptee.browser_mouseEntered(e);
  }
  public void mouseExited(MouseEvent e) {
    adaptee.browser_mouseExited(e);
  }
  public void mousePressed(MouseEvent e) {
    adaptee.browser_mousePressed(e);
  }
  public void mouseReleased(MouseEvent e) {
    adaptee.browser_mouseReleased(e);
  }
}

class browser_viewPanel_mouseMotionAdapter extends java.awt.event.MouseMotionAdapter {
  Landscape2DWindow adaptee;

  browser_viewPanel_mouseMotionAdapter(Landscape2DWindow adaptee) {
    this.adaptee = adaptee;
  }
  public void mouseMoved(MouseEvent e) {
    adaptee.browser_mouseMoved(e);
  }
  public void mouseDragged(MouseEvent e) {
    adaptee.browser_mouseMoved(e);
  }
}

class Landscape2DWindow_bulkAddEnergyButton_actionAdapter implements java.awt.event.ActionListener {
  Landscape2DWindow adaptee;

  Landscape2DWindow_bulkAddEnergyButton_actionAdapter(Landscape2DWindow adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.bulkAddEnergyButton_actionPerformed(e);
  }
}

class Landscape2DWindow_maintainEnergyTextField_keyAdapter extends java.awt.event.KeyAdapter {
  Landscape2DWindow adaptee;

  Landscape2DWindow_maintainEnergyTextField_keyAdapter(Landscape2DWindow adaptee) {
    this.adaptee = adaptee;
  }
  public void keyReleased(KeyEvent e) {
    adaptee.maintainEnergyTextField_keyReleased(e);
  }
}

class Landscape2DWindow_jButton3_actionAdapter implements java.awt.event.ActionListener {
  Landscape2DWindow adaptee;

  Landscape2DWindow_jButton3_actionAdapter(Landscape2DWindow adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton3_actionPerformed(e);
  }
}

class Landscape2DWindow_examineGenomeButton_actionAdapter implements java.awt.event.ActionListener {
  Landscape2DWindow adaptee;

  Landscape2DWindow_examineGenomeButton_actionAdapter(Landscape2DWindow adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.examineGenomeButton_actionPerformed(e);
  }
}

class Landscape2DWindow_this_windowAdapter extends java.awt.event.WindowAdapter {
  Landscape2DWindow adaptee;

  Landscape2DWindow_this_windowAdapter(Landscape2DWindow adaptee) {
    this.adaptee = adaptee;
  }
  public void windowClosing(WindowEvent e) {
    adaptee.this_windowClosing(e);
  }
}

class Landscape2DWindow_northButton_mouseAdapter extends java.awt.event.MouseAdapter {
  Landscape2DWindow adaptee;

  Landscape2DWindow_northButton_mouseAdapter(Landscape2DWindow adaptee) {
    this.adaptee = adaptee;
  }
  public void mousePressed(MouseEvent e) {
    adaptee.northButton_mousePressed(e);
  }
  public void mouseReleased(MouseEvent e) {
    adaptee.northButton_mouseReleased(e);
  }
  public void mouseExited(MouseEvent e) {
    adaptee.northButton_mouseExited(e);
  }
}

class Landscape2DWindow_southButton_mouseAdapter extends java.awt.event.MouseAdapter {
  Landscape2DWindow adaptee;

  Landscape2DWindow_southButton_mouseAdapter(Landscape2DWindow adaptee) {
    this.adaptee = adaptee;
  }
  public void mousePressed(MouseEvent e) {
    adaptee.southButton_mousePressed(e);
  }
  public void mouseReleased(MouseEvent e) {
    adaptee.southButton_mouseReleased(e);
  }
  public void mouseExited(MouseEvent e) {
    adaptee.southButton_mouseExited(e);
  }
}

class Landscape2DWindow_eastButton_mouseAdapter extends java.awt.event.MouseAdapter {
  Landscape2DWindow adaptee;

  Landscape2DWindow_eastButton_mouseAdapter(Landscape2DWindow adaptee) {
    this.adaptee = adaptee;
  }
  public void mousePressed(MouseEvent e) {
    adaptee.eastButton_mousePressed(e);
  }
  public void mouseReleased(MouseEvent e) {
    adaptee.eastButton_mouseReleased(e);
  }
  public void mouseExited(MouseEvent e) {
    adaptee.eastButton_mouseExited(e);
  }
}

class Landscape2DWindow_westButton_mouseAdapter extends java.awt.event.MouseAdapter {
  Landscape2DWindow adaptee;

  Landscape2DWindow_westButton_mouseAdapter(Landscape2DWindow adaptee) {
    this.adaptee = adaptee;
  }
  public void mousePressed(MouseEvent e) {
    adaptee.westButton_mousePressed(e);
  }
  public void mouseReleased(MouseEvent e) {
    adaptee.westButton_mouseReleased(e);
  }
  public void mouseExited(MouseEvent e) {
    adaptee.westButton_mouseExited(e);
  }
}

class Landscape2DWindow_energyDensityTextField_keyAdapter extends java.awt.event.KeyAdapter {
  Landscape2DWindow adaptee;

  Landscape2DWindow_energyDensityTextField_keyAdapter(Landscape2DWindow adaptee) {
    this.adaptee = adaptee;
  }
  public void keyReleased(KeyEvent e) {
    adaptee.energyDensityTextField_keyReleased(e);
  }
}

