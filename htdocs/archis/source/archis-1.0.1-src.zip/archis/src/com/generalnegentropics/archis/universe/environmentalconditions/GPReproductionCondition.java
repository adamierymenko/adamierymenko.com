package com.generalnegentropics.archis.universe.environmentalconditions;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

import java.util.*;
import com.generalnegentropics.archis.life.*;
import com.generalnegentropics.archis.universe.*;
import com.generalnegentropics.archis.*;
import com.generalnegentropics.archis.utils.*;

/**
 * <p>An environmental condition that artificially reproduces cells based on
 * their points earned.</p>
 *
 * @author Adam Ierymenko
 * @version 1.0
 */

public class GPReproductionCondition implements EnvironmentalCondition
{
  /**
   * Description of condition
   */
  public static final String CONDITION_DESCRIPTION = "Artificially reproduces cells based on their points earned. (Makes Archis act like a classic GP system.)";

  private static Map parameters;
  static
  {
    parameters = new HashMap();
    parameters.put("maintainPopulation","Population to maintain in universe");
    parameters.put("fuzziness","Probability of giving a chance to cells farther down the fitness curve");
    parameters = Collections.unmodifiableMap(parameters);
  }

  private Universe universe;
  private Simulation simulation;
  private RandomSource randomSource;
  private int maintainPopulation;
  private float fuzziness;
  private TreeMap pointClasses;

  /**
   * Constructs a new reproduction condition with the given parameters
   */
  public GPReproductionCondition()
  {
    fuzziness = 0.25F;
    maintainPopulation = 10000;
    pointClasses = new TreeMap(Collections.reverseOrder());
  }

  public Map getParameters()
  {
    return parameters;
  }

  public Object getParameter(String name)
  {
    if ("maintainPopulation".equals(name))
      return new Integer(maintainPopulation);
    else if ("fuzziness".equals(name))
      return new Float(fuzziness);
    return null;
  }

  public void setParameter(String name,Object value)
  {
    if ("maintainPopulation".equals(name))
      maintainPopulation = ParameterValueParser.getInt(value);
    else if ("fuzziness".equals(name))
      fuzziness = ParameterValueParser.getFloat(value);
  }

  public String getChannelDescription(int channel)
  {
    return null;
  }

  public boolean newCellNotify(Cell parent, Cell newCell)
  {
    return true;
  }

  public void initCellNotify(Cell cell)
  {
  }

  public void deathNotify(Cell deadCell, String reason)
  {
  }

  public void preExecutionNotify(Cell l)
  {
  }

  public void evaluateOutput(Cell l,int channel,int value)
  {
  }

  public void init(Universe universe,Simulation simulation)
  {
    this.universe = universe;
    this.simulation = simulation;
    randomSource = simulation.randomSource();
  }

  public void destroy()
  {
  }

  public void preTickNotify()
    throws ConditionExpirationException
  {
  }

  public void postTickNotify()
    throws ConditionExpirationException
  {
    // Step forward (in descending point class order) through point classes
    // and artificially reproduce cells.  The fuzziness is the probability
    // that we will skip a cell, and therefore is the relative probability that
    // we'll continue deeper into the top cell list than we otherwise would.
    int totalCellsCreated = 0;
    int population = universe.population();
    if (population < maintainPopulation) {
      boolean done = false;
      synchronized(pointClasses) {
        for(Iterator i=pointClasses.values().iterator();i.hasNext();) {
          LinkedList pc = (LinkedList)i.next();
          for(Iterator i2=pc.iterator();i2.hasNext();) {
            Cell c = (Cell)i2.next();
            if (!randomSource.randomEvent(fuzziness)) {
              // Artificially duplicate cell
              int e = c.energy() / 2;
              c.decEnergy(e);
              universe.addCell(c,new Cell(universe,simulation.nextCellId(),simulation.getName(),c.id(),c.generation()+1L,e,c.genome()));
              ++totalCellsCreated;
              if (++population > maintainPopulation) {
                done = true;
                break;
              }
            }
          }
          if (done)
            break;
        }
      }
    }
    synchronized(pointClasses) {
      pointClasses.clear();
    }
    simulation.setStatistic("GPR GPReproductionCondition.totalCellsDuplicated",totalCellsCreated);
  }

  public void postTickProcessCells(List cells)
  {
    // Put all cells into pointClasses
    for(Iterator i=cells.iterator();i.hasNext();) {
      Cell c = (Cell)i.next();
      int pts;
      if (c.alive()&&((pts = c.getLastPoints()) > 0)&&(c.energy() >= 2)) {
        LinkedList pc;
        Integer _pts = new Integer(pts);
        synchronized(pointClasses) {
          pc = (LinkedList)pointClasses.get(_pts);
        }
        if (pc == null) {
          pc = new LinkedList();
          synchronized(pointClasses) {
            pointClasses.put(_pts,pc);
          }
        }
        synchronized(pc) {
          pc.add(c);
        }
      }
    }
  }
}
