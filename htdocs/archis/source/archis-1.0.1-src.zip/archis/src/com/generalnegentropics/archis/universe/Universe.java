package com.generalnegentropics.archis.universe;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

import java.util.*;
import com.generalnegentropics.archis.*;
import com.generalnegentropics.archis.utils.*;
import com.generalnegentropics.archis.life.*;

/**
 * <p>The Universe</p>
 *
 * <p>Most of the guts of the core loop of the Archis simulation are here.
 * The universe serves as a plugin and cell database manager, and handles
 * the invocation of plugins and the adding and removing of cells.  The
 * main tick() method in here is called from Simulation and is the core
 * loop function of the program.</p>
 *
 * @author Adam Ierymenko
 * @version 2.0
 */

public class Universe
{
  // Conditions and changes
  private Condition[] conditions;
  private Set newConditions,removeConditions;

  // Probes and changes
  private Probe[] probes;
  private Set newProbes,removeProbes;

  // IO handlers
  private IOHandler[] ioChannelAssignments;

  // Random source (from simulation)
  private RandomSource randomSource;

  // Cells (grouped into execution batches)
  private LinkedList[] cells;

  // New cells for current run
  private ArrayList newCells,newCellParents;

  // Object to notify threads to start
  private Object startNotify;

  // Execution agents (null if only one)
  private MultiThreadedExecutionAgent[] threads;

  // Simulation clock
  private long clock;

  // Amount of energy to hand out based on reward function points per tick
  private long energyReward;

  // Statistics
  private volatile long totalCellEnergy;
  private volatile long totalBirths;
  private volatile long totalIntroducedBirths;
  private volatile long totalNaturalBirths;
  private volatile long totalDeaths;
  private volatile long maxGeneration;
  private volatile long maxGenerationThisRun;
  private volatile long minGenerationThisRun;
  private volatile long genomeSizeSum;
  private volatile int maxGenomeSize,minGenomeSize;
  private volatile long ageSum;
  private volatile long totalFailedBirths;

  // Simulation
  private Simulation simulation;

  /**
   * An iterator that iterates over all the cells in the universe
   *
   * @author Adam Ierymenko
   * @version 1.0
   */
  private class CellIterator implements Iterator
  {
    private int ca;
    private Iterator ci;

    public CellIterator()
    {
      ca = 1;
      ci = cells[0].iterator();
    }

    public boolean hasNext()
    {
      if (ci.hasNext())
        return true;
      else if (ca < cells.length)
        return (cells[ca].size() > 0);
      else return false;
    }

    public Object next()
      throws NoSuchElementException
    {
      if (ci.hasNext())
        return ci.next();
      else if (ca < cells.length) {
        ci = cells[ca++].iterator();
        return ci.next();
      } else throw new NoSuchElementException();
    }

    public void remove()
      throws UnsupportedOperationException
    {
      throw new UnsupportedOperationException();
    }
  }

  /**
   * Internal thread to execute cells concurrently
   */
  private class MultiThreadedExecutionAgent extends Thread
  {
    public volatile boolean die;
    public volatile boolean running;
    public volatile boolean doPostTickProcessCells;
    public int batch;
    public Object endNotify;
    public long time;

    public MultiThreadedExecutionAgent(int batch)
    {
      super("Universe concurrent execution thread [batch="+batch+"]");
      super.setDaemon(true);
      this.batch = batch;
      die = false;
      running = false;
      doPostTickProcessCells = false;
      endNotify = new Object();
      time = 0L;
      super.start();
    }

    public void run()
    {
      for(;;) {
        try {
          synchronized(startNotify) {
            if (!running)
              startNotify.wait();
          }
        } catch (InterruptedException e) {}

        if (die)
          break;
        else if (running) {
          if (doPostTickProcessCells) {
            List tmp = Collections.unmodifiableList(cells[batch]);
            for(int i=0;i<conditions.length;i++)
              conditions[i].postTickProcessCells(tmp);
          } else {
            long _st = System.currentTimeMillis();
            executeCellBatch(batch);
            time = System.currentTimeMillis() - _st;
          }

          synchronized(endNotify) {
            running = false;
            endNotify.notifyAll();
          }
        }
      }
    }
  }

  /**
   * Constructs a new universe
   *
   * @param nthreads Number of concurrent threads to execute
   * @param simulation Simulation this universe is running within
   */
  public Universe(int nthreads,Simulation simulation)
  {
    startNotify = new Object();

    cells = new LinkedList[nthreads];
    for(int i=0;i<nthreads;i++)
      cells[i] = new LinkedList();

    if (nthreads > 1) {
      // Start n-1 threads (this thread will function as thread 0)
      threads = new MultiThreadedExecutionAgent[nthreads-1];
      for(int i=0;i<(nthreads-1);i++)
        threads[i] = new MultiThreadedExecutionAgent(i+1);
    } else threads = null;

    this.simulation = simulation;
    randomSource = simulation.randomSource();
    newCells = new ArrayList(65536);
    newCellParents = new ArrayList(65536);
    ioChannelAssignments = new IOHandler[Archis.CHANNEL_COUNT];
    newProbes = new HashSet(32,0.75F);
    newConditions = new HashSet(32,0.75F);
    removeProbes = new HashSet(32,0.75F);
    removeConditions = new HashSet(32,0.75F);
    probes = new Probe[0];
    conditions = new Condition[0];

    energyReward = 1000000L;

    totalCellEnergy = 0L;
    totalBirths = 0L;
    totalIntroducedBirths = 0L;
    totalNaturalBirths = 0L;
    totalFailedBirths = 0L;
    totalDeaths = 0L;
    maxGeneration = 0L;
    maxGenerationThisRun = 0L;
  }

  /**
   * <p>Returns an iterator over all the cells in the population</p>
   *
   * <p>Note that using this <i>during</i> processing is likely to result
   * in spurious ConcurrentModificationExceptions.  It should only be used
   * from preTickNotify or postTickNotify in conditions or when the
   * simulation is paused.</p>
   *
   * <p>Depending on where we are in the cycle, some of the cells found
   * in this iterator may not be alive.  Code that needs to be aware of
   * this should check.</p>
   *
   * <p>This iterator does <i>not</i> implement the remove() method!  Use
   * the kill method of cells instead.</p>
   *
   * @return Iterator over all cells in the population
   */
  public Iterator populationIterator()
  {
    return new CellIterator();
  }

  /**
   * Destroys this universe and kills all associated threads (this should be called explicitly!)
   */
  public void destroy()
  {
    if (threads != null) {
      for(int i=0;i<threads.length;i++) {
        threads[i].die = true;
        threads[i].interrupt();
      }
      threads = null;
    }
  }

  /**
   * Destroy on finalize
   *
   * @throws Throwable Any exception
   */
  protected void finalize()
    throws Throwable
  {
    destroy();
  }

  /**
   * <p>Gets the current I/O channel assignments</p>
   *
   * @return Array of IOHandlers corresponding to channels
   */
  public IOHandler[] getChannelAssignments()
  {
    IOHandler[] r = new IOHandler[ioChannelAssignments.length];
    for(int i=0;i<r.length;i++)
      r[i] = ioChannelAssignments[i];
    return r;
  }

  /**
   * Assigns an I/O channel to a handler
   *
   * @param channel Channel to set/change assignment for
   * @param handler New handler for channel
   */
  public void assignChannel(int channel,IOHandler handler)
  {
    ioChannelAssignments[channel] = handler;
  }

  /**
   * Unassigns an I/O channel
   *
   * @param channel Channel to clear assignment(s) for
   */
  public void unassignChannel(int channel)
  {
    ioChannelAssignments[channel] = null;
  }

  /**
   * Adds an observation probe to the universe
   *
   * @param probe Probe to add
   */
  public void addProbe(Probe probe)
  {
    if (probe != null) {
      synchronized (newProbes) {
        for(Iterator i=newProbes.iterator();i.hasNext();) {
          if (i.next().getClass().getName().equals(probe.getClass().getName()))
            i.remove();
        }
        newProbes.add(probe);
      }
      probe.init(this,simulation);
    }
  }

  /**
   * Removes an observation probe from the universe
   *
   * @param probe Probe to remove
   */
  public void removeProbe(Probe probe)
  {
    if (probe != null) {
      synchronized (probes) {
        removeProbes.add(probe);
      }
    }
  }

  /**
   * Adds a condition to this universe
   *
   * @param condition Condition
   */
  public void addCondition(Condition condition)
  {
    if (condition != null) {
      synchronized(newConditions) {
        for(Iterator i=newConditions.iterator();i.hasNext();) {
          if (i.next().getClass().getName().equals(condition.getClass().getName()))
            i.remove();
        }
        newConditions.add(condition);
      }
      condition.init(this,simulation);
    }
  }

  /**
   * Removes a condition from this universe
   *
   * @param condition Condition to remove
   */
  public void removeCondition(Condition condition)
  {
    if (condition != null) {
      synchronized (removeConditions) {
        removeConditions.add(condition);
      }
    }
  }

  /**
   * Returns a set of conditions present in the universe
   *
   * @return Set of conditions
   */
  public Set getConditions()
  {
    HashSet r = new HashSet(conditions.length+16,0.99F);
    for(int i=0;i<conditions.length;i++)
      r.add(conditions[i]);
    synchronized(newConditions) {
      r.addAll(newConditions);
    }
    return Collections.unmodifiableSet(r);
  }

  /**
   * Returns a set of probes present in the universe
   *
   * @return Set of probes
   */
  public Set getProbes()
  {
    HashSet r = new HashSet(probes.length+16,0.99F);
    for(int i=0;i<probes.length;i++)
      r.add(probes[i]);
    synchronized(newProbes) {
      r.addAll(newProbes);
    }
    return Collections.unmodifiableSet(r);
  }

  /**
   * Returns whether or not the given condition class is active in the universe
   *
   * @param clazz Class to check for
   * @return Is class active?
   */
  public boolean hasCondition(Class clazz)
  {
    String cn = clazz.getName();
    for(int i=0;i<conditions.length;i++) {
      if (conditions[i].getClass().getName().equals(cn))
        return true;
    }
    for(Iterator i=newConditions.iterator();i.hasNext();) {
      if (i.next().getClass().getName().equals(cn))
        return true;
    }
    return false;
  }

  /**
   * Returns whether or not the given probe class is active in the universe
   *
   * @param clazz Class to check for
   * @return Is class active?
   */
  public boolean hasProbe(Class clazz)
  {
    String cn = clazz.getName();
    for(int i=0;i<probes.length;i++) {
      if (probes[i].getClass().getName().equals(cn))
        return true;
    }
    for(Iterator i=newProbes.iterator();i.hasNext();) {
      if (i.next().getClass().getName().equals(cn))
        return true;
    }
    return false;
  }

  /**
   * Attempts to add a cell to the universe (may be rejected by conditions)
   *
   * @param parent Parent or null if none (random or synthetic)
   * @param newCell New cell
   */
  public void addCell(Cell parent,Cell newCell)
  {
    synchronized(newCells) {
      newCells.add(newCell);
      newCellParents.add(parent);
    }
  }

  /**
   * Internal method to execute a given batch of cells
   *
   * @param batch Batch (thread) number
   */
  private void executeCellBatch(int batch)
  {
    synchronized(cells[batch]) {
      int gs;
      long gen;
      Cell cell;

      for(Iterator it=cells[batch].iterator();it.hasNext();) {
        cell = (Cell)it.next();
        if (cell.alive()) {
          // Execute probes against cell
          for(int i=0;i<probes.length;i++)
            probes[i].probeScanCell(cell);
          // Run conditions against cell
          for(int i=0;i<conditions.length;i++)
            conditions[i].preExecutionNotify(cell);

          if (cell.alive()) {
            // Execute cell genome
            cell.heartbeat();

            if (cell.alive()) {
              // Add cell's energy to total living cell energy
              totalCellEnergy += (long)cell.energy();

              // Add to some sums used in calculating averages
              genomeSizeSum += (long)(gs = cell.genome().size());
              if (gs > maxGenomeSize)
                maxGenomeSize = gs;
              if (gs < minGenomeSize)
                minGenomeSize = gs;
              ageSum += cell.age();

              // Update max and min living generation this run
              if ((gen = cell.generation()) > maxGenerationThisRun)
                maxGenerationThisRun = gen;
              if (gen < minGenerationThisRun)
                minGenerationThisRun = gen;
            } else it.remove();
          } else it.remove();
        } else it.remove();
      }
    }
  }

  /**
   * Called only by genome to send output back to universe. Do not call from other code.
   *
   * @param l Cell from which output originated
   * @param channel Channel of output
   * @param value Value of output
   */
  public void evaluateOutput(Cell l,int channel,int value)
  {
    if (channel < 0)
      channel = ((channel == -2147483648) ? 2147483647 : -channel) % Archis.CHANNEL_COUNT;
    else channel %= Archis.CHANNEL_COUNT;

    if (ioChannelAssignments[channel] != null)
      ioChannelAssignments[channel].evaluateOutput(l,channel,value);
  }

  /**
   * Sets energy to distribute to reward function winners per turn
   *
   * @param energyReward Energy to distribute per turn
   */
  public void setEnergyReward(long energyReward)
  {
    this.energyReward = energyReward;
  }

  /**
   * Gets energy to distribute to reward function winners per turn
   *
   * @return Energy to distribute per turn
   */
  public long getEnergyReward()
  {
    return energyReward;
  }

  /**
   * Called only by cells to notify of death. Do not call from other code.
   *
   * @param deadCell Cell that died
   * @param reason Reason for death
   */
  public void deathNotify(Cell deadCell,String reason)
  {
    // Notify environmental conditions of death
    for(int i=0;i<conditions.length;i++)
      conditions[i].deathNotify(deadCell,reason);

    ++totalDeaths;

    // Dead cells are removed from cell lists during runs, not here.
  }

  /**
   * <p>Executes a single tick of universe time</p>
   *
   * <p>Do not call this directly.  Use the methods in Simulation.</p>
   */
  public synchronized void tick()
  {
    // Handle pre-tick on probes
    synchronized(newProbes) {
      synchronized(removeProbes) {
        if ((newProbes.size() > 0) || (removeProbes.size() > 0)) {
          for(Iterator i=removeProbes.iterator();i.hasNext();)
            ((Probe)i.next()).destroy();
          for (int i = 0;i < probes.length;i++)
            newProbes.add(probes[i]);
          newProbes.removeAll(removeProbes);
          int x = 0;
          probes = new Probe[newProbes.size()];
          for (Iterator i = newProbes.iterator();i.hasNext();)
            probes[x++] = (Probe)i.next();
          newProbes.clear();
          removeProbes.clear();
        }
      }
    }
    for(int i=0;i<probes.length;i++)
      probes[i].preTickNotify();

    // Handle pre-tick on conditions
    synchronized(newConditions) {
      synchronized(removeConditions) {
        // Add and remove conditions
        if ((newConditions.size() > 0) || (removeConditions.size() > 0)) {
          for(Iterator i=newConditions.iterator();i.hasNext();) {
            Condition c = (Condition)i.next();
            for(int b=0;b<cells.length;b++) {
              for(Iterator ci=cells[b].iterator();ci.hasNext();) {
                Cell cell = (Cell)ci.next();
                if (cell != null)
                  c.initCellNotify(cell);
              }
            }
          }
          for(Iterator i=removeConditions.iterator();i.hasNext();)
            ((Condition)i.next()).destroy();
          for (int i = 0;i < conditions.length;i++)
            newConditions.add(conditions[i]);
          newConditions.removeAll(removeConditions);
          int x = 0;
          conditions = new Condition[newConditions.size()];
          for (Iterator i = newConditions.iterator();i.hasNext();)
            conditions[x++] = (Condition)i.next();
          newConditions.clear();
          removeConditions.clear();
        }

        // Pre-tick notify conditions
        for(int i=0;i<conditions.length;i++) {
          try {
            conditions[i].preTickNotify();
          } catch (ConditionExpirationException e) {
            removeConditions.add(conditions[i]);
          }
        }

        // Remove any that threw ConditionExpirationException
        if (removeConditions.size() > 0) {
          for (int i = 0;i < conditions.length;i++)
            newConditions.add(conditions[i]);
          newProbes.removeAll(removeConditions);
          int x = 0;
          conditions = new Condition[newConditions.size()];
          for (Iterator i = newConditions.iterator();i.hasNext();)
            conditions[x++] = (Condition)i.next();
        }
      }
    }

    // Handle new cells
    if (newCells.size() > 0) {
      synchronized(newCells) {
        // Figure out which of the cells[] lists is emptiest
        List emptiest = cells[0];
        int emptiestSize = cells[0].size();
        for(int i=1;i<cells.length;i++) {
          if (cells[i].size() < emptiestSize) {
            emptiestSize = cells[i].size();
            emptiest = cells[i];
          }
        }

        // Add cells
        for(int x=0,s=newCells.size();x<s;x++) {
          Cell newCell = (Cell)newCells.get(x);
          Cell parent = (Cell)newCellParents.get(x);

          boolean cellok = true;
          for(int i=0;i<conditions.length;i++) {
            if (!conditions[i].newCellNotify(parent,newCell))
              cellok = false;
          }

          if (cellok) {
            for(int i=0;i<probes.length;i++)
              probes[i].probeNewCell(parent,newCell);
            if (parent == null)
              ++totalIntroducedBirths;
            else ++totalNaturalBirths;
            emptiest.add(newCell);
            ++totalBirths;
          } else ++totalFailedBirths;
        }

        newCells.clear();
        newCellParents.clear();
      }
    }

    // Reset per-run stats
    totalCellEnergy = 0L;
    maxGenerationThisRun = 0L;
    minGenerationThisRun = Long.MAX_VALUE;
    ageSum = 0L;
    genomeSizeSum = 0L;
    maxGenomeSize = 0;
    minGenomeSize = 2147483647;

    if (threads == null) {
      // Just run in this thread if we're running single-threaded
      executeCellBatch(0);
      List tmp = Collections.unmodifiableList(cells[0]);
      for(int i=0;i<conditions.length;i++)
        conditions[i].postTickProcessCells(tmp);
    } else {
      // Start all threads to do cell execution
      synchronized (startNotify) {
        for(int i=0;i<threads.length;i++) {
          threads[i].running = true;
          threads[i].doPostTickProcessCells = false;
        }
        startNotify.notifyAll();
      }

      // Execute cell batch 0 in this thread (and time it as thread 0)
      executeCellBatch(0);

      // Wait for all other threads to be finished
      for (int i=0;i<threads.length;i++) {
        try {
          synchronized (threads[i].endNotify) {
            if (threads[i].running)
              threads[i].endNotify.wait();
          }
        } catch (InterruptedException e) {}
      }

      // Start all threads to do condition post-processing
      synchronized (startNotify) {
        for(int i=0;i<threads.length;i++) {
          threads[i].running = true;
          threads[i].doPostTickProcessCells = true;
        }
        startNotify.notifyAll();
      }

      // Execute condition post-processing for batch 0 in this thread
      List tmp = Collections.unmodifiableList(cells[0]);
      for(int i=0;i<conditions.length;i++)
        conditions[i].postTickProcessCells(tmp);

      // Wait for all other threads to be finished
      for (int i=0;i<threads.length;i++) {
        try {
          synchronized (threads[i].endNotify) {
            if (threads[i].running)
              threads[i].endNotify.wait();
          }
        } catch (InterruptedException e) {}
      }
    }

    // Update max generation
    if (maxGenerationThisRun > maxGeneration)
      maxGeneration = maxGenerationThisRun;

    // Handle post-tick on conditions
    synchronized(removeConditions) {
      for(int i=0;i<conditions.length;i++) {
        try {
          conditions[i].postTickNotify();
        } catch (ConditionExpirationException e) {
          removeConditions.add(conditions[i]);
        }
      }
    }

    // Handle post-tick on probes
    for(int i=0;i<probes.length;i++)
      probes[i].postTickNotify();

    // Distribute reward to cells based on how many points they have and
    // reset their point totals for the next round of execution
    long totalPoints = 0L;
    long maxPoints = 0L;
    long minPoints = 9223372036854775807L; // max long value
    long actualEnergyDistributed = 0L;
    for(int i=0;i<cells.length;i++) {
      synchronized(cells[i]) {
        for (Iterator i2 = cells[i].iterator();i2.hasNext();) {
          Cell c = (Cell)i2.next();
          if (c.alive()) {
            long p = (long)c.getPoints();
            if (p > maxPoints)
              maxPoints = p;
            if (p < minPoints)
              minPoints = p;
            totalPoints += p;
          } else i2.remove();
        }
      }
    }
    double rewardPerPoint = ((totalPoints > 0L) ? (double)energyReward / (double)totalPoints : 0.0);
    for(int i=0;i<cells.length;i++) {
      synchronized(cells[i]) {
        for(Iterator i2=cells[i].iterator();i2.hasNext();) {
          Cell c = (Cell)i2.next();
          int tmp;
          c.incEnergy(tmp = (int)Math.round(rewardPerPoint * (double)c.getPoints()));
          actualEnergyDistributed += (long)tmp;
          c.clearPoints();
        }
      }
    }

    // Advance simulation clock and check stop points
    ++clock;

    // Report some stats
    simulation.setStatistic("U01 Universe.totalIntroducedBirths",totalIntroducedBirths);
    simulation.setStatistic("U02 Universe.totalNaturalBirths",totalNaturalBirths);
    simulation.setStatistic("U03 Universe.totalBirths",totalBirths);
    simulation.setStatistic("U04 Universe.totalFailedBirths",totalFailedBirths);
    simulation.setStatistic("U05 Universe.totalDeaths",totalDeaths);
    int population = 0;
    for(int i=0;i<cells.length;i++)
      population += cells[i].size();
    simulation.setStatistic("U06 Universe.population",population);
    simulation.setStatistic("U07 Universe.totalCellEnergy",totalCellEnergy);
    simulation.setStatistic("U08 Universe.averageGenomeSize",((population > 0) ? (genomeSizeSum / (long)population) : 0L));
    simulation.setStatistic("U09 Universe.largestGenomeSize",maxGenomeSize);
    simulation.setStatistic("U10 Universe.smallestGenomeSize",((minGenomeSize == 2147483647) ? 0 : minGenomeSize));
    simulation.setStatistic("U11 Universe.maxGenerationReached",maxGeneration);
    simulation.setStatistic("U12 Universe.maxGenerationLiving",maxGenerationThisRun);
    simulation.setStatistic("U13 Universe.averageCellAge",((population > 0) ? (ageSum / (long)population) : 0L));
    if (population > 0) {
      simulation.setStatistic("U14 Universe.minPointsEarned",minPoints);
      simulation.setStatistic("U15 Universe.maxPointsEarned",maxPoints);
      simulation.setStatistic("U16 Universe.actualRewardEnergyDistributed",actualEnergyDistributed);
    } else {
      simulation.setStatistic("U14 Universe.minPointsEarned",0);
      simulation.setStatistic("U15 Universe.maxPointsEarned",0);
      simulation.setStatistic("U16 Universe.actualRewardEnergyDistributed",0);
    }
  }

  /**
   * Gets the current simulation clock
   *
   * @return Simulation clock, in ticks
   */
  public long clock()
  {
    return clock;
  }

  /**
   * Gets the current population of cells
   *
   * @return Current population
   */
  public int population()
  {
    int r = 0;
    for(int i=0;i<cells.length;i++)
      r += cells[i].size();
    return r;
  }

  /**
   * Gets the maximum generation alive this last run
   *
   * @return Minimum living generation
   */
  public long minGenerationThisRun()
  {
    return minGenerationThisRun;
  }

  /**
   * Gets the maximum generation alive this last run
   *
   * @return Maximum living generation
   */
  public long maxGenerationThisRun()
  {
    return maxGenerationThisRun;
  }

  /**
   * Gets maximum genome size currently alive
   *
   * @return Maximum living genome size
   */
  public int maxGenomeSize()
  {
    return maxGenomeSize;
  }

  /**
   * Gets minimum genome size currently alive
   *
   * @return Minimum living genome size
   */
  public int minGenomeSize()
  {
    return minGenomeSize;
  }

  /**
   * Gets the total energy of living cells in the universe (valid at/after postTickNotify)
   *
   * @return Total energy of living cells
   */
  public long totalCellEnergy()
  {
    return totalCellEnergy;
  }
}
