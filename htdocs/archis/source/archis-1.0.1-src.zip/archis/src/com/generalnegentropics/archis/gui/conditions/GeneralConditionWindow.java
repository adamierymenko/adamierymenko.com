package com.generalnegentropics.archis.gui.conditions;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

import java.awt.*;
import java.util.*;
import javax.swing.*;
import javax.swing.table.*;
import javax.swing.event.*;
import com.generalnegentropics.archis.*;
import com.generalnegentropics.archis.universe.*;
import java.awt.event.*;
import java.text.NumberFormat;
import java.text.DecimalFormat;

public class GeneralConditionWindow extends JFrame
{
  private Simulation simulation;
  private Condition condition;
  private Map conditionParameters;
  private JPanel contentPane;
  private GridBagLayout gridBagLayout1 = new GridBagLayout();
  private JScrollPane parameterScrollPane = new JScrollPane();
  private JTable parameterTable = new JTable();
  private JTextField descriptionTextField = new JTextField();
  private JLabel jLabel1 = new JLabel();
  private JTextField newParameterValueTextField = new JTextField();
  private JButton setButton = new JButton();
  private JButton closeButton = new JButton();

  //
  // Table model for the network statistics table
  //
  public static class ConditionParametersTableModel implements TableModel
  {
    private static Class stringClass = "".getClass();
    private Object[] parameterNames;
    private Condition condition;
    private NumberFormat decimalFormat;
    private NumberFormat integerFormat;

    public ConditionParametersTableModel(Object[] parameterNames,Condition condition)
    {
      this.parameterNames = parameterNames;
      this.condition = condition;
      decimalFormat = DecimalFormat.getNumberInstance();
      decimalFormat.setGroupingUsed(false);
      decimalFormat.setMaximumFractionDigits(8);
      decimalFormat.setMinimumFractionDigits(1);
      decimalFormat.setMaximumIntegerDigits(32);
      decimalFormat.setMinimumIntegerDigits(1);
      integerFormat = NumberFormat.getIntegerInstance();
      integerFormat.setMaximumFractionDigits(0);
      integerFormat.setMinimumFractionDigits(0);
      integerFormat.setGroupingUsed(false);
      integerFormat.setMaximumIntegerDigits(32);
      integerFormat.setMinimumIntegerDigits(1);
    }

    public int getRowCount()
    {
      return parameterNames.length;
    }

    public int getColumnCount()
    {
      return 2;
    }

    public String getColumnName(int columnIndex)
    {
      switch(columnIndex) {
        case 0:
          return "Parameter Name";
        case 1:
          return "Value";
      }
      return "";
    }

    public Class getColumnClass(int columnIndex)
    {
      return stringClass;
    }

    public boolean isCellEditable(int rowIndex, int columnIndex)
    {
      return false;
    }

    public Object getValueAt(int rowIndex, int columnIndex)
    {
      if (columnIndex == 0)
        return parameterNames[rowIndex];
      else {
        Object r = condition.getParameter((String)parameterNames[rowIndex]);
        if (r == null)
          return "";
        else if ((r instanceof Double)||(r instanceof Float))
          return decimalFormat.format(((Number)r).doubleValue());
        else if ((r instanceof Integer)||(r instanceof Long))
          return integerFormat.format(((Number)r).longValue());
        else return r.toString();
      }
    }

    public void setValueAt(Object aValue, int rowIndex, int columnIndex)
    {
    }

    public void addTableModelListener(TableModelListener l)
    {
    }

    public void removeTableModelListener(TableModelListener l)
    {
    }
  }

  public GeneralConditionWindow(Simulation simulation,Condition condition)
  {
    this.simulation = simulation;
    this.condition = condition;
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
    this.setSize(640,360);
    Dimension ss = this.getToolkit().getScreenSize();
    this.setLocation((ss.width/2)-(this.getWidth()/2),(ss.height/2)-(this.getHeight()/2));
    this.setIconImage(Archis.ICON);
    String cn = condition.getClass().getName();
    int tmp = cn.lastIndexOf('.');
    if (tmp <= 0)
      this.setTitle("["+simulation.getName()+"] "+cn);
    else this.setTitle("["+simulation.getName()+"] "+cn.substring(tmp+1));

    // Set up tables and stuff
    conditionParameters = condition.getParameters();
    parameterTable.setModel(new ConditionParametersTableModel(conditionParameters.keySet().toArray(),condition));
    parameterTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
  }
  private void jbInit() throws Exception {
    contentPane = (JPanel)this.getContentPane();
    contentPane.setLayout(gridBagLayout1);
    this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    descriptionTextField.setEditable(false);
    descriptionTextField.setText("");
    jLabel1.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel1.setText("New Parameter Value:");
    newParameterValueTextField.setText("");
    newParameterValueTextField.addKeyListener(new java.awt.event.KeyAdapter() {
      public void keyReleased(KeyEvent e) {
        newParameterValueTextField_keyReleased(e);
      }
    });
    setButton.setText("Set");
    setButton.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        setButton_actionPerformed(e);
      }
    });
    closeButton.setText("Close");
    closeButton.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        closeButton_actionPerformed(e);
      }
    });
    parameterTable.addMouseListener(new java.awt.event.MouseAdapter()
    {
      public void mouseReleased(MouseEvent e)
      {
        parameterTable_mouseReleased(e);
      }
    });
    parameterTable.addMouseWheelListener(new java.awt.event.MouseWheelListener()
    {
      public void mouseWheelMoved(MouseWheelEvent e)
      {
        parameterTable_mouseWheelMoved(e);
      }
    });
    parameterTable.addKeyListener(new java.awt.event.KeyAdapter()
    {
      public void keyReleased(KeyEvent e)
      {
        parameterTable_keyReleased(e);
      }
    });
    contentPane.add(parameterScrollPane,      new GridBagConstraints(0, 0, 4, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(2, 2, 2, 2), 0, 0));
    parameterScrollPane.getViewport().add(parameterTable, null);
    contentPane.add(descriptionTextField,     new GridBagConstraints(0, 1, 4, 1, 1.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(2, 2, 2, 2), 0, 0));
    contentPane.add(jLabel1,      new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(2, 2, 2, 2), 0, 0));
    contentPane.add(newParameterValueTextField,      new GridBagConstraints(1, 2, 1, 1, 1.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(2, 2, 2, 0), 0, 0));
    contentPane.add(setButton,     new GridBagConstraints(2, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(2, 2, 2, 15), 0, 0));
    contentPane.add(closeButton,   new GridBagConstraints(3, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(2, 2, 2, 2), 0, 0));
  }

  private void setParameterValue(String name,Object value)
  {
    condition.setParameter(name,value);
    parameterTable.repaint();
  }

  void setButton_actionPerformed(ActionEvent e)
  {
    if (parameterTable.getSelectedRow() >= 0) {
      String selectedParameter = (String)parameterTable.getValueAt(parameterTable.getSelectedRow(),0);
      if (selectedParameter != null)
        setParameterValue(selectedParameter,newParameterValueTextField.getText());
    }
    newParameterValueTextField.setText("");
  }

  void newParameterValueTextField_keyReleased(KeyEvent e)
  {
    if (e.getKeyCode() == e.VK_ENTER) {
      if (parameterTable.getSelectedRow() >= 0) {
        String selectedParameter = (String)parameterTable.getValueAt(parameterTable.getSelectedRow(),0);
        if (selectedParameter != null)
          setParameterValue(selectedParameter,newParameterValueTextField.getText());
      }
      newParameterValueTextField.setText("");
    } else if (e.getKeyCode() == e.VK_DOWN) {
      if (conditionParameters.size() > 0) {
        int tmp = parameterTable.getSelectedRow();
        if (tmp < 0)
          parameterTable.setRowSelectionInterval(0,0);
        else if ((tmp+1) < conditionParameters.size())
          parameterTable.setRowSelectionInterval(tmp+1,tmp+1);
      }
      if (parameterTable.getSelectedRow() >= 0) {
        String selectedParameter = (String)parameterTable.getValueAt(parameterTable.getSelectedRow(),0);
        if (selectedParameter != null)
          descriptionTextField.setText((String)conditionParameters.get(selectedParameter));
      }
    } else if (e.getKeyCode() == e.VK_UP) {
      if (conditionParameters.size() > 0) {
        int tmp = parameterTable.getSelectedRow();
        if (tmp < 0)
          parameterTable.setRowSelectionInterval(0,0);
        else if ((tmp-1) >= 0)
          parameterTable.setRowSelectionInterval(tmp-1,tmp-1);
      }
      if (parameterTable.getSelectedRow() >= 0) {
        String selectedParameter = (String)parameterTable.getValueAt(parameterTable.getSelectedRow(),0);
        if (selectedParameter != null)
          descriptionTextField.setText((String)conditionParameters.get(selectedParameter));
      }
    }
  }

  void closeButton_actionPerformed(ActionEvent e)
  {
    this.setVisible(false);
    this.dispose();
  }

  void parameterTable_mouseReleased(MouseEvent e)
  {
    if (parameterTable.getSelectedRow() >= 0) {
      String selectedParameter = (String)parameterTable.getValueAt(parameterTable.getSelectedRow(),0);
      if (selectedParameter != null)
        descriptionTextField.setText((String)conditionParameters.get(selectedParameter));
    }
  }
  void parameterTable_mouseWheelMoved(MouseWheelEvent e)
  {
    if (parameterTable.getSelectedRow() >= 0) {
      String selectedParameter = (String)parameterTable.getValueAt(parameterTable.getSelectedRow(),0);
      if (selectedParameter != null)
        descriptionTextField.setText((String)conditionParameters.get(selectedParameter));
    }
  }
  void parameterTable_keyReleased(KeyEvent e)
  {
    if (parameterTable.getSelectedRow() >= 0) {
      String selectedParameter = (String)parameterTable.getValueAt(parameterTable.getSelectedRow(),0);
      if (selectedParameter != null)
        descriptionTextField.setText((String)conditionParameters.get(selectedParameter));
    }
  }
}
