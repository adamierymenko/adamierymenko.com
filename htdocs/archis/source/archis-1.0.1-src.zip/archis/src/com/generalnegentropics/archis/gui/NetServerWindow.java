package com.generalnegentropics.archis.gui;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

import javax.swing.*;
import javax.swing.table.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import java.net.InetAddress;
import com.generalnegentropics.archis.*;
import com.generalnegentropics.archis.net.*;

/**
 * Window for NetServer
 *
 * @author Adam Ierymenko
 * @version 1.0
 */

public class NetServerWindow extends JFrame implements NetObserver
{
  private NetServer netServer;
  private PrintStream textAreaPrintStream;
  private Object self;
  private JPanel contentPane;
  private String lastCommand;
  private ClientListRefresh clientListRefresh;
  private GridBagLayout gridBagLayout1 = new GridBagLayout();
  private JPanel topPanel = new JPanel();
  private GridBagLayout gridBagLayout2 = new GridBagLayout();
  private JLabel portLabel = new JLabel();
  private JLabel jLabel2 = new JLabel();
  private JLabel jLabel3 = new JLabel();
  private JLabel clientCountLabel = new JLabel();
  private JLabel jLabel5 = new JLabel();
  private JPanel bottomPanel = new JPanel();
  private JComboBox clientSelectComboBox = new JComboBox();
  private GridBagLayout gridBagLayout3 = new GridBagLayout();
  private JScrollPane commandScrollPane = new JScrollPane();
  private JTextArea commandTextArea = new JTextArea();
  private JTextField commandEntryTextField = new JTextField();
  private JMenuBar jMenuBar1 = new JMenuBar();
  private JMenu jMenu1 = new JMenu();
  private JMenuItem jMenuItem1 = new JMenuItem();
  private JMenuItem jMenuItem2 = new JMenuItem();
  private JTabbedPane jTabbedPane1 = new JTabbedPane();
  private JPanel statisticsPanel = new JPanel();
  private JPanel clientsPanel = new JPanel();
  private JScrollPane jScrollPane1 = new JScrollPane();
  private JTable statisticsTable = new JTable();
  private BorderLayout borderLayout1 = new BorderLayout();
  private BorderLayout borderLayout2 = new BorderLayout();
  private JScrollPane jScrollPane3 = new JScrollPane();
  private JList clientList = new JList();
  private JLabel jLabel1 = new JLabel();
  private JTextField logDirectoryTextField = new JTextField();

  //
  // Internal class for an OutputStream to the command text area
  //
  private static class TextAreaOutputStream extends OutputStream
  {
    private JTextArea textArea;
    private JScrollPane scrollPane;
    private StringBuffer buffer;
    private int maxLines,numLines;

    public TextAreaOutputStream(JTextArea output,JScrollPane scrollPane,int maxLines)
    {
      this.maxLines = maxLines;
      this.textArea = output;
      this.scrollPane = scrollPane;
      numLines = 0;
      buffer = new StringBuffer(1024);
    }

    public synchronized void write(int b)
      throws IOException
    {
      if (b != '\r') {
        if (b == '\n') {
          ++numLines;
          textArea.append(buffer.toString());
          SwingUtilities.invokeLater(new Runnable() {
            public void run()
            {
              Thread.yield();
              scrollPane.getVerticalScrollBar().setValue(textArea.getHeight() - textArea.getVisibleRect().height);
            }
          });
          buffer.delete(0,buffer.length());
        }
        buffer.append((char)b);
      }
    }
  }

  //
  // Table model for the network statistics table
  //
  public static class NetStatisticsTableModel implements TableModel,NetObserver
  {
    private static Class stringClass = "".getClass();
    private TableModelEvent tme;
    private NetServer netServer;
    private HashSet tableModelListeners;
    private SortedMap statistics;
    private Object[] statisticNames;
    private String simulationName;
    private int lastLength;

    public NetStatisticsTableModel(NetServer netServer)
    {
      tme = new TableModelEvent(this);
      tableModelListeners = new HashSet(32,0.75F);
      simulationName = null;
      statistics = null;
      statisticNames = null;
      this.netServer = netServer;
      lastLength = 0;
      netServer.addObserver(this);
    }

    public int getRowCount()
    {
      if ((statistics == null)||(statisticNames == null))
        return 0;
      return statisticNames.length;
    }

    public int getColumnCount()
    {
      return 3;
    }

    public String getColumnName(int columnIndex)
    {
      switch(columnIndex) {
        case 0:
          return "Simulation Name";
        case 1:
          return "Statistic";
        case 2:
          return "Value";
      }
      return "";
    }

    public Class getColumnClass(int columnIndex)
    {
      return stringClass;
    }

    public boolean isCellEditable(int rowIndex, int columnIndex)
    {
      return false;
    }

    public Object getValueAt(int rowIndex, int columnIndex)
    {
      if (simulationName == null) {
        int slashIndex;
        switch(columnIndex) {
          case 0:
            slashIndex = ((String)statisticNames[rowIndex]).indexOf('/');
            if (slashIndex <= 0)
              return "***ERROR***";
            return ((String)statisticNames[rowIndex]).substring(0,slashIndex);
          case 1:
            slashIndex = ((String)statisticNames[rowIndex]).indexOf('/');
            if (slashIndex <= 0)
              return "***ERROR***";
            try {
              return ((String)statisticNames[rowIndex]).substring(slashIndex+5);
            } catch (Throwable t) {
              return "***ERROR***";
            }
          case 2:
            return statistics.get(statisticNames[rowIndex]);
        }
      } else {
        switch(columnIndex) {
          case 0:
            return simulationName;
          case 1:
            try {
              return ((String)statisticNames[rowIndex]).substring(4);
            } catch (Throwable t) {
              return statisticNames[rowIndex];
            }
          case 2:
            return statistics.get(statisticNames[rowIndex]);
        }
      }
      return "";
    }

    public void setValueAt(Object aValue, int rowIndex, int columnIndex)
    {
    }

    public void addTableModelListener(TableModelListener l)
    {
      tableModelListeners.add(l);
    }

    public void removeTableModelListener(TableModelListener l)
    {
      tableModelListeners.remove(l);
    }

    //
    // Methods to implement NetObserver
    //
    public void clientConnect(InetAddress fromAddress,int fromPort)
    {
    }
    public void clientLogin(InetAddress fromAddress,int fromPort,String simulationName,long clock,String remoteVersion)
    {
    }
    public void clientDisconnect(InetAddress fromAddress,int fromPort,String simulationName)
    {
    }
    public void clientTickCompleted(String simulationName,long clock)
    {
      if (this.simulationName == null)
        statistics = netServer.getAllStatistics();
      else statistics = netServer.getStatistics(this.simulationName);
      statisticNames = statistics.keySet().toArray();
      if (statisticNames.length != lastLength) {
        synchronized(tableModelListeners) {
          for (Iterator i = tableModelListeners.iterator(); i.hasNext();)
            ((TableModelListener)i.next()).tableChanged(tme);
        }
      } else {
        synchronized(tableModelListeners) {
          TableModelEvent e = new TableModelEvent(this,0,statisticNames.length-1,2);
          for (Iterator i = tableModelListeners.iterator(); i.hasNext();)
            ((TableModelListener)i.next()).tableChanged(e);
        }
      }
      lastLength = statisticNames.length;
    }
  }

  //
  // Little class to refresh client list every .5 seconds
  //
  private class ClientListRefresh extends Thread
  {
    public boolean die;

    public ClientListRefresh()
    {
      super("NetServer Client List Refresher");
      super.setDaemon(true);
      die = false;
      start();
    }

    public void run()
    {
      for(;!die;) {
        try {
          Thread.sleep(500L);
        } catch (Throwable t) {}
        clientList.setListData(netServer.getClientDescriptions());
      }
    }
  }

  public NetServerWindow()
  {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
    this.setSize(750,550);
    Dimension ss = this.getToolkit().getScreenSize();
    this.setLocation((ss.width/2)-(this.getWidth()/2),(ss.height/2)-(this.getHeight()/2));
    this.setIconImage(Archis.ICON);
    netServer = null;
    textAreaPrintStream = new PrintStream(new TextAreaOutputStream(commandTextArea,commandScrollPane,1024),true);
    textAreaPrintStream.println("Archis Version "+Archis.ARCHIS_VERSION);
    textAreaPrintStream.println("NetServer Command Line Interface");
    textAreaPrintStream.println();
    commandEntryTextField.setFont(commandTextArea.getFont());
    lastCommand = null;

    // Start NetServer and prompt for port
    this.self = this; // dumb hack for anonymous class below
    SwingUtilities.invokeLater(new Runnable() {
      public void run()
      {
        String _port = JOptionPane.showInputDialog((Component)self,"Please enter the port number to start this NetServer on:","NetServer Listen Port",JOptionPane.QUESTION_MESSAGE);
        if (_port == null) {
          JOptionPane.showMessageDialog((Component)self,"You must enter a port","Illegal Port",JOptionPane.ERROR_MESSAGE);
          ((JFrame)self).setVisible(false);
          ((JFrame)self).dispose();
        } else {
          try {
            ((NetServerWindow)self).netServer = new NetServer(Integer.parseInt(_port));
            ((NetServerWindow)self).netServer.addObserver((NetObserver)self);
            ((NetServerWindow)self).netServer.setCommandTextOutput(textAreaPrintStream);
            ((NetServerWindow)self).refreshTopFrame();
            ((NetServerWindow)self).statisticsTable.setModel(new NetServerWindow.NetStatisticsTableModel(((NetServerWindow)self).netServer));
            ((NetServerWindow)self).statisticsTable.getColumnModel().getColumn(0).setResizable(false);
            ((NetServerWindow)self).statisticsTable.getColumnModel().getColumn(0).setMaxWidth(128);
            ((NetServerWindow)self).statisticsTable.getColumnModel().getColumn(0).setMinWidth(128);
            ((NetServerWindow)self).statisticsTable.getColumnModel().getColumn(0).setPreferredWidth(128);
            ((NetServerWindow)self).statisticsTable.getColumnModel().getColumn(2).setResizable(false);
            ((NetServerWindow)self).statisticsTable.getColumnModel().getColumn(2).setMaxWidth(128);
            ((NetServerWindow)self).statisticsTable.getColumnModel().getColumn(2).setMinWidth(128);
            ((NetServerWindow)self).statisticsTable.getColumnModel().getColumn(2).setPreferredWidth(128);
            clientListRefresh = new ClientListRefresh();
          } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog((Component)self,"Port must be a positive integer","Illegal Port",JOptionPane.ERROR_MESSAGE);
            ((JFrame)self).setVisible(false);
            ((JFrame)self).dispose();
          } catch (Throwable e) {
            JOptionPane.showMessageDialog((Component)self,"Could not start server: "+e.getMessage(),"Could not start NetServer",JOptionPane.ERROR_MESSAGE);
            ((JFrame)self).setVisible(false);
            ((JFrame)self).dispose();
          }
        }
      }
      });
  }
  private void jbInit() throws Exception {
    contentPane = (JPanel)this.getContentPane();
    contentPane.setLayout(gridBagLayout1);
    this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
    this.setJMenuBar(jMenuBar1);
    this.setTitle("Archis NetServer");
    this.addWindowListener(new java.awt.event.WindowAdapter()
    {
      public void windowClosing(WindowEvent e)
      {
        this_windowClosing(e);
      }
    });
    topPanel.setLayout(gridBagLayout2);
    clientCountLabel.setText("0");
    jLabel2.setHorizontalAlignment(SwingConstants.RIGHT);
    jLabel2.setHorizontalTextPosition(SwingConstants.RIGHT);
    jLabel2.setText("NetServer Listening On Port:");
    jLabel3.setHorizontalAlignment(SwingConstants.RIGHT);
    jLabel3.setHorizontalTextPosition(SwingConstants.RIGHT);
    jLabel3.setText("Clients Connected:");
    portLabel.setText("0");
    topPanel.setBorder(BorderFactory.createEtchedBorder());
    jLabel5.setText("Select a Client (or ALL):");
    bottomPanel.setBorder(BorderFactory.createEtchedBorder());
    bottomPanel.setLayout(gridBagLayout3);
    commandTextArea.setBackground(Color.black);
    commandTextArea.setFont(new java.awt.Font("Monospaced", 0, 12));
    commandTextArea.setForeground(Color.green);
    commandTextArea.setEditable(false);
    commandTextArea.setSelectedTextColor(Color.green);
    commandTextArea.setSelectionColor(Color.darkGray);
    commandTextArea.setLineWrap(false);
    commandTextArea.setWrapStyleWord(false);
    commandTextArea.setOpaque(true);
    commandEntryTextField.setBackground(Color.black);
    commandEntryTextField.setForeground(Color.green);
    commandEntryTextField.setCaretColor(Color.white);
    commandEntryTextField.setMargin(new Insets(2, 2, 2, 2));
    commandEntryTextField.setSelectedTextColor(Color.green);
    commandEntryTextField.setSelectionColor(Color.darkGray);
    commandEntryTextField.setOpaque(true);
    commandEntryTextField.addKeyListener(new java.awt.event.KeyAdapter()
    {
      public void keyReleased(KeyEvent e)
      {
        commandEntryTextField_keyReleased(e);
      }
    });
    commandScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
    commandScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    jMenu1.setText("File");
    jMenuItem1.setText("Set Statistics Log File Directory");
    jMenuItem1.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        jMenuItem1_actionPerformed(e);
      }
    });
    jMenuItem2.setText("Terminate NetServer");
    jMenuItem2.addActionListener(new java.awt.event.ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        jMenuItem2_actionPerformed(e);
      }
    });
    jScrollPane1.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    statisticsPanel.setLayout(borderLayout1);
    clientsPanel.setLayout(borderLayout2);
    jScrollPane3.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    jLabel1.setHorizontalAlignment(SwingConstants.RIGHT);
    jLabel1.setHorizontalTextPosition(SwingConstants.RIGHT);
    jLabel1.setText("Log Directory:");
    logDirectoryTextField.setBorder(null);
    logDirectoryTextField.setOpaque(false);
    logDirectoryTextField.setText("(none)");
    contentPane.add(topPanel,          new GridBagConstraints(0, 0, 1, 1, 1.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(2, 2, 0, 2), 0, 0));
    topPanel.add(portLabel,       new GridBagConstraints(1, 0, 1, 1, 0.5, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(2, 0, 0, 0), 0, 0));
    topPanel.add(jLabel2,         new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(2, 5, 0, 2), 0, 0));
    topPanel.add(jLabel3,        new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.NORTH, GridBagConstraints.HORIZONTAL, new Insets(0, 5, 0, 2), 0, 0));
    topPanel.add(clientCountLabel,      new GridBagConstraints(1, 1, 1, 2, 0.5, 0.0
            ,GridBagConstraints.NORTH, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 0, 0), 0, 0));
    topPanel.add(jLabel5,      new GridBagConstraints(2, 0, 1, 1, 1.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(2, 2, 0, 5), 0, 0));
    topPanel.add(clientSelectComboBox,        new GridBagConstraints(2, 1, 1, 3, 1.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, 2, 2, 5), 0, 0));
    topPanel.add(jLabel1,     new GridBagConstraints(0, 2, 1, 2, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, 5, 2, 2), 0, 0));
    topPanel.add(logDirectoryTextField,  new GridBagConstraints(1, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 2, 0), 0, 0));
    contentPane.add(bottomPanel,     new GridBagConstraints(0, 3, 1, 1, 1.0, 1.5
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(2, 2, 2, 2), 0, 0));
    bottomPanel.add(commandScrollPane,       new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(2, 2, 2, 2), 0, 0));
    bottomPanel.add(commandEntryTextField,  new GridBagConstraints(0, 1, 1, 1, 1.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, 2, 2, 2), 0, 0));
    contentPane.add(jTabbedPane1,   new GridBagConstraints(0, 1, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
    jTabbedPane1.add(statisticsPanel,  "Statistics");
    statisticsPanel.add(jScrollPane1,  BorderLayout.CENTER);
    jScrollPane1.getViewport().add(statisticsTable, null);
    jTabbedPane1.add(clientsPanel,  "Clients");
    clientsPanel.add(jScrollPane3,  BorderLayout.CENTER);
    jScrollPane3.getViewport().add(clientList, null);
    commandScrollPane.getViewport().add(commandTextArea, null);
    jMenuBar1.add(jMenu1);
    jMenu1.add(jMenuItem1);
    jMenu1.addSeparator();
    jMenu1.add(jMenuItem2);
  }

  void this_windowClosing(WindowEvent e)
  {
    if (JOptionPane.showConfirmDialog(this,"Really terminate this NetServer?","Terminate NetServer",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION) {
      if (netServer != null)
        netServer.kill();
      if (clientListRefresh != null)
        clientListRefresh.die = true;
      this.setVisible(false);
      this.dispose();
    }
  }

  void commandEntryTextField_keyReleased(KeyEvent e)
  {
    if (e.getKeyCode() == e.VK_ENTER) {
      String selectedClient = (String)clientSelectComboBox.getSelectedItem();
      String cmd = commandEntryTextField.getText().trim();
      if (selectedClient != null) {
        if (selectedClient.equals("ALL CLIENTS")) {
          textAreaPrintStream.print("-> (ALL CLIENTS) ");
          textAreaPrintStream.println(cmd);
          try {
            netServer.sendCommandToAll(cmd,true);
          } catch (IOException ex) {
            JOptionPane.showMessageDialog(this,"I/O error sending to client(s): "+ex.getMessage(),"I/O Error",JOptionPane.ERROR_MESSAGE);
          }
        } else {
          textAreaPrintStream.print("-> [");
          textAreaPrintStream.print(selectedClient);
          textAreaPrintStream.print("] ");
          textAreaPrintStream.println(cmd);
          try {
            netServer.sendCommand(selectedClient,cmd,true);
          } catch (IOException ex) {
            JOptionPane.showMessageDialog(this,"I/O error sending to client: "+ex.getMessage(),"I/O Error",JOptionPane.ERROR_MESSAGE);
          }
        }
      }
      lastCommand = cmd;
      commandEntryTextField.setText("");
    } else if (e.getKeyCode() == e.VK_UP) {
      if (lastCommand != null)
        commandEntryTextField.setText(lastCommand);
    }
  }

  /**
   * Refreshes the top frame data
   */
  private void refreshTopFrame()
  {
    portLabel.setText(Integer.toString(netServer.getPort()));
    Object currentSelectedClient = clientSelectComboBox.getSelectedItem();
    clientSelectComboBox.removeAllItems();
    clientSelectComboBox.addItem("ALL CLIENTS");
    String[] clients = netServer.getClients();
    Arrays.sort(clients);
    boolean hasCurrent = false;
    for(int i=0;i<clients.length;i++) {
      clientSelectComboBox.addItem(clients[i]);
      if (clients[i].equals(currentSelectedClient))
        hasCurrent = true;
    }
    if ((!hasCurrent)||(currentSelectedClient == null))
      clientSelectComboBox.setSelectedItem("ALL CLIENTS");
    else clientSelectComboBox.setSelectedItem(currentSelectedClient);
    clientCountLabel.setText(Integer.toString(clients.length));
  }

  void jMenuItem2_actionPerformed(ActionEvent e)
  {
    // Terminate
    if (JOptionPane.showConfirmDialog(this,"Really terminate this NetServer?","Terminate NetServer",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION) {
      if (netServer != null)
        netServer.kill();
      if (clientListRefresh != null)
        clientListRefresh.die = true;
      this.setVisible(false);
      this.dispose();
    }
  }

  void jMenuItem1_actionPerformed(ActionEvent e)
  {
    // Set log file directory
    String dn = JOptionPane.showInputDialog(this,"Enter a directory to save statistics from each simulation (empty for none):","Enter Log Directory",JOptionPane.QUESTION_MESSAGE);
    dn = dn.trim();
    if (dn.length() <= 0) {
      netServer.setLogDirectory(null);
    } else {
      File logDir = new File(dn);
      if (!logDir.exists())
        JOptionPane.showMessageDialog(this,"Directory does not exist.","Bad Log Directory",JOptionPane.ERROR_MESSAGE);
      else if (!logDir.isDirectory())
        JOptionPane.showMessageDialog(this,"Specified path is not a directory.","Bad Log Directory",JOptionPane.ERROR_MESSAGE);
      else if (!logDir.canWrite())
        JOptionPane.showMessageDialog(this,"Directory does not have write permission.","Bad Log Directory",JOptionPane.ERROR_MESSAGE);
      else netServer.setLogDirectory(logDir);
    }
    File ld = netServer.getLogDirectory();
    if (ld == null)
      logDirectoryTextField.setText("(none)");
    else logDirectoryTextField.setText(ld.getAbsolutePath());
  }

  //
  // Methods to implement NetObserver
  //
  public void clientConnect(InetAddress fromAddress,int fromPort)
  {
    SwingUtilities.invokeLater(new Runnable() {
      public void run()
      {
        refreshTopFrame();
      }
    });
  }
  public synchronized void clientLogin(InetAddress fromAddress,int fromPort,String simulationName,long clock,String remoteVersion)
  {
    SwingUtilities.invokeLater(new Runnable() {
      public void run()
      {
        refreshTopFrame();
      }
    });
  }
  public synchronized void clientDisconnect(InetAddress fromAddress,int fromPort,String simulationName)
  {
    SwingUtilities.invokeLater(new Runnable() {
      public void run()
      {
        refreshTopFrame();
      }
    });
  }
  public void clientTickCompleted(String simulationName,long clock)
  {
  }
}
