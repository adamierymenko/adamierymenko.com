package com.generalnegentropics.archis.net;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

import java.io.*;
import java.util.ArrayList;
import java.util.zip.Inflater;
import java.util.zip.DataFormatException;

/**
 * <p>Protocol input stream handler</p>
 *
 * <p>Protocol consists of a stream of CR-delimited lines in which ~ is the
 * word-delimiter and \ is the escape character.</p>
 *
 * <p>Like ArchisProtocolOutput, this handles buffering and compression.</p>
 *
 * @author Adam Ierymenko
 * @version 1.0
 */

public class ArchisProtocolInput
{
  private InputStream inStream;
  private byte[] readBuffer,inBuffer;
  private int readPtr;
  private int thisDataBlockSize;
  private ArrayList messageBuffer;
  private char[] wordBuffer;
  private Inflater inflater;
  private long compressedBytesIn;
  private long decompressedBytesIn;

  /**
   * Constructs a new protocol input
   *
   * @param inStream Input stream to connect to
   * @param blockSize Size of input buffer
   */
  public ArchisProtocolInput(InputStream inStream,int blockSize)
  {
    this.inStream = new BufferedInputStream(inStream,blockSize);
    messageBuffer = new ArrayList(128);
    wordBuffer = new char[1024];
    readBuffer = new byte[blockSize+1024];
    inBuffer = new byte[blockSize];
    readPtr = 0;
    thisDataBlockSize = 0;
    inflater = new Inflater(false);
  }

  /**
   * Gets the compression ratio
   *
   * @return Compression ratio
   */
  public double getCompressionRatio()
  {
    if (decompressedBytesIn <= 0L)
      return 0.0;
    return (double)compressedBytesIn / (double)decompressedBytesIn;
  }

  /**
   * Reads a packet as an array of strings
   *
   * @throws IOException I/O error
   * @return Packet data (is never null, may be zero-length array)
   */
  public synchronized String[] readPacket()
    throws IOException
  {
    boolean escapeMode = false;
    int wordBufferPtr = 0;
    messageBuffer.clear();
    for(boolean messageComplete = false;!messageComplete;) {
      // Read another block if necessary
      if (readPtr >= thisDataBlockSize) {
        int s = (inStream.read() & 0x000000ff) | ((inStream.read() << 8) & 0x0000ff00) | ((inStream.read() << 16) & 0x00ff0000) | ((inStream.read() << 24) & 0xff000000);
        if ((s < 0)||(s >= readBuffer.length))
          throw new IOException("Stream corrupt, bad block size of "+s);
        int rc = 0;
        while (rc < s)
          rc += inStream.read(readBuffer,rc,s-rc);
        compressedBytesIn += (long)(s+4);
        inflater.setInput(readBuffer,0,s);
        try {
          thisDataBlockSize = inflater.inflate(inBuffer,0,inBuffer.length);
          decompressedBytesIn += (long)thisDataBlockSize;
          readPtr = 0;
        } catch (DataFormatException e) {
          throw new IOException("Error inflating data block: "+e.getMessage());
        }
        inflater.reset();
      }

      // Process current character
      if (escapeMode) {
        wordBuffer[wordBufferPtr++] = (char)inBuffer[readPtr++];
        escapeMode = false;
      } else {
        char c = (char)inBuffer[readPtr++];
        switch(c) {
          case '\\':
            // Escape character
            escapeMode = true;
            break;
          case '~':
            // Word seperator
            messageBuffer.add(new String(wordBuffer,0,wordBufferPtr));
            wordBufferPtr = 0;
            break;
          case '\r':
            // Ignore Windoze-style \r\n linebreaks
            break;
          case '\n':
            // End of message
            if (wordBufferPtr > 0) {
              messageBuffer.add(new String(wordBuffer,0,wordBufferPtr));
              wordBufferPtr = 0;
            }
            messageComplete = true;
            break;
          default:
            wordBuffer[wordBufferPtr++] = c;
            break;
        }
      }

      // Enlarge wordBuffer if necessary
      if (wordBufferPtr >= wordBuffer.length) {
        char[] tmp = new char[wordBuffer.length+1024];
        for(int i=0;i<wordBuffer.length;i++)
          tmp[i] = wordBuffer[i];
        wordBuffer = tmp;
      }
    }

    // Return array of strings
    String[] msg = new String[messageBuffer.size()];
    for(int i=0;i<msg.length;i++)
      msg[i] = (String)messageBuffer.get(i);
    return msg;
  }

  /**
   * Closes the underlying stream
   *
   * @throws IOException I/O error
   */
  public synchronized void close()
    throws IOException
  {
    inStream.close();
  }
}
