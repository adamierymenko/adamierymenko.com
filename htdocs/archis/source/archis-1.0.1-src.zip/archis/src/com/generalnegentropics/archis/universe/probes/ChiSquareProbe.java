package com.generalnegentropics.archis.universe.probes;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

import java.util.*;
import java.lang.ref.WeakReference;
import com.generalnegentropics.archis.*;
import com.generalnegentropics.archis.universe.*;
import com.generalnegentropics.archis.life.*;
import com.generalnegentropics.archis.utils.RealNumberDataListener;

/**
 * Measures the chi-square of the codon frequency of all genomes
 *
 * @author Adam Ierymenko
 * @version 1.0
 */

public class ChiSquareProbe implements Probe
{
  public static final String PROBE_DESCRIPTION = "Measures the chi-square codon frequency of all genomes in universe.";
  private Universe universe;
  private Simulation simulation;
  private HashMap genomeTypeCounts;
  private HashSet dataListeners;

  //
  // Internal data structure stored in genomeTypeCounts
  //
  private static class GTC
  {
    public long[] codonCounts;
    public int numCodons;
    public long totalGenomeSize;
    public double lastChiSquareSum;
  }

  /**
   * Constructs a new chi-square probe
   */
  public ChiSquareProbe()
  {
    genomeTypeCounts = new HashMap(32,0.75F);
    dataListeners = new HashSet(6,0.95F);
  }

  public void addDataListener(RealNumberDataListener dataListener)
  {
    synchronized(dataListeners) {
      dataListeners.add(new WeakReference(dataListener));
    }
  }

  public void showGUI()
  {
    new com.generalnegentropics.archis.gui.probes.ChiSquareProbeWindow(this,simulation).setVisible(true);
  }

  public void init(Universe universe, Simulation simulation)
  {
    this.universe = universe;
    this.simulation = simulation;
  }

  public void destroy()
  {
  }

  public void preTickNotify()
  {
  }

  public void postTickNotify()
  {
    double chiSquareSum = 0.0;
    double chiSquareStatCount = 0.0;
    synchronized(genomeTypeCounts) {
      for (Iterator it=genomeTypeCounts.entrySet().iterator();it.hasNext();) {
        Map.Entry ent = (Map.Entry)it.next();
        String gcn = (String)ent.getKey();
        GTC gtc = (GTC)ent.getValue();
        double expectedFrequency = (double)gtc.totalGenomeSize / (double)gtc.numCodons;
        double myChiSquareSum = 0.0;
        if (expectedFrequency > 0.0) {
          double tmp;
          for(int i=0;i<gtc.codonCounts.length;i++) {
            tmp = (double)gtc.codonCounts[i] - expectedFrequency;
            myChiSquareSum += (tmp * tmp) / expectedFrequency;
            gtc.codonCounts[i] = 0L;
          }
          myChiSquareSum /= (double)gtc.numCodons;
        } else {
          for(int i=0;i<gtc.codonCounts.length;i++)
            gtc.codonCounts[i] = 0L;
        }
        gtc.totalGenomeSize = 0L;
        gtc.lastChiSquareSum = myChiSquareSum;
        chiSquareSum += myChiSquareSum;
        chiSquareStatCount += 1.0;
      }
    }

    if (chiSquareStatCount > 0.0)
      chiSquareSum /= chiSquareStatCount;
    else chiSquareSum = 0.0;

    synchronized(dataListeners) {
      for (Iterator i=dataListeners.iterator();i.hasNext();) {
        Object dl = ((WeakReference)i.next()).get();
        if (dl == null)
          i.remove();
        else ((RealNumberDataListener)dl).input(universe.clock(),chiSquareSum);
      }
    }

    simulation.setStatistic("CSP ChiSquareProbe.chiSquareFrequencyDeviation",chiSquareSum);
  }

  public void probeScanCell(Cell cell)
  {
    if (cell.alive()) {
      Genome g = cell.genome();
      String gcn = g.getClass().getName();
      GTC gtc;
      synchronized(genomeTypeCounts) {
        gtc = (GTC)genomeTypeCounts.get(gcn);
      }
      if (gtc == null) {
        gtc = new GTC();
        gtc.numCodons = g.getCodonCount();
        gtc.codonCounts = new long[gtc.numCodons];
        gtc.totalGenomeSize = 0L;
        gtc.lastChiSquareSum = 0.0;
        synchronized(genomeTypeCounts) {
          genomeTypeCounts.put(gcn,gtc);
        }
      }
      synchronized(gtc) {
        gtc.totalGenomeSize += (long)g.size();
        g.getCodonDistribution(gtc.codonCounts);
      }
    }
  }

  public void probeNewCell(Cell parent,Cell newCell)
  {
  }
}
