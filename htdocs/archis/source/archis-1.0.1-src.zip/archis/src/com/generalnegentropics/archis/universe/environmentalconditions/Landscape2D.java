package com.generalnegentropics.archis.universe.environmentalconditions;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

import java.util.*;
import java.io.*;
import java.awt.image.BufferedImage;
import com.generalnegentropics.archis.utils.*;
import com.generalnegentropics.archis.*;
import com.generalnegentropics.archis.universe.*;
import com.generalnegentropics.archis.life.*;
import com.generalnegentropics.archis.gui.conditions.*;

/**
 * <p>Implements a two-dimensional landscape with cell-cell interaction.</p>
 *
 * @author Adam Ierymenko
 * @version 3.0
 */

public class Landscape2D implements EnvironmentalCondition
{
  /**
   * Description of condition
   */
  public static final String CONDITION_DESCRIPTION = "Two dimensional landscape permitting many types of cell-cell interaction.";

  //
  // Directions
  //
  private static final int NORTH = 1;
  private static final int SOUTH = (1 << 1);
  private static final int EAST = (1 << 2);
  private static final int WEST = (1 << 3);
  private static final int NORTHEAST = (NORTH & EAST);
  private static final int NORTHWEST = (NORTH & WEST);
  private static final int SOUTHEAST = (SOUTH & EAST);
  private static final int SOUTHWEST = (SOUTH & WEST);

  //
  // Directions to move to get to adjacent blocks on a 7x7 grid
  //
  /* private static final int[] ADJACENT7X7_CELL_DIRECTIONS = {
    NORTHWEST,NORTHWEST,NORTH    ,NORTH    ,NORTH    ,NORTHEAST,NORTHEAST,
    WEST     ,NORTHWEST,NORTHWEST,NORTH    ,NORTHEAST,NORTHEAST,EAST,
    WEST     ,WEST     ,NORTHWEST,NORTH    ,NORTHEAST,EAST     ,EAST,
    WEST     ,WEST     ,WEST     ,0        ,EAST     ,EAST     ,EAST,
    WEST     ,WEST     ,SOUTHWEST,SOUTH    ,SOUTHEAST,EAST     ,EAST,
    WEST     ,SOUTHWEST,SOUTHWEST,SOUTH    ,SOUTHEAST,SOUTHEAST,EAST,
    SOUTHWEST,SOUTHWEST,SOUTH    ,SOUTH    ,SOUTH    ,SOUTHEAST,SOUTHEAST
    }; */

  //
  // What to add or subtract to/from x,y coordinates to get to adjacent blocks
  // on a 7x7 grid
  //
  /* private static final int[][] ADJACENT7X7_CELL_MATH = {
    { -3,3  },{ -2,3  },{ -1,3  },{ 0,3  },{ 1,3  },{ 2,3  },{ 3,3  }, // 0
    { -3,2  },{ -2,2  },{ -1,2  },{ 0,2  },{ 1,2  },{ 2,2  },{ 3,2  }, // 1
    { -3,1  },{ -2,1  },{ -1,1  },{ 0,1  },{ 1,1  },{ 2,1  },{ 3,1  }, // 2
    { -3,0  },{ -2,0  },{ -1,0  },         { 1,0  },{ 2,0  },{ 3,0  }, // 3
    { -3,-1 },{ -2,-1 },{ -1,-1 },{ 0,-1 },{ 1,-1 },{ 2,-1 },{ 3,-1 }, // 4
    { -3,-2 },{ -2,-2 },{ -1,-2 },{ 0,-2 },{ 1,-2 },{ 2,-2 },{ 3,-2 }, // 5
    { -3,-3 },{ -2,-3 },{ -1,-3 },{ 0,-3 },{ 1,-3 },{ 2,-3 },{ 3,-3 }  // 6
    //    0         1         2        3        4        5        6
    }; */

  //
  // Describes a kind of spiraling order for the scanning of the 7x7 block
  // matrix.
  //
  /* private static final int[][] ADJACENT7X7_SEQUENCE = {
    { 2,3 },{ 2,4 },{ 3,4 },{ 4,4 },{ 4,3 },{ 4,2 },{ 3,2 },{ 2,2 },
    { 1,3 },{ 1,4 },{ 1,5 },{ 2,5 },{ 3,5 },{ 4,5 },{ 5,5 },{ 5,4 },{ 5,3 },
      { 5,2 },{ 5,1 },{ 4,1 },{ 3,1 },{ 2,1 },{ 1,1 },{ 1,2 },
    { 0,3 },{ 0,4 },{ 0,5 },{ 0,6 },{ 1,6 },{ 2,6 },{ 3,6 },{ 4,6 },{ 5,6 },
      { 6,6 },{ 6,5 },{ 6,4 },{ 6,3 },{ 6,2 },{ 6,1 },{ 6,0 },{ 5,0 },{ 4,0 },
      { 3,0 },{ 2,0 },{ 1,0 },{ 0,1 },{ 0,2 }
    }; */

  //
  // What to add to x,y coordinates to get to adjacent cells on a 3x3 grid
  //
  private static final int[][] ADJACENT3X3_CELL_MATH = {
    { -1,1  },{ 0,1  },{ 1,1  },
    { -1,0  },         { 1,0  },
    { -1,-1 },{ 0,-1 },{ 1,-1 }
    };

  private static final int[] ADJACENT3X3_CELL_DIRECTIONS = {
    NORTHWEST,NORTH,NORTHEAST,
    WEST     ,0    ,EAST,
    SOUTHWEST,SOUTH,SOUTHEAST
  };

  /**
   * Represents an X,Y location in the landscape
   *
   * @author Adam Ierymenko
   * @version 1.0
   */
  public static class XYLocation implements Externalizable
  {
    /**
     * X location
     */
    public int x;

    /**
     * Y location
     */
    public int y;

    /**
     * Null constructor to implement Externalizable or create disposable
     * copies.
     */
    public XYLocation()
    {
      x = y = 0;
    }

    /**
     * Constructs a new XYLocation
     *
     * @param x X location
     * @param y Y location
     */
    public XYLocation(int x,int y)
    {
      this.x = x;
      this.y = y;
    }

    //
    // Methods to implement Externalizable
    //
    public void writeExternal(ObjectOutput out)
      throws IOException
    {
      out.writeInt(x);
      out.writeInt(y);
    }
    public void readExternal(ObjectInput in)
      throws IOException
    {
      x = in.readInt();
      y = in.readInt();
    }

    /**
     * Returns a hash code
     *
     * @return Hash code is (x * y)
     */
    public int hashCode()
    {
      return (x * y);
    }

    /**
     * Tests for equality with another object
     *
     * @param o Object to test against
     * @return True if other object is XYLocation with the same values
     */
    public boolean equals(Object o)
    {
      if (o != null) {
        if (o instanceof XYLocation) {
          if ((((XYLocation)o).x == x)&&(((XYLocation)o).y == y))
            return true;
        }
      }
      return false;
    }

    /**
     * Returns "x,y" as a string
     *
     * @return String representation
     */
    public String toString()
    {
      return Integer.toString(x)+","+Integer.toString(y);
    }
  }

  //
  // An Integer container that's openly modifiable
  //
  private static class ModifiableInteger extends Number implements Externalizable
  {
    public int value;

    //
    // Methods to implement Externalizable
    //
    public void writeExternal(ObjectOutput out)
      throws IOException
    {
      out.writeInt(value);
    }
    public void readExternal(ObjectInput in)
      throws IOException
    {
      value = in.readInt();
    }

    public ModifiableInteger(int value)
    {
      super();
      this.value = value;
    }
    public ModifiableInteger()
    {
      super();
      this.value = 0;
    }

    public double doubleValue()
    {
      return (double)value;
    }
    public int intValue()
    {
      return value;
    }
    public float floatValue()
    {
      return (float)value;
    }
    public short shortValue()
    {
      return (short)value;
    }
    public byte byteValue()
    {
      return (byte)value;
    }
    public long longValue()
    {
      return (long)value;
    }

    public String toString()
    {
      return Integer.toString(value);
    }
  }

  /**
   * Data structure stored as cell meta-info for landscape
   *
   * @author Adam Ierymenko
   * @version 1.0
   */
  public static class Landscape2DCellMetaInfo implements Externalizable
  {
    public Landscape2D.XYLocation location;
    public boolean hasNewCellSurfaceProtein;
    public int newCellSurfaceProtein;
    public int neighborEnergyTransfer;
    public List communicationInputBuffer;
    public int mpX,mpY,mpXPending,mpYPending;
    public EfficientByteBuffer genomeConcatenateBuffer;

    //
    // Methods to implement Externalizable
    //
    public void writeExternal(ObjectOutput out)
      throws IOException
    {
      out.writeInt(location.x);
      out.writeInt(location.y);
      out.writeBoolean(hasNewCellSurfaceProtein);
      out.writeInt(newCellSurfaceProtein);
      out.writeInt(neighborEnergyTransfer);
      if (communicationInputBuffer != null) {
        out.writeBoolean(true);
        out.writeObject(communicationInputBuffer.toArray());
      } else out.writeBoolean(false);
      out.writeInt(mpX);
      out.writeInt(mpY);
      out.writeInt(mpXPending);
      out.writeInt(mpYPending);
      if (genomeConcatenateBuffer != null) {
        out.writeBoolean(true);
        out.writeObject(genomeConcatenateBuffer.getData());
      } else out.writeBoolean(false);
    }
    public void readExternal(ObjectInput in)
      throws IOException
    {
      try {
        location = new XYLocation(in.readInt(),in.readInt());
        hasNewCellSurfaceProtein = in.readBoolean();
        newCellSurfaceProtein = in.readInt();
        neighborEnergyTransfer = in.readInt();
        if (in.readBoolean()) {
          communicationInputBuffer = new CommunicationsBufferIntegerInput();
          Object[] tmp = (Object[])in.readObject();
          if (tmp != null) {
            for(int i=0;i<tmp.length;i++)
              communicationInputBuffer.add(tmp[i]);
          }
        }
        mpX = in.readInt();
        mpY = in.readInt();
        mpXPending = in.readInt();
        mpYPending = in.readInt();
        if (in.readBoolean()) {
          byte[] tmp = (byte[])in.readObject();
          if (tmp != null) {
            genomeConcatenateBuffer = new EfficientByteBuffer(tmp.length+16);
            for(int i=0;i<tmp.length;i++)
              genomeConcatenateBuffer.add(tmp[i]);
          }
        }
      } catch (ClassNotFoundException e) {
        throw new StreamCorruptedException("Stream contained unknown class: "+e.toString());
      }
    }

    public Landscape2DCellMetaInfo()
    {
    }
  }

  //
  // Internal class to provide an IntegerInput for communication data, extends
  // LinkedList so that it can be used as the buffer itself as well
  //
  private static class CommunicationsBufferIntegerInput extends LinkedList implements IntegerInput
  {
    public CommunicationsBufferIntegerInput()
    {
      super();
    }

    public int read()
    {
      return ((size() > 0) ? ((Number)removeFirst()).intValue() : 0);
    }
  }

  //
  // Internal class to provide vision of neighboring cells' directions
  //
  private class NeighboringCellDirectionVision implements IntegerInput
  {
    private int ctr;
    private XYLocation loc;

    public NeighboringCellDirectionVision(XYLocation loc,int startPos)
    {
      ctr = startPos;
      this.loc = loc;
    }

    public int read()
    {
      if (ctr >= ADJACENT3X3_CELL_MATH.length)
        ctr = 0;
      int x = loc.x + ADJACENT3X3_CELL_MATH[ctr][0];
      int y = loc.y + ADJACENT3X3_CELL_MATH[ctr][1];
      if (x < 0)
        x += landscape.length;
      else if (x >= landscape.length)
        x -= landscape.length;
      if (y < 0)
        y += landscape[0].length;
      else if (y >= landscape[0].length)
        y -= landscape[0].length;
      if (landscape[x][y] != null) {
        if (landscape[x][y] instanceof Cell)
          return ADJACENT3X3_CELL_DIRECTIONS[ctr];
      }
      ++ctr;
      return 0;
    }
  }

  //
  // Internal class to provide vision of neighboring cells' surface proteins
  //
  private class NeighboringCellSurfaceProteinVision implements IntegerInput
  {
    private int ctr;
    private XYLocation loc;

    public NeighboringCellSurfaceProteinVision(XYLocation loc,int startPos)
    {
      ctr = startPos;
      this.loc = loc;
    }

    public int read()
    {
      if (ctr >= ADJACENT3X3_CELL_MATH.length)
        ctr = 0;
      int x = loc.x + ADJACENT3X3_CELL_MATH[ctr][0];
      int y = loc.y + ADJACENT3X3_CELL_MATH[ctr][1];
      if (x < 0)
        x += landscape.length;
      else if (x >= landscape.length)
        x -= landscape.length;
      if (y < 0)
        y += landscape[0].length;
      else if (y >= landscape[0].length)
        y -= landscape[0].length;
      if (landscape[x][y] != null) {
        if (landscape[x][y] instanceof Cell)
          return ((Cell)landscape[x][y]).getCellSurfaceProteinIntValue();
      }
      ++ctr;
      return 0;
    }
  }

  /**
   * Key for Landscape2D meta-info in cells
   */
  public static final Object CELL_INFO_LANDSCAPE2D = new Integer(0x11110001);

  private static Map parameters;
  static
  {
    parameters = new TreeMap();
    parameters.put("maxCommunicationBufferSize","Maximum size of inter-cellular communication buffers");
    parameters.put("negativeCellSurfaceProteinAdhesion","Do negative cell surface proteins adhere?");
    parameters.put("negativeCellSurfaceProteinEnergyTransfer","Can cells with negative cell surface proteins transfer energy?");
    parameters.put("negativeCellSurfaceProteinGenomeTransfer","Can cells with negative cell surface proteins do genetic transfers?");
    parameters.put("negativeCellSurfaceProteinCommunication","Can cells with negative cell surface proteins communicate?");
    parameters.put("zeroCellSurfaceProteinAdhesion","Do zero cell surface proteins adhere?");
    parameters.put("zeroCellSurfaceProteinEnergyTransfer","Can cells with zero cell surface proteins transfer energy?");
    parameters.put("zeroCellSurfaceProteinGenomeTransfer","Can cells with zero cell surface proteins do genetic transfers?");
    parameters.put("zeroCellSurfaceProteinCommunication","Can cells with zero cell surface proteins communicate?");
    parameters.put("positiveCellSurfaceProteinAdhesion","Do positive cell surface proteins adhere?");
    parameters.put("positiveCellSurfaceProteinEnergyTransfer","Can cells with positive cell surface proteins transfer energy?");
    parameters.put("positiveCellSurfaceProteinGenomeTransfer","Can cells with positive cell surface proteins do genetic transfers?");
    parameters.put("positiveCellSurfaceProteinCommunication","Can cells with positive cell surface proteins communicate?");
    parameters.put("maintainEnergy","Energy level to maintain in universe by adding free energy");
    parameters.put("maintainEnergyDensity","Maximum energy to add at each location when maintaining energy");
    parameters.put("maxGeneTransfer","Maximum size of gene transfer buffers");
    parameters.put("landscapeSize","Landscape size (nxn) (set to initialize flat landscape)");
    parameters = Collections.unmodifiableMap(parameters);
  }

  // -------------------------------------------------------------------------

  //
  // Universe and Simulation objects set when init() is called
  //
  private Universe universe;
  private Simulation simulation;

  //
  // Landscape is a nxn grid of Objects
  //
  // Contents can be a Cell or a Number.  A positive Number represents
  // energy while a negative Number represents a solid block.  A null
  // represents an empty block.
  //
  private Object[][] landscape;

  //
  // General settings
  //
  private int maxCommunicationBufferSize;

  //
  // Statistics
  //
  private volatile long stat_totalFreeEnergy;
  private volatile int stat_movementThisTurn;
  private volatile int stat_energyTransfers;
  private volatile int stat_genomeTransfers;
  private volatile int stat_adheredMotion;
  private volatile int stat_communications;

  //
  // Cell surface protein behaviors
  //
  private boolean negativeCellSurfaceProteinAdhesion,negativeCellSurfaceProteinEnergyTransfer,negativeCellSurfaceProteinGenomeTransfer,negativeCellSurfaceProteinCommunication;
  private boolean zeroCellSurfaceProteinAdhesion,zeroCellSurfaceProteinEnergyTransfer,zeroCellSurfaceProteinGenomeTransfer,zeroCellSurfaceProteinCommunication;
  private boolean positiveCellSurfaceProteinAdhesion,positiveCellSurfaceProteinEnergyTransfer,positiveCellSurfaceProteinGenomeTransfer,positiveCellSurfaceProteinCommunication;

  //
  // Maintain energy setting
  //
  private long maintainEnergy;
  private int maintainEnergyDensity;

  //
  // Limit for gene transfer per cell in a single tick
  //
  private int maxGeneTransfer;

  //
  // Source of random numbers
  //
  private RandomSource randomSource;

  //
  // Observer
  //
  private Landscape2DObserver observer;

  /**
   * Returns an estimate of memory usage
   *
   * @param sizeX Size X
   * @param sizeY Size Y
   * @return Memory usage estimate in bytes
   */
  public static long estimateMemoryUsage(int sizeX,int sizeY)
  {
    return (((long)sizeX * (long)sizeY) * 4L);
  }

  /**
   * Constructs a new 2d landscape environmental condition
   */
  public Landscape2D()
  {
    landscape = null;
    observer = null;

    maintainEnergy = 0L;
    maintainEnergyDensity = 100000;
    maxGeneTransfer = 16384;
    maxCommunicationBufferSize = 64;

    negativeCellSurfaceProteinAdhesion = false;
    negativeCellSurfaceProteinEnergyTransfer = false;
    negativeCellSurfaceProteinGenomeTransfer = false;
    negativeCellSurfaceProteinCommunication = true;
    zeroCellSurfaceProteinAdhesion = false;
    zeroCellSurfaceProteinEnergyTransfer = true;
    zeroCellSurfaceProteinGenomeTransfer = true;
    zeroCellSurfaceProteinCommunication = true;
    positiveCellSurfaceProteinAdhesion = true;
    positiveCellSurfaceProteinEnergyTransfer = true;
    positiveCellSurfaceProteinGenomeTransfer = true;
    positiveCellSurfaceProteinCommunication = true;

    stat_totalFreeEnergy = 0L;
    stat_movementThisTurn = 0;
    stat_energyTransfers = 0;
    stat_genomeTransfers = 0;
    stat_communications = 0;
  }

  public Map getParameters()
  {
    return parameters;
  }

  public Object getParameter(String name)
  {
    if ("maxCommunicationBufferSize".equals(name))
      return new Integer(maxCommunicationBufferSize);
    else if ("negativeCellSurfaceProteinAdhesion".equals(name))
      return (negativeCellSurfaceProteinAdhesion ? Boolean.TRUE : Boolean.FALSE);
    else if ("negativeCellSurfaceProteinEnergyTransfer".equals(name))
      return (negativeCellSurfaceProteinEnergyTransfer ? Boolean.TRUE : Boolean.FALSE);
    else if ("negativeCellSurfaceProteinGenomeTransfer".equals(name))
      return (negativeCellSurfaceProteinGenomeTransfer ? Boolean.TRUE : Boolean.FALSE);
    else if ("negativeCellSurfaceProteinCommunication".equals(name))
      return (negativeCellSurfaceProteinCommunication ? Boolean.TRUE : Boolean.FALSE);
    else if ("zeroCellSurfaceProteinAdhesion".equals(name))
      return (zeroCellSurfaceProteinAdhesion ? Boolean.TRUE : Boolean.FALSE);
    else if ("zeroCellSurfaceProteinEnergyTransfer".equals(name))
      return (zeroCellSurfaceProteinEnergyTransfer ? Boolean.TRUE : Boolean.FALSE);
    else if ("zeroCellSurfaceProteinGenomeTransfer".equals(name))
      return (zeroCellSurfaceProteinGenomeTransfer ? Boolean.TRUE : Boolean.FALSE);
    else if ("zeroCellSurfaceProteinCommunication".equals(name))
      return (zeroCellSurfaceProteinCommunication ? Boolean.TRUE : Boolean.FALSE);
    else if ("positiveCellSurfaceProteinAdhesion".equals(name))
      return (positiveCellSurfaceProteinAdhesion ? Boolean.TRUE : Boolean.FALSE);
    else if ("positiveCellSurfaceProteinEnergyTransfer".equals(name))
      return (positiveCellSurfaceProteinEnergyTransfer ? Boolean.TRUE : Boolean.FALSE);
    else if ("positiveCellSurfaceProteinGenomeTransfer".equals(name))
      return (positiveCellSurfaceProteinGenomeTransfer ? Boolean.TRUE : Boolean.FALSE);
    else if ("positiveCellSurfaceProteinCommunication".equals(name))
      return (positiveCellSurfaceProteinCommunication ? Boolean.TRUE : Boolean.FALSE);
    else if ("maintainEnergy".equals(name))
      return new Long(maintainEnergy);
    else if ("maintainEnergyDensity".equals(name))
      return new Integer(maintainEnergyDensity);
    else if ("maxGeneTransfer".equals(name))
      return new Integer(maxGeneTransfer);
    else if ("landscapeSize".equals(name)) {
      if (landscape == null)
        return "0x0";
      else return Integer.toString(landscape.length)+"x"+Integer.toString(landscape[0].length);
    }
    return null;
  }

  public void setParameter(String name,Object value)
  {
    if ("maxCommunicationBufferSize".equals(name))
      maxCommunicationBufferSize = ParameterValueParser.getInt(value);
    else if ("negativeCellSurfaceProteinAdhesion".equals(name))
      negativeCellSurfaceProteinAdhesion = ParameterValueParser.getBoolean(value);
    else if ("negativeCellSurfaceProteinEnergyTransfer".equals(name))
      negativeCellSurfaceProteinEnergyTransfer = ParameterValueParser.getBoolean(value);
    else if ("negativeCellSurfaceProteinGenomeTransfer".equals(name))
      negativeCellSurfaceProteinGenomeTransfer = ParameterValueParser.getBoolean(value);
    else if ("negativeCellSurfaceProteinCommunication".equals(name))
      negativeCellSurfaceProteinCommunication = ParameterValueParser.getBoolean(value);
    else if ("zeroCellSurfaceProteinAdhesion".equals(name))
      zeroCellSurfaceProteinAdhesion = ParameterValueParser.getBoolean(value);
    else if ("zeroCellSurfaceProteinEnergyTransfer".equals(name))
      zeroCellSurfaceProteinEnergyTransfer = ParameterValueParser.getBoolean(value);
    else if ("zeroCellSurfaceProteinGenomeTransfer".equals(name))
      zeroCellSurfaceProteinGenomeTransfer = ParameterValueParser.getBoolean(value);
    else if ("zeroCellSurfaceProteinCommunication".equals(name))
      zeroCellSurfaceProteinCommunication = ParameterValueParser.getBoolean(value);
    else if ("positiveCellSurfaceProteinAdhesion".equals(name))
      positiveCellSurfaceProteinAdhesion = ParameterValueParser.getBoolean(value);
    else if ("positiveCellSurfaceProteinEnergyTransfer".equals(name))
      positiveCellSurfaceProteinEnergyTransfer = ParameterValueParser.getBoolean(value);
    else if ("positiveCellSurfaceProteinGenomeTransfer".equals(name))
      positiveCellSurfaceProteinGenomeTransfer = ParameterValueParser.getBoolean(value);
    else if ("positiveCellSurfaceProteinCommunication".equals(name))
      positiveCellSurfaceProteinCommunication = ParameterValueParser.getBoolean(value);
    else if ("maintainEnergy".equals(name))
      maintainEnergy = ParameterValueParser.getLong(value);
    else if ("maintainEnergyDensity".equals(name))
      maintainEnergyDensity = ParameterValueParser.getInt(value);
    else if ("maxGeneTransfer".equals(name))
      maxGeneTransfer = ParameterValueParser.getInt(value);
    else if ("landscapeSize".equals(name)) {
      if (value != null) {
        String s = value.toString().toLowerCase().trim();
        int tmp = s.indexOf('x');
        try {
          int x = Integer.parseInt(s.substring(0,tmp));
          int y = Integer.parseInt(s.substring(tmp+1));
          initFlatLandscape(x,y);
        } catch (Throwable t) {}
      }
    }
  }

  /**
   * Gets whether cells with matching negative cell surface protein values should adhere
   *
   * @return Cells adhere?
   */
  public boolean cspGetNegativeCellSurfaceProteinAdhesion()
  {
    return negativeCellSurfaceProteinAdhesion;
  }

  /**
   * Gets whether cells with matching negative cell surface protein values should be able to transfer energy
   *
   * @return Cells can energy transfer?
   */
  public boolean cspGetNegativeCellSurfaceProteinEnergyTransfer()
  {
    return negativeCellSurfaceProteinEnergyTransfer;
  }

  /**
   * Gets whether cells with matching negative cell surface protein values should be able to transfer genome data
   *
   * @return Cells can transfer genome data?
   */
  public boolean cspGetNegativeCellSurfaceProteinGenomeTransfer()
  {
    return negativeCellSurfaceProteinGenomeTransfer;
  }

  /**
   * Gets whether cells with matching negative cell surface protein values should be able to communicate
   *
   * @return Cells can communicate?
   */
  public boolean cspGetNegativeCellSurfaceProteinCommunication()
  {
    return negativeCellSurfaceProteinCommunication;
  }

  /**
   * Gets whether cells with matching zero cell surface protein values should adhere
   *
   * @return Cells adhere?
   */
  public boolean cspGetZeroCellSurfaceProteinAdhesion()
  {
    return zeroCellSurfaceProteinAdhesion;
  }

  /**
   * Gets whether cells with matching zero cell surface protein values should be able to transfer energy
   *
   * @return Cells can energy transfer?
   */
  public boolean cspGetZeroCellSurfaceProteinEnergyTransfer()
  {
    return zeroCellSurfaceProteinEnergyTransfer;
  }

  /**
   * Gets whether cells with matching zero cell surface protein values should be able to transfer genome data
   *
   * @return Cells can transfer genome data?
   */
  public boolean cspGetZeroCellSurfaceProteinGenomeTransfer()
  {
    return zeroCellSurfaceProteinGenomeTransfer;
  }

  /**
   * Gets whether cells with matching zero cell surface protein values should be able to communicate
   *
   * @return Cells can communicate?
   */
  public boolean cspGetZeroCellSurfaceProteinCommunication()
  {
    return zeroCellSurfaceProteinCommunication;
  }

  /**
   * Gets whether cells with matching positive cell surface protein values should adhere
   *
   * @return Cells adhere?
   */
  public boolean cspGetPositiveCellSurfaceProteinAdhesion()
  {
    return positiveCellSurfaceProteinAdhesion;
  }

  /**
   * Gets whether cells with matching positive cell surface protein values should be able to transfer energy
   *
   * @return Cells can energy transfer?
   */
  public boolean cspGetPositiveCellSurfaceProteinEnergyTransfer()
  {
    return positiveCellSurfaceProteinEnergyTransfer;
  }

  /**
   * Gets whether cells with matching positive cell surface protein values should be able to transfer genome data
   *
   * @return Cells can transfer genome data?
   */
  public boolean cspGetPositiveCellSurfaceProteinGenomeTransfer()
  {
    return positiveCellSurfaceProteinGenomeTransfer;
  }

  /**
   * Gets whether cells with matching positive cell surface protein values should be able to communicate
   *
   * @return Cells can communicate?
   */
  public boolean cspGetPositiveCellSurfaceProteinCommunication()
  {
    return positiveCellSurfaceProteinCommunication;
  }

  /**
   * Sets whether cells with matching negative cell surface protein values should adhere
   *
   * @param negativeCellSurfaceProteinAdhesion Cells adhere?
   */
  public void cspSetNegativeCellSurfaceProteinAdhesion(boolean negativeCellSurfaceProteinAdhesion)
  {
    this.negativeCellSurfaceProteinAdhesion = negativeCellSurfaceProteinAdhesion;
  }

  /**
   * Sets whether cells with matching negative cell surface protein values should be able to transfer energy
   *
   * @param negativeCellSurfaceProteinEnergyTransfer Cells can energy transfer?
   */
  public void cspSetNegativeCellSurfaceProteinEnergyTransfer(boolean negativeCellSurfaceProteinEnergyTransfer)
  {
    this.negativeCellSurfaceProteinEnergyTransfer = negativeCellSurfaceProteinEnergyTransfer;
  }

  /**
   * Sets whether cells with matching negative cell surface protein values should be able to transfer genome data
   *
   * @param negativeCellSurfaceProteinGenomeTransfer Cells can transfer genome data?
   */
  public void cspSetNegativeCellSurfaceProteinGenomeTransfer(boolean negativeCellSurfaceProteinGenomeTransfer)
  {
    this.negativeCellSurfaceProteinGenomeTransfer = negativeCellSurfaceProteinGenomeTransfer;
  }

  /**
   * Sets whether cells with matching negative cell surface protein values should be able to communicate
   *
   * @param negativeCellSurfaceProteinCommunication Cells can communicate?
   */
  public void cspSetNegativeCellSurfaceProteinCommunication(boolean negativeCellSurfaceProteinCommunication)
  {
    this.negativeCellSurfaceProteinCommunication = negativeCellSurfaceProteinCommunication;
  }

  /**
   * Sets whether cells with matching zero cell surface protein values should adhere
   *
   * @param zeroCellSurfaceProteinAdhesion Cells adhere?
   */
  public void cspSetZeroCellSurfaceProteinAdhesion(boolean zeroCellSurfaceProteinAdhesion)
  {
    this.zeroCellSurfaceProteinAdhesion = zeroCellSurfaceProteinAdhesion;
  }

  /**
   * Sets whether cells with matching zero cell surface protein values should be able to transfer energy
   *
   * @param zeroCellSurfaceProteinEnergyTransfer Cells can energy transfer?
   */
  public void cspSetZeroCellSurfaceProteinEnergyTransfer(boolean zeroCellSurfaceProteinEnergyTransfer)
  {
    this.zeroCellSurfaceProteinEnergyTransfer = zeroCellSurfaceProteinEnergyTransfer;
  }

  /**
   * Sets whether cells with matching zero cell surface protein values should be able to transfer genome data
   *
   * @param zeroCellSurfaceProteinGenomeTransfer Cells can transfer genome data?
   */
  public void cspSetZeroCellSurfaceProteinGenomeTransfer(boolean zeroCellSurfaceProteinGenomeTransfer)
  {
    this.zeroCellSurfaceProteinGenomeTransfer = zeroCellSurfaceProteinGenomeTransfer;
  }

  /**
   * Sets whether cells with matching zero cell surface protein values should be able to communicate
   *
   * @param zeroCellSurfaceProteinCommunication Cells can communicate?
   */
  public void cspSetZeroCellSurfaceProteinCommunication(boolean zeroCellSurfaceProteinCommunication)
  {
    this.zeroCellSurfaceProteinCommunication = zeroCellSurfaceProteinCommunication;
  }

  /**
   * Sets whether cells with matching positive cell surface protein values should adhere
   *
   * @param positiveCellSurfaceProteinAdhesion Cells adhere?
   */
  public void cspSetPositiveCellSurfaceProteinAdhesion(boolean positiveCellSurfaceProteinAdhesion)
  {
    this.positiveCellSurfaceProteinAdhesion = positiveCellSurfaceProteinAdhesion;
  }

  /**
   * Sets whether cells with matching positive cell surface protein values should be able to transfer energy
   *
   * @param positiveCellSurfaceProteinEnergyTransfer Cells can energy transfer?
   */
  public void cspSetPositiveCellSurfaceProteinEnergyTransfer(boolean positiveCellSurfaceProteinEnergyTransfer)
  {
    this.positiveCellSurfaceProteinEnergyTransfer = positiveCellSurfaceProteinEnergyTransfer;
  }

  /**
   * Sets whether cells with matching positive cell surface protein values should be able to transfer genome data
   *
   * @param positiveCellSurfaceProteinGenomeTransfer Cells can transfer genome data?
   */
  public void cspSetPositiveCellSurfaceProteinGenomeTransfer(boolean positiveCellSurfaceProteinGenomeTransfer)
  {
    this.positiveCellSurfaceProteinGenomeTransfer = positiveCellSurfaceProteinGenomeTransfer;
  }

  /**
   * Sets whether cells with matching positive cell surface protein values should be able to communicate
   *
   * @param positiveCellSurfaceProteinCommunication Cells can communicate?
   */
  public void cspSetPositiveCellSurfaceProteinCommunication(boolean positiveCellSurfaceProteinCommunication)
  {
    this.positiveCellSurfaceProteinCommunication = positiveCellSurfaceProteinCommunication;
  }

  /**
   * Sets the maximum gene transfer to permit to a cell per turn
   *
   * @param maxGeneTransfer Max gene transfer
   */
  public void setMaxGeneTransfer(int maxGeneTransfer)
  {
    this.maxGeneTransfer = maxGeneTransfer;
  }

  /**
   * Gets the maximum gene transfer to permit to a cell per turn
   *
   * @return Max gene transfer
   */
  public int getMaxGeneTransfer()
  {
    return maxGeneTransfer;
  }

  /**
   * Sets the observer
   *
   * @param observer Observer or null for none
   */
  public void setObserver(Landscape2DObserver observer)
  {
    this.observer = observer;
  }

  /**
   * Sets the level of energy to maintain in the universe (0 to disable)
   *
   * @param maintainEnergy Level of energy to maintain
   */
  public void setMaintainEnergy(long maintainEnergy)
  {
    this.maintainEnergy = maintainEnergy;
  }

  /**
   * Gets the level of energy to maintain in the universe
   *
   * @return Maintain energy level
   */
  public long getMaintainEnergy()
  {
    return maintainEnergy;
  }

  /**
   * Sets the energy density setting (lower is higher)
   *
   * @param energyDensity Energy density
   */
  public void setEnergyDensity(int energyDensity)
  {
    this.maintainEnergyDensity = energyDensity;
  }

  /**
   * Gets the energy density setting
   *
   * @return Energy density
   */
  public int getEnergyDensity()
  {
    return maintainEnergyDensity;
  }

  /**
   * Returns the total free energy in the landscape
   *
   * @return Total free energy
   */
  public long getTotalFreeEnergy()
  {
    return stat_totalFreeEnergy;
  }

  /**
   * Returns whether or not this landscape has been initialized with a
   * topography
   *
   * @return Has landscape been initialized?
   */
  public boolean isInitialized()
  {
    return (landscape != null);
  }

  /**
   * Initializes a flat featureless landscape
   *
   * @param sizeX Size of landscape (x)
   * @param sizeY Size of landscape (y)
   */
  public void initFlatLandscape(int sizeX,int sizeY)
  {
    landscape = new Object[sizeX][sizeY];
    if (observer != null)
      observer.backgroundChanged();
  }

  /**
   * <p>Initializes a featured lanscape based on an image</p>
   *
   * <p>Black areas of the image will be empty cells, while any non-black
   * areas will be set as solid impassable blocks.</p>
   *
   * @param image Image to initialize from
   */
  public void initImageLandscape(BufferedImage image)
  {
    landscape = new Object[image.getWidth()][image.getHeight()];

    ModifiableInteger negInt = new ModifiableInteger(-1);
    for(int x=0;x<landscape.length;x++) {
      for(int y=0;y<landscape[x].length;y++) {
        if ((image.getRGB(x,y) & 0x00ffffff) > 0)
          landscape[x][y] = negInt;
      }
    }

    if (observer != null)
      observer.backgroundChanged();
  }

  /**
   * Gets the size of the landscape in the X direction
   *
   * @return Size X
   */
  public int getSizeX()
  {
    return ((landscape == null) ? 0 : landscape.length);
  }

  /**
   * Gets the size of the landscape in the Y direction
   *
   * @return Size Y
   */
  public int getSizeY()
  {
    return ((landscape == null) ? 0 : landscape[0].length);
  }

  /**
   * <p>Returns the cell at the given X,Y location</p>
   *
   * <p>This will throw NullPointerException if the landscape is not
   * initialized.</p>
   *
   * @param x X location
   * @param y Y location
   * @return Cell or null if none
   */
  public Cell getCell(int x,int y)
  {
    if ((x < 0)||(x >= landscape.length)||(y < 0)||(y >= landscape.length))
      return null;
    Object tmp = landscape[x][y];
    if (tmp != null) {
      if (tmp instanceof Cell)
        return (Cell)tmp;
    }
    return null;
  }

  /**
   * Returns whether or not landscape cell is solid
   *
   * @param x X location
   * @param y Y location
   * @return Is cell solid?
   */
  public boolean isSolid(int x,int y)
  {
    if ((x < 0)||(x >= landscape.length)||(y < 0)||(y >= landscape.length))
      return false;
    Object tmp = landscape[x][y];
    if (tmp != null) {
      if (tmp instanceof ModifiableInteger)
        return (((ModifiableInteger)tmp).value < 0);
    }
    return false;
  }

  /**
   * Returns the energy value of this landscape cell or 0 if none
   *
   * @param x X location
   * @param y Y location
   * @return Energy value or 0 if none
   */
  public int getEnergyValue(int x,int y)
  {
    if ((x < 0)||(x >= landscape.length)||(y < 0)||(y >= landscape.length))
      return 0;
    Object tmp = landscape[x][y];
    if (tmp != null) {
      if (tmp instanceof ModifiableInteger)
        return (((ModifiableInteger)tmp).value > 0) ? ((ModifiableInteger)tmp).value : 0;
    }
    return 0;
  }

  /**
   * <p>Returns internal landscape contents object</p>
   *
   * <p>This is only useful if you know the internals of this class and to
   * write very fast browsers and visualization components for the landscape.</p>
   *
   * <p>This should probably not be used by third party developers who don't
   * have the source, as what is returned by this function is not guaranteed
   * to stay consistent between program versions.</p>
   *
   * @param x X location
   * @param y Y location
   * @return Internal contents of landscape
   */
  public Object getInternalLandscapeContents(int x,int y)
  {
    return landscape[x][y];
  }

  /**
   * Adds energy at a given location, feeding it to a cell if a cell is there
   * or discarding if the location is blocked.
   *
   * @param x X location
   * @param y Y location
   * @param energy Energy value
   */
  public void addEnergy(int x,int y,int energy)
  {
    if (energy > 0) {
      Object tmp = landscape[x][y];
      if (tmp == null) {
        landscape[x][y] = new ModifiableInteger(energy);
        stat_totalFreeEnergy += (long)energy;
        if (observer != null)
          observer.foodAdded(x,y);
      } else if (tmp instanceof ModifiableInteger) {
        if (((ModifiableInteger)tmp).value >= 0) {
          ((ModifiableInteger)landscape[x][y]).value += energy;
          stat_totalFreeEnergy += (long)energy;
          if (observer != null)
            observer.foodAdded(x,y);
        }
      } else if (tmp instanceof Cell)
        ((Cell)tmp).incEnergy(energy);
    }
  }

  /**
   * Adds a bulk amount of energy to the landscape once
   *
   * @param energyToAdd Energy to add
   * @param density Maximum amount of energy to add per x,y location
   */
  public void bulkAddEnergy(long energyToAdd,int density)
  {
    int e;
    for(long ea=0L;ea<energyToAdd;) {
      if ((e = randomSource.randomPositiveInteger() % density) > 0) {
        ea += (long)e;
        addEnergy(randomSource.randomPositiveInteger() % landscape.length,randomSource.randomPositiveInteger() % landscape[0].length,e);
      }
    }
  }

  // -------------------------------------------------------------------------
  // Methods to implement EnvironmentalCondition
  // -------------------------------------------------------------------------

  public String getChannelDescription(int channel)
  {
    switch(channel) {
      case 2:
        return "Movement in landscape";
      case 3:
        return "Vision of directions of neighboring cells";
      case 4:
        return "Vision of cell surface protein values of neighboring cells";
      case 5:
        return "Set cell surface protein value";
      case 6:
        return "Add/remove energy from adhered neighboring cells";
      case 7:
        return "Communication to/from neighboring adhered cells";
      case 8:
        return "Genome concatenation to neighboring adhered cells";
    }
    return null;
  }

  public void init(Universe universe,Simulation simulation)
  {
    this.simulation = simulation;
    this.universe = universe;
    this.randomSource = simulation.randomSource();

    // Channel 2: movement
    universe.assignChannel(2,this);
    // Channel 3: neighboring cell direction vision
    universe.assignChannel(3,this);
    // Channel 4: neighboring cell surface protein vision
    universe.assignChannel(4,this);
    // Channel 5: set cell surface protein value
    universe.assignChannel(5,this);
    // Channel 6: add/remove energy from neighboring adhered cells
    universe.assignChannel(6,this);
    // Channel 7: communication with neighboring adhered cells
    universe.assignChannel(7,this);
    // Channel 8: genome concatenation to neighboring adhered cells
    universe.assignChannel(8,this);
  }

  public void destroy()
  {
    universe.unassignChannel(2);
    universe.unassignChannel(3);
    universe.unassignChannel(4);
    universe.unassignChannel(5);
    universe.unassignChannel(6);
    universe.unassignChannel(7);
    universe.unassignChannel(8);
  }

  public void preTickNotify()
    throws ConditionExpirationException
  {
    stat_movementThisTurn = 0;
    stat_energyTransfers = 0;
    stat_genomeTransfers = 0;
    stat_communications = 0;
  }

  public void postTickNotify()
    throws ConditionExpirationException
  {
    // Do maintaining of energy if necessary
    if (maintainEnergy > 0L) {
      long totalEnergy = stat_totalFreeEnergy + universe.totalCellEnergy();
      while (totalEnergy < maintainEnergy) {
        int e = randomSource.randomPositiveInteger() % maintainEnergyDensity;
        if (e != 0) {
          addEnergy(randomSource.randomPositiveInteger() % landscape.length,randomSource.randomPositiveInteger() % landscape[0].length,e);
          totalEnergy += (long)e;
        }
      }
    }

    simulation.setStatistic("L01 Landscape2D.totalFreeEnergy",stat_totalFreeEnergy);
    simulation.setStatistic("L02 Landscape2D.movement",stat_movementThisTurn);
    simulation.setStatistic("L03 Landscape2D.adhesionEnergyTransfers",stat_energyTransfers);
    simulation.setStatistic("L04 Landscape2D.adheredGeneticTransfers",stat_genomeTransfers);
    simulation.setStatistic("L05 Landscape2D.adheredCommunicationActivity",stat_communications);
    simulation.setStatistic("L06 Landscape2D.adheredMovement",stat_adheredMotion);
  }

  public void postTickProcessCells(List cells)
  {
    for(Iterator ci=cells.iterator();ci.hasNext();) {
      Cell cell = (Cell)ci.next();
      if (cell.alive()) {
        // Get cell location
        Landscape2DCellMetaInfo cellMetaInfo = (Landscape2DCellMetaInfo)cell.getMetaInfo(CELL_INFO_LANDSCAPE2D);
        if (cellMetaInfo == null)
          continue;

        // Get and zero cell movement potentials
        int mpx = cellMetaInfo.mpX;
        int mpy = cellMetaInfo.mpY;
        cellMetaInfo.mpX = 0;
        cellMetaInfo.mpY = 0;

        // Add/remove energy and distribute leftover mp to adhered cells
        int cellSurfaceProtein = cell.getCellSurfaceProteinIntValue();
        int leftoverX = ((mpx >= 2) ? mpx-1 : ((mpx <= -2) ? mpx+1 : 0));
        int leftoverY = ((mpy >= 2) ? mpy-1 : ((mpy <= -2) ? mpy+1 : 0));
        for(int i=0;i<ADJACENT3X3_CELL_MATH.length&&cell.alive();i++) {
          int _x = cellMetaInfo.location.x + ADJACENT3X3_CELL_MATH[i][0];
          int _y = cellMetaInfo.location.y + ADJACENT3X3_CELL_MATH[i][1];
          if (_x < 0)
            _x += landscape.length;
          else if (_x >= landscape.length)
            _x -= landscape.length;
          if (_y < 0)
            _y += landscape[0].length;
          else if (_y >= landscape[0].length)
            _y -= landscape[0].length;
          Object neighbor = landscape[_x][_y];
          if (neighbor != null) {
            if (neighbor instanceof Cell) {
              if (((Cell)neighbor).alive()&&(((Cell)neighbor).getCellSurfaceProteinIntValue() == cellSurfaceProtein)) {
                if (cellSurfaceProtein < 0) {
                  // Cell surface proteins are negative
                  if (negativeCellSurfaceProteinEnergyTransfer) {
                    // Energy transfer between adjacent cells
                    if (cellMetaInfo.neighborEnergyTransfer > 0) {
                      // Give energy to neighboring cell
                      int epossible = cell.energy();
                      cell.decEnergy(cellMetaInfo.neighborEnergyTransfer);
                      ((Cell)neighbor).incEnergy((epossible < cellMetaInfo.neighborEnergyTransfer) ? epossible : cellMetaInfo.neighborEnergyTransfer);
                      ++stat_energyTransfers;
                    } else if (cellMetaInfo.neighborEnergyTransfer < 0) {
                      // Take energy from neighboring cell
                      int abs = ((cellMetaInfo.neighborEnergyTransfer == -2147483648) ? 2147483647 : Math.abs(cellMetaInfo.neighborEnergyTransfer));
                      int epossible = ((Cell)neighbor).energy();
                      ((Cell)neighbor).decEnergy(abs);
                      if (epossible > 0)
                        cell.incEnergy((epossible < abs) ? epossible : abs);
                      ++stat_energyTransfers;
                    }
                  }
                  if (negativeCellSurfaceProteinAdhesion) {
                    // Distribute leftover movement potential
                    if ((leftoverX != 0)||(leftoverY != 0)) {
                      Landscape2DCellMetaInfo neighborMetaInfo = (Landscape2DCellMetaInfo)((Cell)neighbor).getMetaInfo(CELL_INFO_LANDSCAPE2D);
                      neighborMetaInfo.mpXPending += leftoverX;
                      neighborMetaInfo.mpYPending += leftoverY;
                      ++stat_adheredMotion;
                    }
                  }
                } else if (cellSurfaceProtein == 0) {
                  // Cell surface proteins are zero
                  if (zeroCellSurfaceProteinEnergyTransfer) {
                    // Energy transfer between adjacent cells
                    if (cellMetaInfo.neighborEnergyTransfer > 0) {
                      // Give energy to neighboring cell
                      int epossible = cell.energy();
                      cell.decEnergy(cellMetaInfo.neighborEnergyTransfer);
                      ((Cell)neighbor).incEnergy((epossible < cellMetaInfo.neighborEnergyTransfer) ? epossible : cellMetaInfo.neighborEnergyTransfer);
                      ++stat_energyTransfers;
                    } else if (cellMetaInfo.neighborEnergyTransfer < 0) {
                      // Take energy from neighboring cell
                      int abs = ((cellMetaInfo.neighborEnergyTransfer == -2147483648) ? 2147483647 : Math.abs(cellMetaInfo.neighborEnergyTransfer));
                      int epossible = ((Cell)neighbor).energy();
                      ((Cell)neighbor).decEnergy(abs);
                      if (epossible > 0)
                        cell.incEnergy((epossible < abs) ? epossible : abs);
                      ++stat_energyTransfers;
                    }
                  }
                  if (zeroCellSurfaceProteinAdhesion) {
                    // Distribute leftover movement potential
                    if ((leftoverX != 0)||(leftoverY != 0)) {
                      Landscape2DCellMetaInfo neighborMetaInfo = (Landscape2DCellMetaInfo)((Cell)neighbor).getMetaInfo(CELL_INFO_LANDSCAPE2D);
                      neighborMetaInfo.mpXPending += leftoverX;
                      neighborMetaInfo.mpYPending += leftoverY;
                      ++stat_adheredMotion;
                    }
                  }
                } else {
                  // Cell surface proteins are positive
                  if (positiveCellSurfaceProteinEnergyTransfer) {
                    // Energy transfer between adjacent cells
                    if (cellMetaInfo.neighborEnergyTransfer > 0) {
                      // Give energy to neighboring cell
                      int epossible = cell.energy();
                      cell.decEnergy(cellMetaInfo.neighborEnergyTransfer);
                      ((Cell)neighbor).incEnergy((epossible < cellMetaInfo.neighborEnergyTransfer) ? epossible : cellMetaInfo.neighborEnergyTransfer);
                      ++stat_energyTransfers;
                    } else if (cellMetaInfo.neighborEnergyTransfer < 0) {
                      // Take energy from neighboring cell
                      int abs = ((cellMetaInfo.neighborEnergyTransfer == -2147483648) ? 2147483647 : Math.abs(cellMetaInfo.neighborEnergyTransfer));
                      int epossible = ((Cell)neighbor).energy();
                      ((Cell)neighbor).decEnergy(abs);
                      if (epossible > 0)
                        cell.incEnergy((epossible < abs) ? epossible : abs);
                      ++stat_energyTransfers;
                    }
                  }
                  if (positiveCellSurfaceProteinAdhesion) {
                    // Distribute leftover movement potential
                    if ((leftoverX != 0)||(leftoverY != 0)) {
                      Landscape2DCellMetaInfo neighborMetaInfo = (Landscape2DCellMetaInfo)((Cell)neighbor).getMetaInfo(CELL_INFO_LANDSCAPE2D);
                      neighborMetaInfo.mpXPending += leftoverX;
                      neighborMetaInfo.mpYPending += leftoverY;
                      ++stat_adheredMotion;
                    }
                  }
                }
              }
            }
          }
        }

        // Zero neighbor energy transfer
        cellMetaInfo.neighborEnergyTransfer = 0;

        // If the cell died giving away energy, continue with next
        if (!cell.alive())
          continue;

        // Handle movement of the cell itself
        int newX = cellMetaInfo.location.x;
        int newY = cellMetaInfo.location.y;
        int oldX = newX;
        int oldY = newY;
        if (mpx >= 1) {
          if (++newX >= landscape.length)
            newX -= landscape.length;
        } else if (mpx <= -1) {
          if (--newX < 0)
            newX += landscape.length;
        }
        if (mpy >= 1) {
          if (++newY >= landscape[0].length)
            newY -= landscape[0].length;
        } else if (mpy <= -1) {
          if (--newY < 0)
            newY += landscape[0].length;
        }
        if ((mpx != 0)||(mpy != 0)) {
          // Movement is possible if destination cell is empty or has energy
          Object dest = landscape[newX][newY];
          if (dest == null) {
            landscape[newX][newY] = cell;
            landscape[oldX][oldY] = null;
            cellMetaInfo.location.x = newX;
            cellMetaInfo.location.y = newY;
            if (observer != null)
              observer.cellMoved(oldX,oldY,newX,newY,cell);
            ++stat_movementThisTurn;
          } else if (dest instanceof ModifiableInteger) {
            int energy = ((ModifiableInteger)dest).intValue();
            if (energy >= 0) {
              cell.incEnergy(energy);
              stat_totalFreeEnergy -= (long)energy;
              landscape[newX][newY] = cell;
              landscape[oldX][oldY] = null;
              cellMetaInfo.location.x = newX;
              cellMetaInfo.location.y = newY;
              if (observer != null)
                observer.cellMoved(oldX,oldY,newX,newY,cell);
              ++stat_movementThisTurn;
            }
          }
        }

        // Concatenate anything in genbuf onto this genome
        if (cellMetaInfo.genomeConcatenateBuffer != null) {
          if (cellMetaInfo.genomeConcatenateBuffer.size() > 0) {
            Genome tmp = cell.genome().createNew(cellMetaInfo.genomeConcatenateBuffer.getData());
            try {
              cell.setGenome(cell.genome().concat(tmp));
            } catch (IncompatibleGenomeException e) {
              // Beastiality (sex with wrong species) attempted??  :)
            } catch (UnsupportedOperationException e) {
              // Genome type does not support this
            }
            ++stat_genomeTransfers;
            cellMetaInfo.genomeConcatenateBuffer = null;
          }
        }

        // Set new CSP if there is one
        if (cellMetaInfo.hasNewCellSurfaceProtein) {
          cell.setCellSurfaceProtein(new Integer(cellMetaInfo.newCellSurfaceProtein));
          cellMetaInfo.hasNewCellSurfaceProtein = false;
        }
      }
    }
  }

  public void preExecutionNotify(Cell l)
  {
    // Check to make sure it's alive -- don't give vision to a corpse
    if (l.alive()) {
      // Go ahead and handle pending X and Y movement potentials here
      Landscape2DCellMetaInfo cellMetaInfo = (Landscape2DCellMetaInfo)l.getMetaInfo(CELL_INFO_LANDSCAPE2D);
      if (cellMetaInfo != null) {
        cellMetaInfo.mpX += cellMetaInfo.mpXPending;
        cellMetaInfo.mpY += cellMetaInfo.mpYPending;
        cellMetaInfo.mpXPending = 0;
        cellMetaInfo.mpYPending = 0;
      }

      // Set vision inputs
      int sp = randomSource.randomPositiveInteger() % ADJACENT3X3_CELL_MATH.length;
      l.setInput(3,new NeighboringCellDirectionVision(cellMetaInfo.location,sp));
      l.setInput(4,new NeighboringCellSurfaceProteinVision(cellMetaInfo.location,sp));

      // Set cell surface protein value as input
      l.setInput(5,new SingleValueIntegerInput(l.getCellSurfaceProteinIntValue()));

      // Set communications buffer as input
      if (cellMetaInfo.communicationInputBuffer != null)
        l.setInput(7,(CommunicationsBufferIntegerInput)cellMetaInfo.communicationInputBuffer);
    }
  }

  public void evaluateOutput(Cell l,int channel,int value)
  {
    int cellSurfaceProtein;
    Landscape2DCellMetaInfo cellMetaInfo;
    switch(channel) {
      case 2:
        // Movement
        cellMetaInfo = (Landscape2DCellMetaInfo)l.getMetaInfo(CELL_INFO_LANDSCAPE2D);
        if ((value != 0)&&(cellMetaInfo != null)) {
          if ((value & NORTH) != 0)
            ++cellMetaInfo.mpY;
          if ((value & SOUTH) != 0)
            --cellMetaInfo.mpY;
          if ((value & EAST) != 0)
            ++cellMetaInfo.mpX;
          if ((value & WEST) != 0)
            --cellMetaInfo.mpX;
        }
        break;
      case 3:
        // Neighboring cell direction vision -- do nothing on input
        break;
      case 4:
        // Neighboring cell surface protein vision -- do nothing on input
        break;
      case 5:
        // Set new CSP (not actually set until next round)
        cellMetaInfo = (Landscape2DCellMetaInfo)l.getMetaInfo(CELL_INFO_LANDSCAPE2D);
        cellMetaInfo.hasNewCellSurfaceProtein = true;
        cellMetaInfo.newCellSurfaceProtein = value;
        break;
      case 6:
        // Add/remove energy from neighboring adhered cells
        cellMetaInfo = (Landscape2DCellMetaInfo)l.getMetaInfo(CELL_INFO_LANDSCAPE2D);
        if (cellMetaInfo != null)
          cellMetaInfo.neighborEnergyTransfer += value;
        break;
      case 7:
        // Communication with neighboring adhered cells
        //
        // Add to communications buffer of all adjacent cells with the same
        // cell surface protein as the sending cell (if allowed)
        cellSurfaceProtein = l.getCellSurfaceProteinIntValue();
        cellMetaInfo = (Landscape2DCellMetaInfo)l.getMetaInfo(CELL_INFO_LANDSCAPE2D);
        for(int i=0;i<ADJACENT3X3_CELL_MATH.length;i++) {
          int _x = cellMetaInfo.location.x + ADJACENT3X3_CELL_MATH[i][0];
          int _y = cellMetaInfo.location.y + ADJACENT3X3_CELL_MATH[i][1];
          if (_x < 0)
            _x += landscape.length;
          else if (_x >= landscape.length)
            _x -= landscape.length;
          if (_y < 0)
            _y += landscape[0].length;
          else if (_y >= landscape[0].length)
            _y -= landscape[0].length;
          Object neighbor = landscape[_x][_y];
          if (neighbor != null) {
            if (neighbor instanceof Cell) {
              if (((Cell)neighbor).alive()&&(((Cell)neighbor).getCellSurfaceProteinIntValue() == cellSurfaceProtein)) {
                if (((cellSurfaceProtein < 0)&&negativeCellSurfaceProteinCommunication)||((cellSurfaceProtein == 0)&&zeroCellSurfaceProteinCommunication)||((cellSurfaceProtein > 0)&&positiveCellSurfaceProteinCommunication)) {
                  Landscape2DCellMetaInfo neighborMetaInfo = (Landscape2DCellMetaInfo)((Cell)neighbor).getMetaInfo(CELL_INFO_LANDSCAPE2D);
                  if (neighborMetaInfo.communicationInputBuffer == null)
                    neighborMetaInfo.communicationInputBuffer = new CommunicationsBufferIntegerInput();
                  synchronized(neighborMetaInfo.communicationInputBuffer) {
                    if (neighborMetaInfo.communicationInputBuffer.size() < maxCommunicationBufferSize) {
                      neighborMetaInfo.communicationInputBuffer.add(new Integer(value));
                      ++stat_communications;
                    }
                  }
                }
              }
            }
          }
        }
        break;
      case 8:
        // Concatenation of genome to neighboring cells
        //
        // Add to genome buffer of all neighboring cells with the same
        // cell surface protein (if allowed)
        cellSurfaceProtein = l.getCellSurfaceProteinIntValue();
        cellMetaInfo = (Landscape2DCellMetaInfo)l.getMetaInfo(CELL_INFO_LANDSCAPE2D);
        for(int i=0;i<ADJACENT3X3_CELL_MATH.length;i++) {
          if (cellMetaInfo == null)
            continue;
          int _x = cellMetaInfo.location.x + ADJACENT3X3_CELL_MATH[i][0];
          int _y = cellMetaInfo.location.y + ADJACENT3X3_CELL_MATH[i][1];
          if (_x < 0)
            _x += landscape.length;
          else if (_x >= landscape.length)
            _x -= landscape.length;
          if (_y < 0)
            _y += landscape[0].length;
          else if (_y >= landscape[0].length)
            _y -= landscape[0].length;
          Object neighbor = landscape[_x][_y];
          if (neighbor != null) {
            if (neighbor instanceof Cell) {
              if (((Cell)neighbor).alive()&&(((Cell)neighbor).getCellSurfaceProteinIntValue() == cellSurfaceProtein)) {
                if (((cellSurfaceProtein < 0)&&negativeCellSurfaceProteinGenomeTransfer)||((cellSurfaceProtein == 0)&&zeroCellSurfaceProteinGenomeTransfer)||((cellSurfaceProtein > 0)&&positiveCellSurfaceProteinGenomeTransfer)) {
                  Landscape2DCellMetaInfo neighborMetaInfo = (Landscape2DCellMetaInfo)((Cell)neighbor).getMetaInfo(CELL_INFO_LANDSCAPE2D);
                  if (neighborMetaInfo.genomeConcatenateBuffer == null)
                    neighborMetaInfo.genomeConcatenateBuffer = new EfficientByteBuffer(64);
                  synchronized(neighborMetaInfo.genomeConcatenateBuffer) {
                    if (neighborMetaInfo.genomeConcatenateBuffer.size() < maxGeneTransfer)
                      neighborMetaInfo.genomeConcatenateBuffer.add((byte)value);
                  }
                }
              }
            }
          }
        }
        break;
    }
  }

  public void deathNotify(Cell deadCell,String reason)
  {
    try {
      Landscape2DCellMetaInfo cellMetaInfo = (Landscape2DCellMetaInfo)deadCell.getMetaInfo(CELL_INFO_LANDSCAPE2D);
      if (cellMetaInfo != null) {
        landscape[cellMetaInfo.location.x][cellMetaInfo.location.y] = null;
        if (observer != null)
          observer.cellRemoved(cellMetaInfo.location.x,cellMetaInfo.location.y);
        int e = deadCell.energy();
        if (e > 0)
          addEnergy(cellMetaInfo.location.x,cellMetaInfo.location.y,e);
      }
    } catch (Throwable t) {
      t.printStackTrace();
    }
  }

  public void initCellNotify(Cell cell)
  {
    newCellNotify(null,cell);
  }

  public boolean newCellNotify(Cell parent,Cell newCell)
  {
    // Sanity check
    if (landscape == null)
      return false;

    // Choose a cell as close to the parent as possible or place randomly
    // if there is no parent; feed energy at new location to cell if energy
    // is present.
    Landscape2DCellMetaInfo cellMetaInfo = new Landscape2DCellMetaInfo();
    cellMetaInfo.location = new XYLocation();
    if (parent == null) {
      int cnt;
      for (cnt=0;cnt<10000000;cnt++) {
        cellMetaInfo.location.x = randomSource.randomPositiveInteger() % landscape.length;
        cellMetaInfo.location.y = randomSource.randomPositiveInteger() % landscape[0].length;
        if (landscape[cellMetaInfo.location.x][cellMetaInfo.location.y] == null)
          break;
        else if (landscape[cellMetaInfo.location.x][cellMetaInfo.location.y] instanceof ModifiableInteger) {
          // Handle any energy at new location
          int energy;
          if ((energy = ((ModifiableInteger)landscape[cellMetaInfo.location.x][cellMetaInfo.location.y]).value) > 0) {
            stat_totalFreeEnergy -= (long)energy;
            newCell.incEnergy(energy);
            landscape[cellMetaInfo.location.x][cellMetaInfo.location.y] = null;
            break;
          }
        }
      }
      if (cnt >= 10000000)
        return false;
    } else {
      Landscape2DCellMetaInfo parentMetaInfo = (Landscape2DCellMetaInfo)parent.getMetaInfo(CELL_INFO_LANDSCAPE2D);
      if (parentMetaInfo == null)
        return false;
      else {
        boolean foundNearestNeighbor = false;
        for(int i=0;i<ADJACENT3X3_CELL_MATH.length;i++) {
          cellMetaInfo.location.x = parentMetaInfo.location.x + ADJACENT3X3_CELL_MATH[i][0];
          cellMetaInfo.location.y = parentMetaInfo.location.y + ADJACENT3X3_CELL_MATH[i][1];
          if (cellMetaInfo.location.x < 0)
            cellMetaInfo.location.x += landscape.length;
          else if (cellMetaInfo.location.x >= landscape.length)
            cellMetaInfo.location.x -= landscape.length;
          if (cellMetaInfo.location.y < 0)
            cellMetaInfo.location.y += landscape[0].length;
          else if (cellMetaInfo.location.y >= landscape[0].length)
            cellMetaInfo.location.y -= landscape[0].length;
          if (landscape[cellMetaInfo.location.x][cellMetaInfo.location.y] == null) {
            foundNearestNeighbor = true;
            break;
          } else if (landscape[cellMetaInfo.location.x][cellMetaInfo.location.y] instanceof ModifiableInteger) {
            // Handle any energy at new location
            int energy;
            if ((energy = ((ModifiableInteger)landscape[cellMetaInfo.location.x][cellMetaInfo.location.y]).value) > 0) {
              stat_totalFreeEnergy -= (long)energy;
              newCell.incEnergy(energy);
              landscape[cellMetaInfo.location.x][cellMetaInfo.location.y] = null;
              foundNearestNeighbor = true;
              break;
            }
          }
        }
        if (!foundNearestNeighbor)
          return false;
      }

      // Set same cell surface protein as parent;
      newCell.setCellSurfaceProtein(new Integer(parent.getCellSurfaceProteinIntValue()));
    }

    cellMetaInfo.hasNewCellSurfaceProtein = false;
    newCell.setMetaInfo(CELL_INFO_LANDSCAPE2D,cellMetaInfo);
    landscape[cellMetaInfo.location.x][cellMetaInfo.location.y] = newCell;
    if (observer != null)
      observer.cellAdded(cellMetaInfo.location.x,cellMetaInfo.location.y,newCell);

    return true;
  }
}
