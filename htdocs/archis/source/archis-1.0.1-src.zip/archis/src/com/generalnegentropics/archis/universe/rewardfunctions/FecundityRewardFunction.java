package com.generalnegentropics.archis.universe.rewardfunctions;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

import java.util.*;
import com.generalnegentropics.archis.*;
import com.generalnegentropics.archis.life.*;
import com.generalnegentropics.archis.universe.*;

/**
 * Rewards cells for having children
 *
 * @author Adam Ierymenko
 * @version 1.0
 */

public class FecundityRewardFunction implements RewardFunction
{
  /**
   * Description of condition
   */
  public static final String CONDITION_DESCRIPTION = "Rewards cells one point for each child.";

  private Universe universe;
  private Simulation simulation;

  /**
   * Constructs a new reward function
   */
  public FecundityRewardFunction()
  {
  }

  public Map getParameters()
  {
    return Collections.EMPTY_MAP;
  }

  public Object getParameter(String name)
  {
    return null;
  }

  public void setParameter(String name,Object value)
  {
  }

  public String getChannelDescription(int channel)
  {
    return null;
  }

  public boolean newCellNotify(Cell parent, Cell newCell)
  {
    if (parent != null)
      parent.incPoints(1);
    return true;
  }

  public void initCellNotify(Cell cell)
  {
  }

  public void deathNotify(Cell deadCell, String reason)
  {
  }

  public void preExecutionNotify(Cell l)
  {
  }

  public void evaluateOutput(Cell l,int channel,int value)
  {
  }

  public void init(Universe universe,Simulation simulation)
  {
    this.universe = universe;
    this.simulation = simulation;
  }

  public void destroy()
  {
  }

  public void preTickNotify()
    throws ConditionExpirationException
  {
  }

  public void postTickNotify()
    throws ConditionExpirationException
  {
  }

  public void postTickProcessCells(List cells)
  {
  }
}
