package com.generalnegentropics.archis.universe.probes;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

import java.util.*;
import java.io.*;
import java.util.zip.*;
import java.lang.ref.WeakReference;
import com.generalnegentropics.archis.*;
import com.generalnegentropics.archis.universe.*;
import com.generalnegentropics.archis.life.*;
import com.generalnegentropics.archis.utils.RealNumberDataListener;

/**
 * Measures entropy by measuring deflate compression ratio of all genomes
 *
 * @author Adam Ierymenko
 * @version 3.0
 */

public class CompressibilityProbe implements Probe
{
  public static final String PROBE_DESCRIPTION = "Uses deflate compression to roughly measure entropy of all genomes in the universe.";
  private Universe universe;
  private Simulation simulation;
  private HashSet dataListeners;
  private NullCounterOutputStream counterOutput;
  private DeflaterOutputStream deflaterOutput;
  private long totalPreCompressionBytes;

  /**
   * Internal class to count output bytes from deflater output stream
   *
   * @author Adam Ierymenko
   * @version 1.0
   */
  private static class NullCounterOutputStream extends OutputStream
  {
    public long bytes;

    public NullCounterOutputStream()
    {
      super();
      bytes = 0L;
    }

    public void write(int b)
      throws IOException
    {
      ++bytes;
    }

    public void write(byte[] b)
      throws IOException
    {
      bytes += (long)b.length;
    }

    public void write(byte[] b,int start,int len)
      throws IOException
    {
      bytes += (long)len;
    }

    public void close()
    {
    }
  }

  /**
   * Constructs a new compressibility probe
   */
  public CompressibilityProbe()
  {
    dataListeners = new HashSet(6,0.95F);
    counterOutput = new NullCounterOutputStream();
  }

  public void addDataListener(RealNumberDataListener dataListener)
  {
    synchronized(dataListeners) {
      dataListeners.add(new WeakReference(dataListener));
    }
  }

  public void showGUI()
  {
    new com.generalnegentropics.archis.gui.probes.CompressibilityProbeWindow(this,simulation).setVisible(true);
  }

  public void init(Universe universe, Simulation simulation)
  {
    this.universe = universe;
    this.simulation = simulation;
  }

  public void destroy()
  {
  }

  public void preTickNotify()
  {
    counterOutput.bytes = 0L;
    deflaterOutput = new DeflaterOutputStream(counterOutput,new Deflater(Deflater.DEFAULT_COMPRESSION,false),16384);
    totalPreCompressionBytes = 0L;
  }

  public void postTickNotify()
  {
    synchronized(deflaterOutput) {
      try {
        deflaterOutput.finish();
        double ratio = (double)counterOutput.bytes / (double)totalPreCompressionBytes;
        simulation.setStatistic("CP0 CompressibilityProbe.compressionRatio",ratio);
        for(Iterator i=dataListeners.iterator();i.hasNext();) {
          Object dataOutput = ((WeakReference)i.next()).get();
          if (dataOutput == null)
            i.remove();
          else ((RealNumberDataListener)dataOutput).input(universe.clock(),ratio);
        }
      } catch (IOException e) {}
    }
  }

  public void probeScanCell(Cell cell)
  {
    if (cell.alive()) {
      synchronized(deflaterOutput) {
        try {
          totalPreCompressionBytes += (long)cell.genome().writeTo(deflaterOutput);
        } catch (IOException e) {}
      }
    }
  }

  public void probeNewCell(Cell parent,Cell newCell)
  {
  }
}
