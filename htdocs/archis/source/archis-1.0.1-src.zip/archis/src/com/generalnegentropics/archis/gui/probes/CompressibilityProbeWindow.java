package com.generalnegentropics.archis.gui.probes;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

import javax.swing.*;
import com.generalnegentropics.archis.universe.probes.*;
import com.generalnegentropics.archis.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.*;
import com.generalnegentropics.archis.gui.*;

public class CompressibilityProbeWindow extends JFrame
{
  private JPanel contentPane;
  private Simulation simulation;
  private CompressibilityProbe probe;
  GridBagLayout gridBagLayout1 = new GridBagLayout();
  JPanel jPanel1 = new JPanel();
  TitledBorder titledBorder1;
  TitledBorder titledBorder2;
  GridBagLayout gridBagLayout2 = new GridBagLayout();
  HorizontalLineGraph icGraph = new HorizontalLineGraph(16384,16384,Color.green,Color.black);
  JSlider icGraphSlider = new JSlider();
  private JButton closeButton = new JButton();

  public CompressibilityProbeWindow(CompressibilityProbe probe,Simulation simulation)
  {
    this.simulation = simulation;
    this.probe = probe;
    simulation.newFrameNotify(this);
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
    this.setSize(400,320);
    this.setTitle("["+simulation.getName()+"] CompressibilityProbe");
    Dimension ss = this.getToolkit().getScreenSize();
    this.setLocation((ss.width/2)-(this.getWidth()/2),(ss.height/2)-(this.getHeight()/2));
    this.setIconImage(Archis.ICON);
    probe.addDataListener(icGraph);
    icGraph.setAutoScale(false);
    icGraph.setFloor(0.0);
    icGraph.setCeiling(1.0);
    icGraphSlider.setPaintLabels(false);
    icGraphSlider.setPaintTicks(false);
    icGraphSlider.setPaintTrack(true);
    icGraph.setScrollBar(icGraphSlider);
  }

  private void jbInit() throws Exception {
    contentPane = (JPanel)this.getContentPane();
    titledBorder1 = new TitledBorder("");
    titledBorder2 = new TitledBorder("");
    contentPane.setLayout(gridBagLayout1);
    this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    jPanel1.setBorder(titledBorder1);
    jPanel1.setLayout(gridBagLayout2);
    titledBorder1.setTitle("Entropy Measured by Compressibility");
    titledBorder2.setTitle("Output Data to File");
    icGraphSlider.setPaintLabels(false);
    icGraphSlider.setPaintTicks(false);
    closeButton.setText("Close");
    closeButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        closeButton_actionPerformed(e);
      }
    });
    contentPane.add(jPanel1,    new GridBagConstraints(0, 0, 1, 1, 1.0, 2.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(2, 2, 0, 2), 0, 0));
    jPanel1.add(icGraph,    new GridBagConstraints(0, 0, 1, 1, 1.0, 2.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(2, 2, 2, 2), 0, 0));
    jPanel1.add(icGraphSlider,  new GridBagConstraints(0, 1, 1, 1, 1.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, 2, 2, 2), 0, 0));
    jPanel1.add(closeButton,  new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
  }

  void closeButton_actionPerformed(ActionEvent e) {
    this.setVisible(false);
    this.dispose();
  }
}
