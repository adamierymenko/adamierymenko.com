package com.generalnegentropics.archis.universe.environmentalconditions;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

import java.util.*;
import com.generalnegentropics.archis.utils.*;
import com.generalnegentropics.archis.life.*;
import com.generalnegentropics.archis.universe.*;
import com.generalnegentropics.archis.*;

/**
 * <p>An environmental condition that permits cells to reproduce using I/O channels</p>
 *
 * <p>Channels:</p>
 * <p>
 * 0 - Output genome to this channel to reproduce, input is current genome size
 * </p>
 *
 * @author Adam Ierymenko
 * @version 1.0
 */

public class ReproductionCondition implements EnvironmentalCondition
{
  /**
   * Description of condition
   */
  public static final String CONDITION_DESCRIPTION = "Provides cells with the ability to reproduce by outputting the genetic information of the child.";

  private static Map parameters;
  static
  {
    parameters = new HashMap();
    parameters.put("minGenomeSize","Minimum allowed genome size");
    parameters.put("maxGenomeSize","Maximum allowed genome size");
    parameters.put("parentEnergyDividend","Children have parent's energy divided by this (values < 2 are considered 2)");
    parameters = Collections.unmodifiableMap(parameters);
  }

  // Children to be created at postTickNotify() (key is parent, value is
  // EfficientByteBuffer containing genome output so far)
  private HashMap children;

  // Universe we exist within and our simulation
  private Universe universe;
  private Simulation simulation;

  // Min and max genome sizes
  private int minGenomeSize;
  private int maxGenomeSize;

  // Value to divide parent energy by when spawning children (>=2)
  private int parentEnergyDividend;

  /**
   * An IntegerInput that returns a cell's energy and genome size as the
   * first two values.
   *
   * @author Adam Ierymenko
   * @version 1.0
   */
  private static class EnergyAndGenomeSizeIntegerInput implements IntegerInput
  {
    private int i;
    private Cell c;

    public EnergyAndGenomeSizeIntegerInput(Cell c)
    {
      this.c = c;
      i = 0;
    }

    public int read()
    {
      switch(i++) {
        case 0:
          return c.energy();
        case 1:
          return c.genome().size();
      }
      return 0;
    }
  }

  /**
   * Class for child buffer structure
   *
   * @author Adam Ierymenko
   * @version 1.0
   */
  private static class ChildBuffer
  {
    public int ptr;
    public byte[] buf;
  }

  /**
   * Constructs a new reproduction condition with the given parameters
   */
  public ReproductionCondition()
  {
    children = new HashMap(16384,0.75F);
    minGenomeSize = 8;
    maxGenomeSize = 16384;
    parentEnergyDividend = 2;
  }

  public Map getParameters()
  {
    return parameters;
  }

  public Object getParameter(String name)
  {
    if ("minGenomeSize".equals(name))
      return new Integer(minGenomeSize);
    else if ("maxGenomeSize".equals(name))
      return new Integer(maxGenomeSize);
    else if ("parentEnergyDividend".equals(name))
      return new Integer(parentEnergyDividend);
    return null;
  }

  public void setParameter(String name,Object value)
  {
    if ("minGenomeSize".equals(name))
      minGenomeSize = ParameterValueParser.getInt(value);
    else if ("maxGenomeSize".equals(name))
      maxGenomeSize = ParameterValueParser.getInt(value);
    else if ("parentEnergyDividend".equals(name))
      parentEnergyDividend = ParameterValueParser.getInt(value);
    if (parentEnergyDividend < 2)
      parentEnergyDividend = 2;
  }

  public String getChannelDescription(int channel)
  {
    if (channel == 0)
      return "Reproduction output, input provides energy and genome size";
    return null;
  }

  public boolean newCellNotify(Cell parent, Cell newCell)
  {
    return true;
  }

  public void initCellNotify(Cell cell)
  {
  }

  public void deathNotify(Cell deadCell, String reason)
  {
  }

  public void preExecutionNotify(Cell l)
  {
    if (l.alive())
      l.setInput(0,new EnergyAndGenomeSizeIntegerInput(l));
  }

  public void evaluateOutput(Cell l,int channel,int value)
  {
    if (channel == 0) {
      ChildBuffer cb;
      synchronized(children) {
        cb = (ChildBuffer)children.get(l);
      }
      if (cb == null) {
        cb = new ChildBuffer();
        cb.ptr = 0;
        cb.buf = new byte[l.genome().size() * 2];
        synchronized(children) {
          children.put(l,cb);
        }
      }
      if (cb.ptr < maxGenomeSize) {
        cb.buf[cb.ptr++] = (byte)value;
        if (cb.ptr >= cb.buf.length) {
          byte[] nb = new byte[cb.buf.length*2];
          for(int i=0;i<cb.ptr;i++)
            nb[i] = cb.buf[i];
          cb.buf = nb;
        }
      }
    }
  }

  public void init(Universe universe,Simulation simulation)
  {
    this.universe = universe;
    this.simulation = simulation;
    universe.assignChannel(0,this);
  }

  public void destroy()
  {
    universe.unassignChannel(0);
  }

  public void preTickNotify()
    throws ConditionExpirationException
  {
  }

  public void postTickNotify()
    throws ConditionExpirationException
  {
    synchronized(children) {
      for(Iterator it=children.entrySet().iterator();it.hasNext();) {
        Map.Entry ent = (Map.Entry)it.next();
        ChildBuffer cb = (ChildBuffer)ent.getValue();

        if (cb.ptr >= minGenomeSize) {
          Cell parent = (Cell)ent.getKey();
          int parentEnergy = parent.energy();
          if (parentEnergy > parentEnergyDividend) {
            int childEnergy = parentEnergy / parentEnergyDividend;
            parent.decEnergy(childEnergy);
            universe.addCell(parent,new Cell(universe,simulation.nextCellId(),simulation.getName(),parent.id(),parent.generation()+1L,childEnergy,parent.genome().createNew(cb.buf,0,cb.ptr).canonicalize()));
          }
        }
      }
      simulation.setStatistic("RPC ReproductionCondition.childrenCreated",children.size());
      children.clear();
    }
  }

  public void postTickProcessCells(List cells)
  {
  }
}
