package com.generalnegentropics.archis.universe.environmentalconditions;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

import java.util.*;
import com.generalnegentropics.archis.universe.*;
import com.generalnegentropics.archis.life.*;
import com.generalnegentropics.archis.utils.*;
import com.generalnegentropics.archis.*;

/**
 * A condition that causes random mutations to living cells
 *
 * @author Adam Ierymenko
 * @version 2.0
 */

public class EnvironmentalMutationCondition implements EnvironmentalCondition
{
  /**
   * Description of condition
   */
  public static final String CONDITION_DESCRIPTION = "Randomly causes mutations with a given probability.";

  private static Map parameters;
  static
  {
    parameters = new HashMap();
    parameters.put("pointMutationProbability","Probability of point mutations");
    parameters.put("insertionMutationProbability","Probability of insertion mutations");
    parameters.put("deletionMutationProbability","Probability of deletion mutations");
    parameters.put("duplicationMutationProbability","Probability of duplication mutations");
    parameters = Collections.unmodifiableMap(parameters);
  }

  private Simulation simulation;
  private RandomSource randomSource;
  private float pointMutationProbability;
  private float insertionMutationProbability;
  private float deletionMutationProbability;
  private float duplicationMutationProbability;
  private volatile int pointMutationsThisTick;
  private volatile int insertionMutationsThisTick;
  private volatile int deletionMutationsThisTick;
  private volatile int duplicationMutationsThisTick;

  /**
   * Constructs a new environmental mutation condition
   */
  public EnvironmentalMutationCondition()
  {
    pointMutationProbability = 0.0005F;
    insertionMutationProbability = 0.0005F;
    deletionMutationProbability = 0.0005F;
    duplicationMutationProbability = 0.00005F;
  }

  public Map getParameters()
  {
    return parameters;
  }

  public Object getParameter(String name)
  {
    if ("pointMutationProbability".equals(name))
      return new Float(pointMutationProbability);
    else if ("insertionMutationProbability".equals(name))
      return new Float(insertionMutationProbability);
    else if ("deletionMutationProbability".equals(name))
      return new Float(deletionMutationProbability);
    else if ("duplicationMutationProbability".equals(name))
      return new Float(duplicationMutationProbability);
    return null;
  }

  public void setParameter(String name,Object value)
  {
    if ("pointMutationProbability".equals(name))
      pointMutationProbability = ParameterValueParser.getFloat(value);
    else if ("insertionMutationProbability".equals(name))
      insertionMutationProbability = ParameterValueParser.getFloat(value);
    else if ("deletionMutationProbability".equals(name))
      deletionMutationProbability = ParameterValueParser.getFloat(value);
    else if ("duplicationMutationProbability".equals(name))
      duplicationMutationProbability = ParameterValueParser.getFloat(value);
  }

  public void init(Universe universe,Simulation simulation)
  {
    this.simulation = simulation;
    this.randomSource = simulation.randomSource();
  }

  public void destroy()
  {
  }

  public void preTickNotify()
    throws ConditionExpirationException
  {
    pointMutationsThisTick = 0;
    insertionMutationsThisTick = 0;
    deletionMutationsThisTick = 0;
    duplicationMutationsThisTick = 0;
  }

  public void postTickNotify()
    throws ConditionExpirationException
  {
    simulation.setStatistic("EM1 EnvironmentalMutationCondition.pointMutations",pointMutationsThisTick);
    simulation.setStatistic("EM2 EnvironmentalMutationCondition.insertionMutations",insertionMutationsThisTick);
    simulation.setStatistic("EM3 EnvironmentalMutationCondition.deletionMutations",deletionMutationsThisTick);
    simulation.setStatistic("EM4 EnvironmentalMutationCondition.duplicationMutations",duplicationMutationsThisTick);
  }

  public void postTickProcessCells(List cells)
  {
  }

  public void preExecutionNotify(Cell cell)
  {
    if (randomSource.randomEvent(pointMutationProbability)) {
      cell.setGenome(cell.genome().pointMutation(randomSource));
      ++pointMutationsThisTick;
    }
    if (randomSource.randomEvent(insertionMutationProbability)) {
      cell.setGenome(cell.genome().insertionMutation(randomSource));
      ++insertionMutationsThisTick;
    }
    if (randomSource.randomEvent(deletionMutationProbability)) {
      cell.setGenome(cell.genome().deletionMutation(randomSource));
      ++deletionMutationsThisTick;
    }
    if (randomSource.randomEvent(duplicationMutationProbability)) {
      cell.setGenome(cell.genome().duplicationMutation(randomSource));
      ++duplicationMutationsThisTick;
    }
  }

  public void evaluateOutput(Cell l, int channel, int value)
  {
  }

  public String getChannelDescription(int channel)
  {
    return null;
  }

  public void deathNotify(Cell deadCell,String reason)
  {
  }

  public boolean newCellNotify(Cell parent,Cell newCell)
  {
    return true;
  }

  public void initCellNotify(Cell cell)
  {
  }
}
