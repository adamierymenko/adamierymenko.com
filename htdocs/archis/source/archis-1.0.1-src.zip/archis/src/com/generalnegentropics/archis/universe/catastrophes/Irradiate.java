package com.generalnegentropics.archis.universe.catastrophes;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

import java.util.*;
import com.generalnegentropics.archis.universe.*;
import com.generalnegentropics.archis.life.*;
import com.generalnegentropics.archis.utils.*;
import com.generalnegentropics.archis.*;

/**
 * A universal condition that runs for one cycle and causes tons of mutations.
 *
 * @author Adam Ierymenko
 * @version 1.0
 */

public class Irradiate implements Catastrophe
{
  /**
   * Description of condition
   */
  public static final String CONDITION_DESCRIPTION = "Causes one or more mutations in almost all cells for a single tick.";

  private static Map parameters;
  static
  {
    parameters = new HashMap();
    parameters.put("mutationProbability","Probability of mutations in each cell");
    parameters = Collections.unmodifiableMap(parameters);
  }

  private float mutationProbability;
  private RandomSource randomSource;

  /**
   * Constructs a new irradiate event with a mutation likelihood of 0.75 and maxMutations=5
   */
  public Irradiate()
  {
    mutationProbability = 0.75F;
  }

  public Map getParameters()
  {
    return parameters;
  }

  public Object getParameter(String name)
  {
    if ("mutationProbability".equals(name))
      return new Float(mutationProbability);
    return null;
  }

  public void setParameter(String name,Object value)
  {
    if ("mutationProbability".equals(name))
      mutationProbability = ParameterValueParser.getFloat(value);
  }

  public void init(Universe universe,Simulation simulation)
  {
    randomSource = simulation.randomSource();
  }

  public void destroy()
  {
  }

  public void preTickNotify()
    throws ConditionExpirationException
  {
  }

  public void postTickNotify()
    throws ConditionExpirationException
  {
    throw new ConditionExpirationException();
  }

  public void postTickProcessCells(List cells)
  {
  }

  public void preExecutionNotify(Cell cell)
  {
    Genome g = cell.genome();
    while (randomSource.randomEvent(mutationProbability)) {
      if (randomSource.randomEvent(0.25F))
        g = g.pointMutation(randomSource);
      if (randomSource.randomEvent(0.25F))
        g = g.insertionMutation(randomSource);
      if (randomSource.randomEvent(0.25F))
        g = g.deletionMutation(randomSource);
      if (randomSource.randomEvent(0.25F))
        g = g.duplicationMutation(randomSource);
    }
    cell.setGenome(g);
  }

  public void deathNotify(Cell deadCell,String reason)
  {
  }

  public boolean newCellNotify(Cell parent,Cell newCell)
  {
    return true;
  }

  public void initCellNotify(Cell cell)
  {
  }
}
