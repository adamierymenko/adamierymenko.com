package com.generalnegentropics.archis.net;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.zip.*;
import java.lang.ref.WeakReference;
import com.generalnegentropics.archis.Archis;
import com.generalnegentropics.archis.utils.*;

/**
 * Archis network server
 *
 * @author Adam Ierymenko
 * @version 1.0
 */

public class NetServer extends Thread
{
  // -------------------------------------------------------------------------
  // Internal class for client connections
  // -------------------------------------------------------------------------
  private class NetServerClientConnection extends Thread implements Comparable
  {
    public Socket clientConnection;
    public boolean die;
    public ArchisProtocolInput in;
    public ArchisProtocolOutput out;

    // Latest client statistics
    public TreeMap statistics;
    // Has client logged in?
    public volatile boolean loggedIn;
    // Latest client clock (-1 means hasn't reported yet)
    public volatile long clock;
    // Simulation name
    public String simulationName;
    // Remote version
    public String remoteVersion;
    // Address of remote
    public String remoteAddress;
    // Log output stream
    public PrintStream logOutput;

    public NetServerClientConnection(Socket clientConnection)
      throws IOException
    {
      super("NetServer Connection from ".concat(clientConnection.getInetAddress().toString()));
      super.setDaemon(true);
      clientConnection.setSoTimeout(0);
      clientConnection.setSendBufferSize(131072);
      clientConnection.setReceiveBufferSize(131072);
      in = new ArchisProtocolInput(clientConnection.getInputStream(),ArchisProtocolOutput.SUGGESTED_BLOCKSIZE);
      out = new ArchisProtocolOutput(clientConnection.getOutputStream(),ArchisProtocolOutput.SUGGESTED_BLOCKSIZE);
      this.clientConnection = clientConnection;
      remoteAddress = clientConnection.getInetAddress().toString();
      statistics = new TreeMap();
      clock = -1L;
      die = false;
      loggedIn = false;
      logOutput = null;
      start();
    }

    public String toString()
    {
      if (loggedIn)
        return remoteAddress+" ["+simulationName+", clock="+clock+", version="+remoteVersion+", incoming compression="+(100.0 - Math.round(in.getCompressionRatio() * 100.0))+"%]";
      else return remoteAddress.concat(" [Waiting for HELLO]");
    }

    public int compareTo(Object o)
    {
      if (loggedIn) {
        if (((NetServerClientConnection)o).loggedIn)
          return simulationName.compareTo(((NetServerClientConnection)o).simulationName);
        return -1;
      }
      return 1;
    }

    public boolean equals(Object o)
    {
      return (this == o);
    }

    public void run()
    {
      for(;!die;) {
        try {
          String[] packet = in.readPacket();

          //
          // Here is where read packets are processed (kinda ghetto, but it
          // works...)
          //
          if (packet.length > 0) {
            if ("HELLO".equals(packet[0])) {
              // Hello packets are sent when a client connects
              // Arguments: simulation name, clock, remote version
              if (packet.length < 4) {
                out.sendPacket("EBADPKT","HELLO requires: simulation name, clock value, program version");
                out.flush();
              } else if (loggedIn) {
                out.sendPacket("EBADPKT","Already logged in!");
                out.flush();
              } else {
                try {
                  if (clientsBySimulationName.containsKey(packet[1])) {
                    out.sendPacket("EDUPNAME","Simulation names must be unique in net");
                    out.flush();
                  } else {
                    clock = Long.parseLong(packet[2]);
                    simulationName = packet[1];
                    remoteVersion = packet[3];
                    loggedIn = true;
                    synchronized(clientsBySimulationName) {
                      clientsBySimulationName.put(simulationName,this);
                    }
                    synchronized(netObservers) {
                      for(Iterator i=netObservers.iterator();i.hasNext();) {
                        WeakReference ref = (WeakReference)i.next();
                        if (ref.get() == null)
                          i.remove();
                        else ((NetObserver)ref.get()).clientLogin(clientConnection.getInetAddress(),clientConnection.getPort(),simulationName,clock,remoteVersion);
                      }
                    }
                  }
                } catch (NumberFormatException e) {
                  out.sendPacket("EBADPKT","Clock value must be an integer");
                  out.flush();
                }
              }
            } else if ("CRESP".equals(packet[0])) {
              // Command response packets contain lines of text in response
              // to a command to the client.
              // Arguments: line of text (if this is not present, assumed to
              // be blank)
              if (!loggedIn) {
                out.sendPacket("ENOTLOGGEDIN");
                out.flush();
              } else {
                synchronized(commandTextOutput) {
                  commandTextOutput.print(simulationName);
                  commandTextOutput.print("> ");
                  if (packet.length < 2)
                    commandTextOutput.println();
                  else commandTextOutput.println(packet[1]);
                }
              }
            } else if ("TICK".equals(packet[0])) {
              // Tick packets indicate completion of a clock tick
              // Arguments: clock value
              if (!loggedIn) {
                out.sendPacket("ENOTLOGGEDIN");
                out.flush();
              } else if (packet.length < 2) {
                out.sendPacket("EBADPKT","TICK requires a clock value");
                out.flush();
              } else {
                try {
                  clock = Long.parseLong(packet[1]);

                  // Notify net observers
                  synchronized(netObservers) {
                    for(Iterator i=netObservers.iterator();i.hasNext();) {
                      WeakReference ref = (WeakReference)i.next();
                      if (ref.get() == null)
                        i.remove();
                      else ((NetObserver)ref.get()).clientTickCompleted(simulationName,clock);
                    }
                  }

                  // Log statistics
                  if (logDirectory != null) {
                    if (logOutput == null) {
                      File lf = new File(logDirectory,simulationName+".1.csv.gz");
                      int fn = 1;
                      while (lf.exists())
                        lf = new File(logDirectory,simulationName+"."+fn+".csv.gz");
                      logOutput = new PrintStream(new GZIPOutputStream(new FileOutputStream(lf),4096),false);
                      logOutput.print("simulationClock");
                      for(Iterator i=statistics.keySet().iterator();i.hasNext();) {
                        logOutput.print(',');
                        String s = (String)i.next();
                        if (s.length() > 4)
                          logOutput.print(s.substring(4));
                        else logOutput.print(s);
                      }
                      logOutput.println();
                    }
                    logOutput.print(Long.toString(clock));
                    for(Iterator i=statistics.values().iterator();i.hasNext();) {
                      logOutput.print(',');
                      logOutput.print(i.next().toString());
                    }
                    logOutput.println();
                  } else if (logOutput != null) {
                    logOutput.close();
                    logOutput = null;
                  }

                  // Send global tick complete messages
                  /* int connectedCount = 0;
                  synchronized(clients) {
                    for(int i=0;i<clientArray.length;i++) {
                      if (clientArray[i].loggedIn)
                        ++connectedCount;
                    }
                  }
                  if (connectedCount > 1) {
                    synchronized(ticksInProgress) {
                      Long _clock = new Long(clock);
                      Integer remaining = (Integer)ticksInProgress.get(_clock);
                      if (remaining == null)
                        ticksInProgress.put(_clock,new Integer(connectedCount-1));
                      else {
                        if (remaining.intValue() <= 1) {
                          synchronized(clients) {
                            for(int i=0;i<clientArray.length;i++) {
                              if (clientArray[i].loggedIn) {
                                clientArray[i].out.sendPacket("GLOBALTICKCOMPLETE",packet[1]);
                                clientArray[i].out.flush();
                              }
                            }
                          }
                          ticksInProgress.remove(_clock);
                        } else ticksInProgress.put(_clock,new Integer(remaining.intValue() - 1));
                      }
                    }
                  } else {
                    synchronized(clients) {
                      for(int i=0;i<clientArray.length;i++) {
                        if (clientArray[i].loggedIn) {
                          clientArray[i].out.sendPacket("GLOBALTICKCOMPLETE",packet[1]);
                          clientArray[i].out.flush();
                        }
                      }
                    }
                  } */
                } catch (NumberFormatException e) {
                  out.sendPacket("EBADPKT","Clock value must be an integer");
                  out.flush();
                }
              }
            } else if ("STAT".equals(packet[0])) {
              // Statistics packets report statistics
              // Arguments: stat name, stat value
              if (!loggedIn) {
                out.sendPacket("ENOTLOGGEDIN");
                out.flush();
              } else if (packet.length < 3) {
                out.sendPacket("EBADPKT","STAT requires parameter name and value");
                out.flush();
              } else {
                synchronized(statistics) {
                  statistics.put(packet[1],packet[2]);
                }
              }
            } else if ("CELL".equals(packet[0])) {
              // Receives a cell from a simulation
              // Arguments: origin (string), destination (numeric), parent id,
              //   generation, energy, genome type (numeric), genome data (base64)
              if (!loggedIn) {
                out.sendPacket("ENOTLOGGEDIN");
                out.flush();
              } else if (packet.length < 8) {
                out.sendPacket("EBADPKT","CELL requires cell data arguments and destination");
                out.flush();
              } else {
                try {
                  int destId = Integer.parseInt(packet[2]);
                  destId = ((destId < 0) ? ((destId == -2147483648) ? 2147483647 : -destId) : destId) % clientArray.length;
                  NetServerClientConnection dest;
                  synchronized(clients) {
                    dest = clientArray[destId];
                    int cnt = 0;
                    while (!dest.loggedIn&&(cnt < clientArray.length)) {
                      destId = (destId+1) % clientArray.length;
                      dest = clientArray[destId];
                      ++cnt;
                    }
                    if (!dest.loggedIn) {
                      out.sendPacket("ENODESTINATION","No destination for cell");
                      out.flush();
                    } else {
                      // Packet can be passed along as-is to destination
                      dest.out.sendPacket(packet);
                    }
                  }
                } catch (NumberFormatException e) {
                  out.sendPacket("EBADPKT","Destination must be an integer");
                  out.flush();
                }
              }
            } else if ("WHO".equals(packet[0])) {
              // Query other clients
              if (!loggedIn) {
                out.sendPacket("ENOTLOGGEDIN");
                out.flush();
              } else {
                String[] pkt = new String[5];
                synchronized(clients) {
                  for(int i=0;i<clientArray.length;) {
                    if (clientArray[i].loggedIn) {
                      pkt[0] = "WHOLIST";
                      pkt[1] = Integer.toString(i);
                      pkt[2] = clientArray[i].simulationName;
                      pkt[3] = clientArray[i].remoteAddress;
                      pkt[4] = clientArray[i].remoteVersion;
                      pkt[5] = Long.toString(clientArray[i].clock);
                      out.sendPacket(pkt);
                    }
                  }
                }
              }
            } else if ("PING".equals(packet[0])) {
              // PONG is replied to pings and can have an arbitrary argument
              // that is echoed (such as a time)
              if (packet.length < 2)
                out.sendPacket("PONG");
              else out.sendPacket("PONG",packet[1]);
              out.flush();
            } else if ("HELP".equalsIgnoreCase(packet[0])) {
              out.sendPacket("HELPINFO","* Possible Client-Server Packet Types (upper-case):");
              out.sendPacket("HELPINFO","  HELLO, PING, CELL, WHO, STAT, CRESP");
              out.sendPacket("HELPINFO","* Possible Server-Client Errors:");
              out.sendPacket("HELPINFO","  EBADPKT, EUNKNOWNTYPE, EDUPNAME, ENOTLOGGEDIN, ENODESTINATION");
              out.sendPacket("HELPINFO","* Possible Server-Client Packet Types:");
              out.sendPacket("HELPINFO","  PONG, WHOLIST, CELL, GLOBALTICKCOMPLETE, CMD");
              out.sendPacket("HELPINFO","* NetServer Archis Version "+Archis.ARCHIS_VERSION);
              out.flush();
            } else {
              out.sendPacket("EUNKNOWNTYPE","Packet type unknown");
              out.flush();
            }
          } else {
            out.sendPacket("EBADPKT","No packet type found");
            out.flush();
          }
        } catch (InterruptedIOException e) {
          // Socket timeout or Thread interrupt
        } catch (IOException e) {
          try {
            in.close();
          } catch (IOException e2) {}
          try {
            out.close();
          } catch (IOException e2) {}
          try {
            clientConnection.close();
          } catch (IOException e2) {}
          die = true;
        }
      }

      // Remove from lists and stuff when we die
      if (logOutput != null) {
        logOutput.flush();
        logOutput.close();
      }
      if (simulationName != null) {
        synchronized (clientsBySimulationName) {
          clientsBySimulationName.remove(simulationName);
        }
      }
      synchronized(clients) {
        clients.remove(this);
        NetServerClientConnection[] tmp = new NetServerClientConnection[clients.size()];
        int tmp2 = 0;
        for(Iterator i=clients.iterator();i.hasNext();)
          tmp[tmp2++] = (NetServerClientConnection)i.next();
        clientArray = tmp;
      }
      synchronized(netObservers) {
        for(Iterator i=netObservers.iterator();i.hasNext();) {
          WeakReference ref = (WeakReference)i.next();
          if (ref.get() == null)
            i.remove();
          else ((NetObserver)ref.get()).clientDisconnect(clientConnection.getInetAddress(),clientConnection.getPort(),simulationName);
        }
      }
    }
  }
  // -------------------------------------------------------------------------

  // Socket to listen to
  private ServerSocket listenSocket;

  // Clients connected
  private LinkedList clients;

  // Array of clients connected (synchronize on clients to synchronize access)
  private NetServerClientConnection[] clientArray;

  // Map containing clients by client simulation name
  private TreeMap clientsBySimulationName;

  // Set to true to make thread die
  private boolean die;

  // Ticks in progress
  private HashMap ticksInProgress;

  // PrintStream to receive lines of text from commands
  private PrintStream commandTextOutput;

  // Net observers (in WeakReferences)
  private LinkedList netObservers;

  // Log directory or null to disable logging
  private File logDirectory;

  /**
   * Constructs and starts a new Archis net server
   *
   * @param port Port to listen to
   * @throws IOException Could not bind or listen to port
   */
  public NetServer(int port)
    throws IOException
  {
    super("Archis NetServer");
    super.setDaemon(true);

    listenSocket = new ServerSocket(port,32);
    listenSocket.setSoTimeout(60000);
    listenSocket.setReceiveBufferSize(131072);
    die = false;
    clients = new LinkedList();
    clientArray = new NetServerClientConnection[0];
    clientsBySimulationName = new TreeMap();
    ticksInProgress = new HashMap(16384,0.75F);
    commandTextOutput = null;
    netObservers = new LinkedList();
    logDirectory = null;

    start();
  }

  /**
   * Do not use; internal Thread run() method
   */
  public void run()
  {
    for(;;) {
      if (die)
        break;

      Socket clientConnection;
      try {
        clientConnection = listenSocket.accept();
      } catch (InterruptedIOException e) {
        // Socket timeout or Thread interrupt
        continue;
      } catch (IOException e) {
        System.out.println("Internal error in Archis NetServer while listening: "+e.toString());
        break;
      }

      try {
        synchronized(clients) {
          clients.add(new NetServerClientConnection(clientConnection));
          Collections.sort(clients);
          NetServerClientConnection[] tmp = new NetServerClientConnection[clients.size()];
          int tmp2 = 0;
          for(Iterator i=clients.iterator();i.hasNext();)
            tmp[tmp2++] = (NetServerClientConnection)i.next();
          clientArray = tmp;
        }
        synchronized(netObservers) {
          for(Iterator i=netObservers.iterator();i.hasNext();) {
            WeakReference ref = (WeakReference)i.next();
            if (ref.get() == null)
              i.remove();
            else ((NetObserver)ref.get()).clientConnect(clientConnection.getInetAddress(),clientConnection.getPort());
          }
        }
      } catch (IOException e) {}
    }

    // When we die, clean up some stuff
    for(Iterator i=clients.iterator();i.hasNext();) {
      ((NetServerClientConnection)i.next()).die = true;
      ((NetServerClientConnection)i.next()).interrupt();
      i.remove();
    }
    try {
      listenSocket.close();
    } catch (Throwable t) {}
  }

  /**
   * Gets the port we're listening on
   *
   * @return Port number
   */
  public int getPort()
  {
    return listenSocket.getLocalPort();
  }

  /**
   * Gets the current connection count
   *
   * @return Connection count
   */
  public int getConnectionCount()
  {
    return clientArray.length;
  }

  /**
   * Set the PrintStream that should receive command response text from clients
   *
   * @param commandTextOutput Command output stream
   */
  public void setCommandTextOutput(PrintStream commandTextOutput)
  {
    this.commandTextOutput = commandTextOutput;
  }

  /**
   * Sets this thread to die (doesn't happen immediately)
   */
  public void kill()
  {
    die = true;
  }

  /**
   * Kill extra threads if we're gc'd
   */
  protected void finalize()
  {
    for(Iterator i=clients.iterator();i.hasNext();) {
      ((NetServerClientConnection)i.next()).die = true;
      ((NetServerClientConnection)i.next()).interrupt();
      i.remove();
    }
  }

  /**
   * Gets an array of descriptions of all clients connected (including those that haven't logged in)
   *
   * @return String array of descriptions
   */
  public String[] getClientDescriptions()
  {
    synchronized(clients) {
      int n = 0;
      String[] r = new String[clients.size()];
      for(Iterator i=clients.iterator();i.hasNext();)
        r[n++] = i.next().toString();
      return r;
    }
  }

  /**
   * Gets an array of client simulation names
   *
   * @return String array of descriptions
   */
  public String[] getClients()
  {
    synchronized(clients) {
      ArrayList r = new ArrayList(clients.size()+1);
      for(int i=0;i<clientArray.length;i++) {
        if (clientArray[i].loggedIn)
          r.add(clientArray[i]);
      }
      String[] _r = new String[r.size()];
      for(int i=0;i<_r.length;i++)
        _r[i] = ((NetServerClientConnection)r.get(i)).simulationName;
      return _r;
    }
  }

  /**
   * Sends a command to all logged in clients
   *
   * @param command Command to send
   * @param flushOnSend Flush client output on command send
   * @throws IOException I/O error
   */
  public void sendCommandToAll(String command,boolean flushOnSend)
    throws IOException
  {
    synchronized(clients) {
      for(int i=0;i<clientArray.length;i++) {
        if (clientArray[i].loggedIn) {
          clientArray[i].out.sendPacket("CMD",command);
          if (flushOnSend)
            clientArray[i].out.flush();
        }
      }
    }
  }

  /**
   * Send a command to a single client
   *
   * @param simulationName Simulation name of destination client
   * @param command Command to send
   * @param flushOnSend Flush client output on command send
   * @throws IOException I/O error
   * @return Was a logged-in client with the given name found?
   */
  public boolean sendCommand(String simulationName,String command,boolean flushOnSend)
    throws IOException
  {
    NetServerClientConnection client;
    synchronized(clientsBySimulationName) {
      client = (NetServerClientConnection)clientsBySimulationName.get(simulationName);
    }
    if (client == null)
      return false;
    if (!client.loggedIn)
      return false;
    client.out.sendPacket("CMD",command);
    if (flushOnSend)
      client.out.flush();
    return true;
  }

  /**
   * Add a net observer
   *
   * @param observer Net observer
   */
  public void addObserver(NetObserver observer)
  {
    synchronized(netObservers) {
      netObservers.add(new WeakReference(observer));
    }
  }

  /**
   * Remove a net observer
   *
   * @param observer Net observer
   */
  public void removeObserver(NetObserver observer)
  {
    synchronized(netObservers) {
      for(Iterator i=netObservers.iterator();i.hasNext();) {
        WeakReference ref = (WeakReference)i.next();
        if (ref.get() == null)
          i.remove();
        else if (ref.get().equals(observer))
          i.remove();
      }
    }
  }

  /**
   * Gets statistics for a given client connection or returns null if the name was not found
   *
   * @param simulationName Simulation name for this connection
   * @return SortedMap containing most recently reported statistics
   */
  public SortedMap getStatistics(String simulationName)
  {
    NetServerClientConnection client;
    synchronized(clientsBySimulationName) {
      client = (NetServerClientConnection)clientsBySimulationName.get(simulationName);
    }
    if (client == null)
      return null;
    return Collections.unmodifiableSortedMap(client.statistics);
  }

  /**
   * <p>Gets all statistics for all clients connected</p>
   *
   * <p>
   * The format is simulationName/statistic, and so the simulation name
   * can be parsed out from the statistic by looking for the first / character.
   * </p>
   *
   * @return SortedMap containing all statistics
   */
  public SortedMap getAllStatistics()
  {
    TreeMap r = new TreeMap();
    StringBuffer tmp = new StringBuffer(128);
    synchronized(clients) {
      for(int i=0;i<clientArray.length;i++) {
        synchronized(clientArray[i].statistics) {
          for(Iterator i2=clientArray[i].statistics.entrySet().iterator();i2.hasNext();) {
            Map.Entry ent = (Map.Entry)i2.next();
            tmp.append(clientArray[i].simulationName);
            tmp.append('/');
            tmp.append(ent.getKey().toString());
            r.put(tmp.toString(),ent.getValue().toString());
            tmp.delete(0,tmp.length());
          }
        }
      }
    }
    return r;
  }

  /**
   * Sets the log directory where the results of each simulation will be logged
   *
   * @param logDirectory Log directory (or set to null to turn off logging)
   */
  public void setLogDirectory(File logDirectory)
  {
    this.logDirectory = logDirectory;
  }

  /**
   * Gets the current log directory
   *
   * @return Current log directory (or null for none)
   */
  public File getLogDirectory()
  {
    return logDirectory;
  }
}
