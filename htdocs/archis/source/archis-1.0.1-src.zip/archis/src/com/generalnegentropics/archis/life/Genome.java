package com.generalnegentropics.archis.life;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

import java.io.*;
import com.generalnegentropics.archis.universe.*;
import com.generalnegentropics.archis.utils.*;

/**
 * <p>Genome virtual machine interface</p>
 *
 * <p>A genome can have any mode of execution possible.  Implementation of the
 * mutation methods is optional, and it is acceptable for one or all of these
 * methods to do nothing if the given mutation type is not applicable to this
 * genome type.</p>
 *
 * @author Adam Ierymenko
 * @version 1.0
 */

public interface Genome extends Externalizable
{
  /**
   * <p>Constructs a new genome of the same type</p>
   *
   * <p>Whatever is returned by toUnmodifiableByteArray() should be usable
   * here.</p>
   *
   * @param codons Codons to construct new genome from
   * @param start Start of codons in byte array
   * @param length Length of codons in byte array
   * @return New genome object (unrelated to this one)
   */
  Genome createNew(byte[] codons,int start,int length);

  /**
   * <p>Constructs a new genome of the same type</p>
   *
   * <p>Whatever is returned by toUnmodifiableByteArray() should be usable
   * here.</p>
   *
   * @param codons Codons to construct new genome from
   * @return New genome object (unrelated to this one)
   */
  Genome createNew(byte[] codons);

  /**
   * Constructs a new genome of the same type from codons in human readable form
   *
   * @param randomSource Source for random numbers to select codons for instructions (if needed for this genome type)
   * @param syntheticGenome Codons in some human readable format (genome type specific)
   * @return New genome object (unrelated to this one)
   */
  Genome createNew(RandomSource randomSource,String syntheticGenome);

  /**
   * Constructs a new random genome of the same type
   *
   * @param randomSource Source for random numbers to create random genome
   * @param meanSize Mean size in codons (actual size of a codon is genome type specific)
   * @param sizeDeviation Size deviation +/- mean
   * @return New genome object (unrelated to this one)
   */
  Genome createNew(RandomSource randomSource,int meanSize,int sizeDeviation);

  /**
   * <p>Returns a 'canonical' equivalent copy of this genome.</p>
   *
   * <p>
   * This method works by maintaining an internal Map with weak keys and
   * values containing genomes.  When this is called, any equivalent genomes
   * within this Map are returned.  Otherwise, the current genome is added
   * to the map and the method returns itself.  The result of using this is
   * to ensure that only one copy of each genome actually resides in memory.
   * Use of this method saves memory at the expense of a small CPU overhead.
   * </p>
   *
   * <p>
   * Genomes must implement this.
   * </p>
   *
   * @return Genome equal to this one (may return the same object)
   */
  Genome canonicalize();

  /**
   * Returns a genome with a single point mutation from this one
   *
   * @param randomSource Randomness source
   * @return Point mutated genome
   */
  Genome pointMutation(RandomSource randomSource);

  /**
   * Returns a genome with a random insertion mutation at a random position
   *
   * @param randomSource Randomness source
   * @return Insertion mutated genome
   */
  Genome insertionMutation(RandomSource randomSource);

  /**
   * Returns a genome with a random deletion mutation at a random position
   *
   * @param randomSource Randomness source
   * @return Deletion mutated genome
   */
  Genome deletionMutation(RandomSource randomSource);

  /**
   * Returns a genome with a random duplication mutation at a random position of a random length
   *
   * @param randomSource Randomness source
   * @return Duplication mutated genome
   */
  Genome duplicationMutation(RandomSource randomSource);

  /**
   * Concatenate another genome onto the end of this one and return result
   *
   * @param genome Genome to concatenate
   * @return Genome consisting of this genome plus concatenated genome
   * @throws IncompatibleGenomeException Genome is not from same GVM
   * @throws UnsupportedOperationException This genome type does not support this
   */
  Genome concat(Genome genome)
    throws IncompatibleGenomeException,UnsupportedOperationException;

  /**
   * Calculates a checksum of this genome
   *
   * @return Checksum value
   */
  int checksum();

  /**
   * Executes the genome and returns the resulting output
   *
   * @param input Input data as an array of int[] arrays (any other type will cause type cast error)
   * @param output Recipient of output
   * @param cell Cell genome is executing for
   * @param memory Memory of cell
   * @param maxInstructions Maximum number of instructions to permit to be executed
   * @return Number of instructions executed (not including introns)
   */
  int execute(IntegerInput[] input,Universe output,Cell cell,int[] memory,int maxInstructions);

  /**
   * Get size in codons
   *
   * @return Number of codons in genome
   */
  int size();

  /**
   * Get actual size in bytes in memory
   *
   * @return Number of bytes taken up by genome
   */
  int sizeBytes();

  /**
   * Dumps out the genome as bytes to an output stream
   *
   * @param out Output stream
   * @throws IOException An error occurred writing to the stream
   * @return Number of bytes written
   */
  int writeTo(OutputStream out)
    throws IOException;

  /**
   * <p>Returns a byte array representation of this genome.</p>
   *
   * <p>It is acceptable to return the actual byte array used internally to
   * store the genome here for speed reasons.  (Of course, if the genome does
   * not store itself internally in a byte array, then something else must be
   * done.)  Therefore, <b>the byte array returned by this method should never
   * be modified.</b> (The name reflects this just to remind you...)</p>
   *
   * <p>This is not necessarily the same size as what is returned by sizeBytes().
   * That method is for determining memory usage.  This may also not be the
   * same size as size() returns.</p>
   *
   * @return Byte array representation of this genome
   */
  byte[] toUnmodifiableByteArray();

  /**
   * Returns the number of codons that this genome type uses
   *
   * @return Number of codons
   */
  int getCodonCount();

  /**
   * <p>Counts all codons in genome</p>
   *
   * <p>
   * This method increments each element of the array based on it's corresponding
   * codon.  The array must be at least getCodonCount() in length or an
   * ArrayIndexOutOfBoundsException may occur.
   * </p>
   *
   * @param codonCounts Array of counts to be incremented
   */
  void getCodonDistribution(long[] codonCounts);
}
