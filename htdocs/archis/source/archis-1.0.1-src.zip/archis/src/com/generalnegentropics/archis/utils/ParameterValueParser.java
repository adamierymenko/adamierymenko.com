package com.generalnegentropics.archis.utils;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

/**
 * Contains static methods to help get values to condition parameters
 *
 * @author Adam Ierymenko
 * @version 1.0
 */

public class ParameterValueParser
{
  /**
   * Returns whether or not an object represents a true value (e.g. true, yes, 1, etc.)
   *
   * @param o An object
   * @return Boolean value
   */
  public static boolean getBoolean(Object o)
  {
    if (o == null)
      return false;
    if (o instanceof Boolean)
      return ((Boolean)o).booleanValue();
    if (o instanceof Number)
      return (((Number)o).intValue() != 0);
    String s = o.toString().trim();
    if (s.length() == 0)
      return false;
    char c = s.charAt(0);
    return ((c == '1')||(c == 'y')||(c == 'Y')||(c == 't')||(c == 'T'));
  }

  /**
   * Gets an integer from an object (0 for null or unparseable)
   *
   * @param o Object
   * @return Result value
   */
  public static int getInt(Object o)
  {
    if (o == null)
      return 0;
    if (o instanceof Number)
      return ((Number)o).intValue();
    try {
      return Integer.parseInt(o.toString().trim());
    } catch (NumberFormatException e) {
      return 0;
    }
  }

  /**
   * Gets a long from an object (0 for null or unparseable)
   *
   * @param o Object
   * @return Result value
   */
  public static long getLong(Object o)
  {
    if (o == null)
      return 0L;
    if (o instanceof Number)
      return ((Number)o).longValue();
    try {
      return Long.parseLong(o.toString().trim());
    } catch (NumberFormatException e) {
      return 0L;
    }
  }

  /**
   * Gets a float from an object (0 for null or unparseable)
   *
   * @param o Object
   * @return Result value
   */
  public static float getFloat(Object o)
  {
    if (o == null)
      return 0.0F;
    if (o instanceof Number)
      return ((Number)o).floatValue();
    try {
      return Float.parseFloat(o.toString().trim());
    } catch (NumberFormatException e) {
      return 0.0F;
    }
  }

  /**
   * Gets a double from an object (0 for null or unparseable)
   *
   * @param o Object
   * @return Result value
   */
  public static double getDouble(Object o)
  {
    if (o == null)
      return 0.0;
    if (o instanceof Number)
      return ((Number)o).doubleValue();
    try {
      return Double.parseDouble(o.toString().trim());
    } catch (NumberFormatException e) {
      return 0.0;
    }
  }
}
