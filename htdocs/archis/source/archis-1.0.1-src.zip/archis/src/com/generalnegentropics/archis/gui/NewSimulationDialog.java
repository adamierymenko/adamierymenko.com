package com.generalnegentropics.archis.gui;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

import java.awt.*;
import javax.swing.*;
import com.generalnegentropics.archis.*;
import java.util.*;
import java.io.File;
import java.io.IOException;
import javax.swing.border.*;
import java.awt.event.*;
import com.generalnegentropics.archis.universe.environmentalconditions.*;
import com.generalnegentropics.archis.utils.*;

/**
 * Dialog box for new simulations
 *
 * @author Adam Ierymenko
 * @version 1.0
 */

public class NewSimulationDialog extends JFrame
{
  private JPanel contentPane;
  private java.util.List simulations;
  GridBagLayout gridBagLayout1 = new GridBagLayout();
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JTextField nameTextField = new JTextField();
  JTextField threadsTextField = new JTextField();
  TitledBorder titledBorder1;
  JPanel jPanel1 = new JPanel();
  JButton cancelButton = new JButton();
  JButton okButton = new JButton();
  JLabel jLabel3 = new JLabel();
  JComboBox prngComboBox = new JComboBox();
  JLabel jLabel4 = new JLabel();
  JTextField randomSeedTextField = new JTextField();
  JLabel jLabel5 = new JLabel();
  JLabel jLabel6 = new JLabel();
  JTextField statisticsLogFileTextField = new JTextField();
  JButton setStatisticsLogFileButton = new JButton();

  public NewSimulationDialog(java.util.List simulations)
  {
    this.simulations = simulations;
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
    this.setSize(500,275);
    this.setIconImage(Archis.ICON);
    this.setLocation(170,170);
    prngComboBox.addItem("Mersenne Twister");
    prngComboBox.addItem("java.util.Random");
    prngComboBox.addItem("Incrementing Placebo");
    prngComboBox.setSelectedItem("Mersenne Twister");
    randomSeedTextField.setText(Long.toString(System.currentTimeMillis() % (long)Integer.MAX_VALUE));
  }
  private void jbInit() throws Exception
  {
    contentPane = (JPanel)this.getContentPane();
    titledBorder1 = new TitledBorder("");
    jLabel1.setHorizontalAlignment(SwingConstants.RIGHT);
    jLabel1.setHorizontalTextPosition(SwingConstants.RIGHT);
    jLabel1.setText("Number of Execution Threads:");
    this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    this.setTitle("New Simulation");
    contentPane.setLayout(gridBagLayout1);
    jLabel2.setHorizontalAlignment(SwingConstants.RIGHT);
    jLabel2.setHorizontalTextPosition(SwingConstants.RIGHT);
    jLabel2.setText("Simulation Name:");
    threadsTextField.setText("1");
    cancelButton.setText("Cancel");
    cancelButton.addActionListener(new NewSimulationDialog_cancelButton_actionAdapter(this));
    okButton.setText("OK");
    okButton.addActionListener(new NewSimulationDialog_okButton_actionAdapter(this));
    jLabel3.setHorizontalAlignment(SwingConstants.RIGHT);
    jLabel3.setHorizontalTextPosition(SwingConstants.RIGHT);
    jLabel3.setText("Pseudo-Random Number Generator:");
    jLabel4.setHorizontalAlignment(SwingConstants.RIGHT);
    jLabel4.setHorizontalTextPosition(SwingConstants.RIGHT);
    jLabel4.setText("Random Seed:");
    randomSeedTextField.setText("0");
    jLabel5.setFont(new java.awt.Font("Dialog", 0, 11));
    jLabel5.setHorizontalAlignment(SwingConstants.RIGHT);
    jLabel5.setHorizontalTextPosition(SwingConstants.RIGHT);
    jLabel5.setText("(Suggested Value Derived from Clock)");
    nameTextField.setText("");
    jLabel6.setHorizontalAlignment(SwingConstants.RIGHT);
    jLabel6.setHorizontalTextPosition(SwingConstants.RIGHT);
    jLabel6.setText("Statistics Log File:");
    setStatisticsLogFileButton.setText("Browse...");
    setStatisticsLogFileButton.addActionListener(new NewSimulationDialog_setStatisticsLogFileButton_actionAdapter(this));
    statisticsLogFileTextField.setEditable(false);
    statisticsLogFileTextField.setText("");
    contentPane.add(jLabel1,          new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 0, 5), 0, 0));
    contentPane.add(jLabel2,            new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 0, 5), 0, 0));
    contentPane.add(nameTextField,            new GridBagConstraints(1, 0, 2, 1, 1.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 0, 0, 5), 0, 0));
    contentPane.add(threadsTextField,            new GridBagConstraints(1, 1, 2, 1, 1.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 0, 0, 5), 0, 0));
    contentPane.add(jPanel1,          new GridBagConstraints(0, 9, 3, 1, 1.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 5, 5), 0, 0));
    jPanel1.add(okButton, null);
    jPanel1.add(cancelButton, null);
    contentPane.add(jLabel3,            new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 0, 5), 0, 0));
    contentPane.add(prngComboBox,           new GridBagConstraints(1, 2, 2, 1, 1.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 0, 0, 5), 0, 0));
    contentPane.add(jLabel4,          new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 0, 5), 0, 0));
    contentPane.add(randomSeedTextField,      new GridBagConstraints(1, 3, 2, 1, 1.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 0, 0, 5), 0, 0));
    contentPane.add(jLabel5,      new GridBagConstraints(0, 4, 3, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(0, 5, 0, 5), 0, 0));
    contentPane.add(jLabel6,    new GridBagConstraints(0, 5, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(5, 5, 5, 5), 0, 0));
    contentPane.add(statisticsLogFileTextField,    new GridBagConstraints(1, 5, 1, 1, 1.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(5, 0, 5, 5), 0, 0));
    contentPane.add(setStatisticsLogFileButton,   new GridBagConstraints(2, 5, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 5), 0, 0));
  }

  void okButton_actionPerformed(ActionEvent e) {
    // OK
    if (nameTextField.getText().trim().length() <= 0) {
      JOptionPane.showMessageDialog(this,"Please enter a simulation name","Enter Name",JOptionPane.INFORMATION_MESSAGE);
      return;
    }
    try {
      int threads = Integer.parseInt(threadsTextField.getText().trim());
      long seed = Long.parseLong(randomSeedTextField.getText().trim());
      RandomSource prng = null;
      Object prngSelected = prngComboBox.getSelectedItem();
      if ("Mersenne Twister".equals(prngSelected)) {
        prng = new MersenneTwisterRandomSource(seed);
      } else if ("java.util.Random".equals(prngSelected)) {
        prng = new JavaBuiltinRandomSource(seed);
      } else if ("Incrementing Placebo".equals(prngSelected)) {
        prng = new NonRandomRandomSource(seed);
      }
      if (prng == null)
        throw new RuntimeException("Internal error: bad selected PRNG!");
      File lf = new File(statisticsLogFileTextField.getText().trim());
      if (lf.exists()) {
        if (JOptionPane.showConfirmDialog(this,"File already exists: replace?","Replace File?",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION)
          lf.delete();
        else return;
      }
      Simulation simulation = new Simulation(threads,nameTextField.getText().trim(),prng);
      simulation.universe().addCondition(new ReproductionCondition());
      simulation.universe().addCondition(new RandomSourceCondition());
      simulation.universe().addCondition(new EnvironmentalMutationCondition());
      try {
        if (statisticsLogFileTextField.getText().trim().length() > 0)
          simulation.openStatisticsLogFile(lf);
      } catch (IOException ex) {
        JOptionPane.showMessageDialog(this,"Could not open simulation log file; logging disabled ("+ex.getMessage()+")","Error Opening Log File",JOptionPane.ERROR_MESSAGE);
      }
      SimulationWindow sw = new SimulationWindow(simulation);
      sw.setVisible(true);
      simulations.add(sw);
      this.setVisible(false);
      this.dispose();
    } catch (NumberFormatException ex) {
      JOptionPane.showMessageDialog(this,"Integer fields must be integer values","Bad value",JOptionPane.ERROR_MESSAGE);
    }
  }

  void cancelButton_actionPerformed(ActionEvent e) {
    // Cancel
    this.setVisible(false);
    this.dispose();
  }

  void setStatisticsLogFileButton_actionPerformed(ActionEvent e) {
    JFileChooser fc = new JFileChooser();
    fc.setMultiSelectionEnabled(false);
    fc.setDialogType(fc.SAVE_DIALOG);
    fc.setFileSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    if (fc.showSaveDialog(this) == fc.APPROVE_OPTION) {
      File f = fc.getSelectedFile();
      if (f != null) {
        if (f.getName().trim().length() > 0)
          statisticsLogFileTextField.setText(f.getAbsolutePath());
      }
    }
  }
}

class NewSimulationDialog_okButton_actionAdapter implements java.awt.event.ActionListener {
  NewSimulationDialog adaptee;

  NewSimulationDialog_okButton_actionAdapter(NewSimulationDialog adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.okButton_actionPerformed(e);
  }
}

class NewSimulationDialog_cancelButton_actionAdapter implements java.awt.event.ActionListener {
  NewSimulationDialog adaptee;

  NewSimulationDialog_cancelButton_actionAdapter(NewSimulationDialog adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.cancelButton_actionPerformed(e);
  }
}

class NewSimulationDialog_setStatisticsLogFileButton_actionAdapter implements java.awt.event.ActionListener {
  NewSimulationDialog adaptee;

  NewSimulationDialog_setStatisticsLogFileButton_actionAdapter(NewSimulationDialog adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.setStatisticsLogFileButton_actionPerformed(e);
  }
}
