package com.generalnegentropics.archis;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

import java.util.*;
import java.io.*;
import java.lang.ref.*;
import java.net.*;
import java.util.zip.*;
import javax.swing.JFrame;
import com.generalnegentropics.archis.universe.*;
import com.generalnegentropics.archis.universe.catastrophes.*;
import com.generalnegentropics.archis.universe.environmentalconditions.*;
import com.generalnegentropics.archis.universe.probes.*;
import com.generalnegentropics.archis.universe.rewardfunctions.*;
import com.generalnegentropics.archis.utils.*;
import com.generalnegentropics.archis.net.*;
import com.generalnegentropics.archis.cmdline.ArchisCommandLine;

/**
 * <p>Main class for a running simulation</p>
 *
 * <p>This class starts a simulation thread to handle simulation asynchronously.
 * When started, the simulator is not running and must be started with start().
 * The thread created by this class can be destroyed by destroy() or will be
 * stopped if this class is garbage collected.</p>
 *
 * <p>This is really just a wrapper; most of the guts are in Universe.java.</p>
 *
 * @author Adam Ierymenko
 * @version 3.0
 */

public class Simulation
{
  /**
   * Built-in environmental conditions (key is Class, value is description)
   */
  public static final Map BUILTIN_ENVIRONMENTAL_CONDITIONS;
  /**
   * Built-in reward functions (key is Class, value is description)
   */
  public static final Map BUILTIN_REWARD_FUNCTIONS;
  /**
   * Built-in catastrophes (key is Class, value is description)
   */
  public static final Map BUILTIN_CATASTROPHES;
  /**
   * Built-in probes (key is Class, value is description)
   */
  public static final Map BUILTIN_PROBES;

  //
  // Load in all the builtins
  //
  static
  {
    HashMap tmp = new HashMap(4,0.95F);
    tmp.put(new ExtinctionLevelEvent().getClass(),ExtinctionLevelEvent.CONDITION_DESCRIPTION);
    tmp.put(new Irradiate().getClass(),Irradiate.CONDITION_DESCRIPTION);
    BUILTIN_CATASTROPHES = Collections.unmodifiableMap(tmp);
    tmp = new HashMap(16,0.95F);
    tmp.put(new EnvironmentalMutationCondition().getClass(),EnvironmentalMutationCondition.CONDITION_DESCRIPTION);
    tmp.put(new GenesisCondition().getClass(),GenesisCondition.CONDITION_DESCRIPTION);
    tmp.put(new GPReproductionCondition().getClass(),GPReproductionCondition.CONDITION_DESCRIPTION);
    tmp.put(new Landscape2D().getClass(),Landscape2D.CONDITION_DESCRIPTION);
    tmp.put(new LifespanCondition().getClass(),LifespanCondition.CONDITION_DESCRIPTION);
    tmp.put(new RandomDeathCondition().getClass(),RandomDeathCondition.CONDITION_DESCRIPTION);
    tmp.put(new RandomSourceCondition().getClass(),RandomSourceCondition.CONDITION_DESCRIPTION);
    tmp.put(new ReproductionCondition().getClass(),ReproductionCondition.CONDITION_DESCRIPTION);
    BUILTIN_ENVIRONMENTAL_CONDITIONS = Collections.unmodifiableMap(tmp);
    tmp = new HashMap(6,0.95F);
    tmp.put(new ChiSquareProbe().getClass(),ChiSquareProbe.PROBE_DESCRIPTION);
    tmp.put(new CompressibilityProbe().getClass(),CompressibilityProbe.PROBE_DESCRIPTION);
    tmp.put(new GenesisProbe().getClass(),GenesisProbe.PROBE_DESCRIPTION);
    BUILTIN_PROBES = Collections.unmodifiableMap(tmp);
    tmp = new HashMap(16,0.95F);
    tmp.put(new BaselineRewardFunction().getClass(),BaselineRewardFunction.CONDITION_DESCRIPTION);
    tmp.put(new BiggestRewardFunction().getClass(),BiggestRewardFunction.CONDITION_DESCRIPTION);
    tmp.put(new FecundityRewardFunction().getClass(),FecundityRewardFunction.CONDITION_DESCRIPTION);
    tmp.put(new FibonacciSequenceRewardFunction().getClass(),FibonacciSequenceRewardFunction.CONDITION_DESCRIPTION);
    tmp.put(new SmallestRewardFunction().getClass(),SmallestRewardFunction.CONDITION_DESCRIPTION);
    BUILTIN_REWARD_FUNCTIONS = Collections.unmodifiableMap(tmp);
  }

  // Random source for simulation
  private RandomSource randomSource;

  // Universe that forms the core of this simulation
  private Universe universe;

  // LinkedList of WeakReference references to SimulationObserver objects
  private LinkedList observers;

  // Simulation run thread
  private SimulationRunnerThread srthread;

  // Statistics
  private TreeMap statistics;

  // Name of simulation
  private String name;

  // Number of threads
  private int nthreads;

  // Frames open for GUI in this simulation
  private LinkedList openFrames;

  // Halt reason or null for none
  private String haltReason;

  // Statistics log file and PrintStream
  private File statisticsLogFile;
  private PrintStream statisticsPrintStream;
  private boolean statisticsLogHeaderWritten;

  // Cell ID counter
  private volatile long cellIdCounter;

  // Connection to NetServer
  private Socket netServerSocket;
  private ArchisProtocolInput netServerInput;
  private ArchisProtocolOutput netServerOutput;
  private NetServerInputHandler netServerInputHandlerThread;

  // Permit remote commands?
  private boolean allowRemoteCommands;

  // Universe elements (key is class, value is description)
  private HashMap environmentalConditions;
  private HashMap rewardFunctions;
  private HashMap catastrophes;
  private HashMap probes;

  // Command line interface
  private ArchisCommandLine commandLine;

  // Stop point
  private long stopPoint;

  // -------------------------------------------------------------------------
  // Internal thread for running the simulation
  // -------------------------------------------------------------------------
  private class SimulationRunnerThread extends Thread
  {
    public volatile boolean run;
    public volatile boolean running;
    public volatile boolean step;
    public volatile boolean die;
    public long startTime,stopTime;

    public SimulationRunnerThread()
    {
      super("Archis Simulation Thread");
      super.setDaemon(false);
      run = false;
      running = false;
      die = false;
      step = false;
      startTime = stopTime = 0L;
      start();
    }

    public void run()
    {
      for(;;) {
        if (die)
          break;

        if (run||step) {
          running = true;

          startTime = System.currentTimeMillis();
          universe.tick();
          stopTime = System.currentTimeMillis();

          if (statisticsPrintStream != null) {
            synchronized(statisticsPrintStream) {
              if (statisticsPrintStream != null) {
                if (!statisticsLogHeaderWritten) {
                  statisticsPrintStream.print("\"Simulation Clock\"");
                  for(Iterator i=statistics.keySet().iterator();i.hasNext();) {
                    String tmp = i.next().toString();
                    statisticsPrintStream.print(",\"");
                    if (tmp.length() >= 5)
                      statisticsPrintStream.print(tmp.substring(4));
                    else statisticsPrintStream.print(tmp);
                    statisticsPrintStream.print('"');
                  }
                  statisticsPrintStream.println();
                  statisticsLogHeaderWritten = true;
                }
                statisticsPrintStream.print(Long.toString(universe.clock()));
                for(Iterator i=statistics.values().iterator();i.hasNext();) {
                  statisticsPrintStream.print(',');
                  statisticsPrintStream.print(i.next().toString());
                }
                statisticsPrintStream.println();
              }
            }
          }

          // Notify observers of tick
          synchronized(observers) {
            for(Iterator i=observers.iterator();i.hasNext();) {
              WeakReference ref = (WeakReference)i.next();
              SimulationObserver obs = (SimulationObserver)ref.get();
              if (obs == null)
                i.remove();
              else {
                try {
                  obs.tick();
                } catch (Throwable t) {}
              }
            }
          }

          // Send stats and tick message to NetServer if connected
          if (netServerOutput != null) {
            try {
              String[] pkt = new String[3];
              pkt[0] = "STAT";
              synchronized(statistics) {
                for(Iterator i=statistics.entrySet().iterator();i.hasNext();) {
                  Map.Entry ent = (Map.Entry)i.next();
                  pkt[1] = ent.getKey().toString();
                  pkt[2] = ent.getValue().toString();
                  netServerOutput.sendPacket(pkt);
                }
              }
              netServerOutput.sendPacket("TICK",Long.toString(universe.clock()));
            } catch (IOException e) {
              disconnect();
            }
          }

          step = false;

          // Check for stop point
          if (stopPoint > 0L) {
            if (universe.clock() >= stopPoint) {
              haltReason = "Stop point at tick "+stopPoint+" reached";
              stopPoint = 0L;
            }
          }

          // Check for halt reason
          if (haltReason != null) {
            run = false;
            if (netServerOutput != null) {
              try {
                netServerOutput.sendPacket("CRESP","Simulation halted: "+haltReason);
                netServerOutput.flush();
              } catch (IOException e) {}
            }
            synchronized(observers) {
              for(Iterator i=observers.iterator();i.hasNext();) {
                WeakReference ref = (WeakReference)i.next();
                SimulationObserver obs = (SimulationObserver)ref.get();
                if (obs == null)
                  i.remove();
                else {
                  try {
                    obs.halted(haltReason);
                  } catch (Throwable t) {}
                }
              }
            }
          }
        } else {
          if (netServerOutput != null) {
            try {
              netServerOutput.flush();
            } catch (IOException e) {
              disconnect();
            }
          }
          running = false;
          step = false;
          try {
            Thread.sleep(10000L);
          } catch (InterruptedException e) {}
        }
      }
    }
  }
  // -------------------------------------------------------------------------

  // -------------------------------------------------------------------------
  // Internal class for a PrintStream to send command responses to NetServer
  // -------------------------------------------------------------------------
  private static class NetServerCommandResponseOutputStream extends OutputStream
  {
    private ArchisProtocolOutput out;
    private StringBuffer lineBuf;

    public NetServerCommandResponseOutputStream(ArchisProtocolOutput out)
    {
      super();
      this.out = out;
      lineBuf = new StringBuffer(1024);
    }

    public synchronized void write(int b)
      throws IOException
    {
      if (b != '\r') {
        if (b == '\n') {
          out.sendPacket("CRESP",lineBuf.toString());
          lineBuf.delete(0,lineBuf.length());
        } else lineBuf.append((char)b);
      }
    }

    public void flush()
      throws IOException
    {
    }

    public void close()
      throws IOException
    {
    }
  }
  // -------------------------------------------------------------------------

  // -------------------------------------------------------------------------
  // Internal thread for the NetServer input stream
  // -------------------------------------------------------------------------
  private class NetServerInputHandler extends Thread
  {
    public boolean die;
    public ArchisProtocolInput in;
    public ArchisProtocolOutput out;
    public PrintStream commandResponsePrintStream;

    public NetServerInputHandler(ArchisProtocolInput in,ArchisProtocolOutput out)
    {
      super("NetServer Input Handler");
      super.setDaemon(true);
      this.in = in;
      this.out = out;
      commandResponsePrintStream = new PrintStream(new Simulation.NetServerCommandResponseOutputStream(out),true);
      die = false;
      start();
    }

    public void run()
    {
      for(;!die;) {
        try {
          String[] packet = in.readPacket();

          if (packet.length >= 1) {
            if ("CMD".equals(packet[0])) {
              // Execute command and return results
              if (packet.length >= 2) {
                if (allowRemoteCommands)
                  commandLine.exec(packet[1],commandResponsePrintStream);
                else commandResponsePrintStream.println("Remote commands disabled.");
                commandResponsePrintStream.flush();
                out.flush();
              }
            } else if ("PONG".equals(packet[0])) {
              // Ping response
            } else if ("CELL".equals(packet[0])) {
              // Cell introduction from another simulation
            } else if ("GLOBALTICKCOMPLETE".equals(packet[0])) {
              // The entire "herd" of simulations has completed the given tick
            }
          }
        } catch (InterruptedIOException e) {
          // Interrupt or timeout
        } catch (IOException e) {
          // I/O error kills thread
          die = true;
        }
      }
    }
  }
  // -------------------------------------------------------------------------

  /**
   * <p>Constructs a new simulation</p>
   *
   * <p>The recommended number of threads is 1 for single processor systems,
   * 1 or 2 for duals (try both and see what performs better),and n-1 for
   * systems with more than 2 processors where n is the number of processors.</p>
   *
   * @param nthreads Number of concurrent threads
   * @param name Name of this simulation
   * @param randomSource PRNG for this simulation
   */
  public Simulation(int nthreads,String name,RandomSource randomSource)
  {
    this.name = name;
    this.nthreads = nthreads;
    this.randomSource = randomSource;

    universe = new Universe(nthreads,this);
    srthread = new SimulationRunnerThread();
    commandLine = new ArchisCommandLine(this);

    cellIdCounter = 0L;
    allowRemoteCommands = false;
    stopPoint = 0L;

    observers = new LinkedList();
    statistics = new TreeMap();
    openFrames = new LinkedList();

    statisticsLogFile = null;
    statisticsPrintStream = null;
    statisticsLogHeaderWritten = false;

    netServerSocket = null;
    netServerInput = null;
    netServerOutput = null;
    netServerInputHandlerThread = null;

    environmentalConditions = new HashMap(64,0.75F);
    rewardFunctions = new HashMap(64,0.75F);
    catastrophes = new HashMap(64,0.75F);
    probes = new HashMap(64,0.75F);
    environmentalConditions.putAll(BUILTIN_ENVIRONMENTAL_CONDITIONS);
    rewardFunctions.putAll(BUILTIN_REWARD_FUNCTIONS);
    catastrophes.putAll(BUILTIN_CATASTROPHES);
    probes.putAll(BUILTIN_PROBES);
  }

  /**
   * Gets stop point (&lt;= 0 means disabled)
   *
   * @return Stop point
   */
  public long getStopPoint()
  {
    return stopPoint;
  }

  /**
   * Sets a stop point to stop after tick #n (set to 0 to disable)
   *
   * @param stopPoint Stop point or 0 to disable
   */
  public void setStopPoint(long stopPoint)
  {
    this.stopPoint = stopPoint;
  }

  /**
   * Gets whether this simulation should allow remote commands
   *
   * @return Allow remote commands?
   */
  public boolean getAllowRemoteCommands()
  {
    return allowRemoteCommands;
  }

  /**
   * Sets whether this simulation should allow remote commands
   *
   * @param allowRemoteCommands Allow remote commands?
   */
  public void setAllowRemoteCommands(boolean allowRemoteCommands)
  {
    this.allowRemoteCommands = allowRemoteCommands;
  }

  /**
   * Returns whether or not we are connected to a NetServer
   *
   * @return Connected to NetServer?
   */
  public boolean isConnected()
  {
    return (netServerSocket != null);
  }

  /**
   * Gets a description of the current NetServer connection
   *
   * @return Description of connection
   */
  public String getConnectionInfo()
  {
    if (netServerSocket == null)
      return "Not connected";
    else return "Connected to: "+netServerSocket.getInetAddress().toString()+":"+netServerSocket.getPort();
  }

  /**
   * Connects to a NetServer (existing connections are closed)
   *
   * @param address InetAddress to connect to
   * @param port Port to connect to
   * @throws IOException Could not connect
   */
  public synchronized void connect(InetAddress address,int port)
    throws IOException
  {
    Socket newSocket = new Socket(address,port);
    newSocket.setReceiveBufferSize(131072);
    newSocket.setSendBufferSize(131072);

    // Close any existing socket
    disconnect();

    netServerSocket = newSocket;
    netServerInput = new ArchisProtocolInput(newSocket.getInputStream(),ArchisProtocolOutput.SUGGESTED_BLOCKSIZE);
    netServerOutput = new ArchisProtocolOutput(newSocket.getOutputStream(),ArchisProtocolOutput.SUGGESTED_BLOCKSIZE);
    netServerInputHandlerThread = new NetServerInputHandler(netServerInput,netServerOutput);

    String[] pkt = new String[4];
    pkt[0] = "HELLO";
    pkt[1] = name;
    pkt[2] = Long.toString(universe.clock());
    pkt[3] = Archis.ARCHIS_VERSION;
    netServerOutput.sendPacket(pkt);
    netServerOutput.flush();
  }

  /**
   * Disconnects from any NetServer
   */
  public synchronized void disconnect()
  {
    if (netServerSocket != null) {
      netServerInputHandlerThread.die = true;
      netServerInputHandlerThread.interrupt();
      netServerInputHandlerThread = null;
      Thread.yield();
      synchronized(netServerOutput) {
        try {
          netServerSocket.close();
        } catch (IOException e) {}
      }
      netServerInput = null;
      netServerOutput = null;
      netServerSocket = null;
    }
  }

  /**
   * Returns the next cell ID for this simulation (starts with 1)
   *
   * @return Next cell ID
   */
  public long nextCellId()
  {
    return ++cellIdCounter;
  }

  /**
   * <p>Halts simulation at end of next tick</p>
   *
   * <p>Use null as a reason to cancel a halt.  Note that starting the
   * simulation clears halt reasons, so if the simulation is stopped this
   * will have no effect.</p>
   *
   * @param reason Halt reason
   */
  public void halt(String reason)
  {
    haltReason = reason;
  }

  /**
   * <p>Notifies simulation of a new frame</p>
   *
   * <p>This should only be called from with in the GUI code.</p>
   *
   * @param frame GUI frame that has opened
   */
  public void newFrameNotify(JFrame frame)
  {
    synchronized(openFrames) {
      openFrames.add(new WeakReference(frame));
      for (Iterator i = openFrames.iterator();i.hasNext();) {
        WeakReference tmp = (WeakReference)i.next();
        if (tmp.get() == null)
          i.remove();
      }
    }
  }

  /**
   * Returns the number of processing threads this simulation is using
   *
   * @return Number of processing threads
   */
  public int nThreads()
  {
    return nthreads;
  }

  /**
   * Gets the name of this simulation
   *
   * @return Name of simulation
   */
  public String getName()
  {
    return name;
  }

  /**
   * Adds a simulation observer to be notified on completion of each simulation tick
   *
   * @param observer Observer to add
   */
  public void addObserver(SimulationObserver observer)
  {
    synchronized(observers) {
      observers.add(new WeakReference(observer));
    }
  }

  /**
   * <p>Removes a simulation observer</p>
   *
   * <p>Note: observers are stored in WeakReference objects and are removed
   * automatically if they are garbage collected.</p>
   *
   * @param observer Observer to remove
   */
  public void removeObserver(SimulationObserver observer)
  {
    synchronized(observers) {
      for(Iterator i=observers.iterator();i.hasNext();) {
        WeakReference ref = (WeakReference)i.next();
        if (ref.get() == null)
          i.remove();
        else if (observer.equals(ref.get()))
          i.remove();
      }
    }
  }

  /**
   * Starts the simulation
   */
  public synchronized void start()
  {
    haltReason = null;
    srthread.run = true;
    srthread.interrupt();
  }

  /**
   * Stops the simulation
   *
   * @param wait Wait to return until current tick has finished?
   */
  public synchronized void stop(boolean wait)
  {
    srthread.run = false;
    if (wait) {
      while (srthread.running) {
        try {
          Thread.sleep(500L);
        } catch (InterruptedException e) {}
      }
    }
  }

  /**
   * Steps forward a single tick
   *
   * @throws IllegalStateException Simulation was already running
   */
  public synchronized void step()
    throws IllegalStateException
  {
    if (srthread.running||srthread.run)
      throw new IllegalStateException("Simulation is already running");
    haltReason = null;
    srthread.step = true;
    srthread.interrupt();
  }

  /**
   * Kills this simulation and any threads or frames associated with it (this must be used!)
   */
  public synchronized void kill()
  {
    srthread.die = true;
    srthread.interrupt();
    srthread = null;
    universe.destroy();
    disconnect();
    synchronized(openFrames) {
      for(Iterator i=openFrames.iterator();i.hasNext();) {
        WeakReference tmp = (WeakReference)i.next();
        JFrame f = (JFrame)tmp.get();
        if (f != null) {
          try {
            f.setVisible(false);
            f.dispose();
          } catch (Throwable t) {}
        }
      }
      openFrames.clear();
    }
  }

  /**
   * Retuerns whether this simulation has been killed (killed simulations are no longer usable)
   *
   * @return Has this simulation been killed with kill()?
   */
  public boolean isKilled()
  {
    return (srthread == null);
  }

  /**
   * Returns whether the simulation is currently running
   *
   * @return Is simulation running?
   */
  public boolean isRunning()
  {
    return srthread.running;
  }

  /**
   * Gets the universe associated with this simulation
   *
   * @return Universe associated with simulation
   */
  public Universe universe()
  {
    return universe;
  }

  /**
   * Sets the value of a simulation statistic
   *
   * @param name Name of statistic (should begin with [module])
   * @param value Value of statistic
   */
  public void setStatistic(String name,int value)
  {
    synchronized(statistics) {
      statistics.put(name,new Integer(value));
    }
  }

  /**
   * Sets the value of a simulation statistic
   *
   * @param name Name of statistic (should begin with [module])
   * @param value Value of statistic
   */
  public void setStatistic(String name,long value)
  {
    synchronized(statistics) {
      statistics.put(name,new Long(value));
    }
  }

  /**
   * Sets the value of a simulation statistic
   *
   * @param name Name of statistic (should begin with [module])
   * @param value Value of statistic
   */
  public void setStatistic(String name,String value)
  {
    synchronized(statistics) {
      statistics.put(name,value);
    }
  }

  /**
   * Sets the value of a simulation statistic
   *
   * @param name Name of statistic (should begin with [module])
   * @param value Value of statistic
   */
  public void setStatistic(String name,float value)
  {
    synchronized(statistics) {
      statistics.put(name,new Float(value));
    }
  }

  /**
   * Sets the value of a simulation statistic
   *
   * @param name Name of statistic (should begin with [module])
   * @param value Value of statistic
   */
  public void setStatistic(String name,double value)
  {
    synchronized(statistics) {
      statistics.put(name,new Double(value));
    }
  }

  /**
   * Sets the value of a simulation statistic
   *
   * @param name Name of statistic (should begin with [module])
   * @param value Value of statistic
   */
  public void setStatistic(String name,boolean value)
  {
    synchronized(statistics) {
      statistics.put(name,(value ? Boolean.TRUE : Boolean.FALSE));
    }
  }

  /**
   * Gets the current statistics for this simulation
   *
   * @return Current statistics in a Map sorted by name
   */
  public SortedMap getStatistics()
  {
    return Collections.unmodifiableSortedMap(statistics);
  }

  /**
   * Puts all statistics into a pre-existing Map
   *
   * @param dest Map to put all statistics into
   */
  public void getStatistics(Map dest)
  {
    dest.putAll(statistics);
  }

  /**
   * <p>Returns the time in ms that the last tick took</p>
   *
   * <p>If this is called while a tick is in progress, it may return an
   * incorrect result.  It may be called from the tick() method of a
   * SimulationObserver while the simulation is running and the result will
   * be correct.</p>
   *
   * @return Time last tick took (ms)
   */
  public long getLastTickTime()
  {
    return srthread.stopTime - srthread.startTime;
  }

  /**
   * Gets the random number source for this simulation
   *
   * @return Random number source
   */
  public RandomSource randomSource()
  {
    return randomSource;
  }

  /**
   * <p>Opens a file to log statistics to</p>
   *
   * <p>If there is already a statistics log file open, it is closed.  The
   * first line in this log file will be the names of each statistic item.</p>
   *
   * @param statisticsLogFile File to log statistics to
   * @throws IOException I/O error opening log file
   */
  public void openStatisticsLogFile(File statisticsLogFile)
    throws IOException
  {
    if (statisticsPrintStream != null) {
      synchronized(statisticsPrintStream) {
        statisticsPrintStream.close();
        statisticsPrintStream = null;
        this.statisticsLogFile = null;
      }
    }
    this.statisticsLogFile = statisticsLogFile;
    statisticsPrintStream = new PrintStream(new FileOutputStream(statisticsLogFile),true);
    statisticsLogHeaderWritten = false;
  }

  /**
   * Closes any currently open statistics log file
   */
  public void closeStatisticsLogFile()
  {
    if (statisticsPrintStream != null) {
      synchronized(statisticsPrintStream) {
        statisticsPrintStream.close();
        statisticsPrintStream = null;
        statisticsLogFile = null;
      }
    }
  }

  /**
   * Returns the current file to which logging is occurring (or null if none)
   *
   * @return Log file or null if none
   */
  public File getStatisticsLogFile()
  {
    return statisticsLogFile;
  }

  /**
   * Gets the command line for this simulation
   *
   * @return Command line interface object
   */
  public ArchisCommandLine commandLine()
  {
    return commandLine;
  }

  /**
   * Gets the short version (just the last part) of a class name
   *
   * @param clazz Class to get name for
   * @return Shortened name
   */
  public String getShortClassName(Class clazz)
  {
    String cn = clazz.getName();
    int tmp = cn.lastIndexOf('.');
    if (tmp <= 0)
      return cn;
    if ((tmp+1) >= cn.length())
      return cn;
    return cn.substring(tmp+1);
  }

  /**
   * Internal method to look up classes in a map based on a long or short name
   *
   * @param classMap Map to search
   * @param name Name to search for
   * @return Class or null if not found
   */
  private Class classNameLookup(Map classMap,String name)
  {
    String dotName = ".".concat(name);
    for(Iterator i=classMap.keySet().iterator();i.hasNext();) {
      Class c = (Class)i.next();
      String cn = c.getName();
      if (cn.equals(name))
        return c;
      else if (cn.endsWith(dotName))
        return c;
    }
    return null;
  }

  /**
   * Gets a Map containing environmental condition classes and their descriptions
   *
   * @return Map containing Class objects as keys and descriptions as values
   */
  public Map getEnvironmentalConditions()
  {
    return Collections.unmodifiableMap(environmentalConditions);
  }

  /**
   * Gets an environmental condition class by short or long class name
   *
   * @param name Short (just part after last dot) or long class name
   * @return Class or null if not found
   */
  public Class getEnvironmentalCondition(String name)
  {
    synchronized(environmentalConditions) {
      return classNameLookup(environmentalConditions,name);
    }
  }

  /**
   * Gets a Map containing reward function classes and their descriptions
   *
   * @return Map containing Class objects as keys and descriptions as values
   */
  public Map getRewardFunctions()
  {
    return Collections.unmodifiableMap(rewardFunctions);
  }

  /**
   * Gets a reward function class by short or long class name
   *
   * @param name Short (just part after last dot) or long class name
   * @return Class or null if not found
   */
  public Class getRewardFunction(String name)
  {
    synchronized(rewardFunctions) {
      return classNameLookup(rewardFunctions,name);
    }
  }

  /**
   * Gets a Map containing probe classes and their descriptions
   *
   * @return Map containing Class objects as keys and descriptions as values
   */
  public Map getProbes()
  {
    return Collections.unmodifiableMap(probes);
  }

  /**
   * Gets a probe class by short or long class name
   *
   * @param name Short (just part after last dot) or long class name
   * @return Class or null if not found
   */
  public Class getProbe(String name)
  {
    synchronized(probes) {
      return classNameLookup(probes,name);
    }
  }

  /**
   * Gets a Map containing catastrophe classes and their descriptions
   *
   * @return Map containing Class objects as keys and descriptions as values
   */
  public Map getCatastrophes()
  {
    return Collections.unmodifiableMap(catastrophes);
  }

  /**
   * Gets a catastrophe class by short or long class name
   *
   * @param name Short (just part after last dot) or long class name
   * @return Class or null if not found
   */
  public Class getCatastrophe(String name)
  {
    synchronized(catastrophes) {
      return classNameLookup(catastrophes,name);
    }
  }
}
