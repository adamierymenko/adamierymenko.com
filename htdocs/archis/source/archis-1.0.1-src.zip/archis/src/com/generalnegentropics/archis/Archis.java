package com.generalnegentropics.archis;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

import java.awt.Image;
import java.io.*;
import java.util.*;
import java.net.*;
import javax.swing.ImageIcon;
import com.generalnegentropics.archis.gui.*;
import com.generalnegentropics.archis.utils.*;
import javax.swing.UIManager;

/**
 * <p>Main class to be invoked to start the application</p>
 *
 * <p>This also contains some fundamental constants.</p>
 *
 * @author Adam Ierymenko
 * @version 3.0
 */

public class Archis
{
  /**
   * Number of I/O channels available to cells
   */
  public static final int CHANNEL_COUNT = 32;

  /**
   * Program version
   */
  public static final String ARCHIS_VERSION = "1.0.1";
  /**
   * Program description
   */
  public static final String ARCHIS_DESCRIPTION = "Archis Version "+ARCHIS_VERSION+" \u00A92001-2003 Adam Ierymenko, All Rights Reserved";

  /**
   * Size of cell state memory in ints
   */
  public static final int CELL_STATE_MEMORY_SIZE = 64;

  /**
   * Icon for GUI
   */
  public static Image ICON;

  /**
   * Main method
   *
   * @param argv Command line arguments
   */
  public static void main(String[] argv)
  {
    if (argv.length <= 0) {
      //
      // Start graphical user interface if no arguments
      //

      // Try to set a nicer look and feel...
      boolean lafset = false;
      try {
        // Windoze look and feel
        Class.forName("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
        UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
        lafset = true;
      } catch (Throwable t) {}
      if (!lafset) {
        // MacOSX look and feel on OSX
        try {
          Class.forName("com.apple.mrj.swing.MacLookAndFeel");
          UIManager.setLookAndFeel("com.apple.mrj.swing.MacLookAndFeel");
          lafset = true;
        } catch (Throwable t) {}
      }
      if (!lafset) {
        // GTK look and feel on Unix boxen
//      try {
//        Class.forName("com.sun.java.swing.plaf.gtk.GTKLookAndFeel");
//        UIManager.setLookAndFeel("com.sun.java.swing.plaf.gtk.GTKLookAndFeel");
//        lafset = true;
//      } catch (Throwable t) {}
      }

      // OS-specific setup stuff
      String osName = System.getProperty("os.name","").toLowerCase();
      if ((osName.indexOf("xp")>0)&&(osName.indexOf("win")>=0)) {
        // Turn off off-screen direct draw acceleration or the colors look like
        // a bad acid trip on Windows XP (may be fixed in latest JVM, not sure)
        System.setProperty("sun.java2d.ddoffscreen","false");
      }

      // Get icon image
      ICON = new ImageIcon(ClassLoader.getSystemClassLoader().getResource("com/generalnegentropics/archis/resources/spiral.gif")).getImage();

      // Create GUI window
      new ArchisWindow().setVisible(true);
    } else if ("-slave".equals(argv[0])) {
      //
      // Start in headless slave mode
      //

      LinkedList simulations = new LinkedList();

      if (argv.length == 1)
        System.out.println("No slave config files specified!");
      else {
        for(int i=1;i<argv.length;i++) {
          try {
            System.out.println("Starting slave from file "+argv[i]);
            FileInputStream in = new FileInputStream(argv[i]);
            Properties sc = new Properties();
            sc.load(in);
            in.close();

            if (sc.getProperty("name") == null) {
              System.out.println("  The 'name' field is required! skipping!");
              continue;
            } else if (sc.getProperty("host") == null) {
              System.out.println("  The 'host' field is required! skipping!");
              continue;
            } else if (sc.getProperty("port") == null) {
              System.out.println("  The 'port' field is required! skipping!");
              continue;
            }

            String defaultRS = Long.toString(System.currentTimeMillis() % (long)Integer.MAX_VALUE);

            RandomSource rs;
            if ("MersenneTwister".equalsIgnoreCase(sc.getProperty("randomSource","")))
              rs = new MersenneTwisterRandomSource(Long.parseLong(sc.getProperty("randomSeed",defaultRS)));
            else if ("java.util.Random".equalsIgnoreCase(sc.getProperty("randomSource","")))
              rs = new JavaBuiltinRandomSource(Long.parseLong(sc.getProperty("randomSeed",defaultRS)));
            else if ("Placebo".equalsIgnoreCase(sc.getProperty("randomSource","")))
              rs = new NonRandomRandomSource(Long.parseLong(sc.getProperty("randomSeed",defaultRS)));
            else {
              System.out.println("  No random source specified; assuming MersenneTwister");
              rs = new MersenneTwisterRandomSource(Long.parseLong(sc.getProperty("randomSeed",defaultRS)));
            }
            System.out.println("  Random Source: "+rs.getClass().getName());
            System.out.println("  Random Seed: "+sc.getProperty("randomSeed",defaultRS));

            Simulation s = new Simulation(Integer.parseInt(sc.getProperty("threads","1")),sc.getProperty("name"),rs);
            System.out.println("  Simulation '"+s.getName()+"' started with "+sc.getProperty("threads","1")+" threads!");
            try {
              s.connect(InetAddress.getByName(sc.getProperty("host")),Integer.parseInt(sc.getProperty("port")));
              System.out.println("  Connected to "+sc.getProperty("host")+":"+sc.getProperty("port"));
            } catch (IOException e) {
              System.out.println("  Sorry... skipping! could not connect to NetServer: "+e.toString());
              continue;
            }
            s.setAllowRemoteCommands(true);
            simulations.add(s);
          } catch (IOException e) {
            System.out.println("Could not open "+argv[i]+": "+e.getMessage());
          } catch (NumberFormatException e) {
            System.out.println("Slave config file "+argv[i]+" contained at least one bad numeric");
            System.out.println("value. (NumberFormatException)");
          } catch (Throwable t) {
            System.out.println("Error starting slave from config file "+argv[i]);
            t.printStackTrace();
          }
        }
      }

      // Quit program when all simulations die
      for(;;) {
        try {
          Thread.sleep(1000L);
        } catch (InterruptedException e) {}
        for(Iterator i=simulations.iterator();i.hasNext();) {
          Simulation s = (Simulation)i.next();
          if (s.isKilled())
            i.remove();
          else if (!s.isConnected()) {
            System.out.println("Simulation '"+s.getName()+"' is no longer connected to NetServer, killing!");
            s.kill();
          }
        }
        if (simulations.size() <= 0) {
          System.out.println("No more simulations!  Goodbye!");
          System.exit(0);
        }
      }
    } else {
      //
      // Print help
      //

      System.out.println("Archis Version "+ARCHIS_VERSION);
      System.out.println("(c) 2001-2003 Adam Ierymenko, All Rights Reserved");
      System.out.println("This program is distributed under the terms of the GNU GPL.");
      System.out.println();
      System.out.println("Start Archis with no arguments to start the interactive graphical");
      System.out.println("user interface.  The following arguments are also available to");
      System.out.println("run Archis in other ways:");
      System.out.println();
      System.out.println("-slave <slave config file> [<slave config file> ...]");
      System.out.println("  <slave config file> - Any number of these can be specified");
      System.out.println();
      System.out.println("Slave config files contain the following options:");
      System.out.println("  name=<slave simulation name, required>");
      System.out.println("  threads=<threads to use for simulation, default=1>");
      System.out.println("  host=<NetServer host, required>");
      System.out.println("  port=<NetServer port, required>");
      System.out.println("  randomSource=<MersenneTwister/java.util.Random/Placebo>");
      System.out.println("  randomSeed=<random seed as 32-bit integer, default=clock-derived>");
      System.out.println();
      System.out.println("The -slave option runs Archis in headless slave mode and connects");
      System.out.println("it to a NetServer.  More than one simulation can be run per VM");
      System.out.println("by using a number greater than 1 as the first option.  When");
      System.out.println("slaves connect, they are configured to accept remote commands by");
      System.out.println("default (this is turned off by default in GUI mode).");
    }
  }
}
