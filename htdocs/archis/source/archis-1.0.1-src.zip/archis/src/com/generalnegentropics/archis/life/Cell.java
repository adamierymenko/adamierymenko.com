package com.generalnegentropics.archis.life;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

import java.util.*;
import com.generalnegentropics.archis.*;
import com.generalnegentropics.archis.utils.*;
import com.generalnegentropics.archis.universe.*;

/**
 * A single cell
 *
 * @author Adam Ierymenko
 * @version 1.0
 */

public class Cell
{
  // Internal ID counter
  private static volatile long idCounter = 0L;

  // Is cell alive?
  private boolean alive;

  // Amount of energy this cell has
  private int energy;

  // Age of cell in heartbeats
  private long age;

  // Number of points earned for reward functions this round and last round
  private int points,lastPoints;

  // Genetic code
  private Genome genome;

  // State memory
  private int[] memory;

  // ID and parentage information
  private long parentId;
  private long generation;
  private long id;

  // Name of simulation of origin
  private String origin;

  // Input for next run
  private IntegerInput[] input;

  // Universe that we belong to
  private Universe output;

  // Cell meta-info (can be used by universe, etc.)
  private HashMap metaInfo;

  // Cell surface protein is any object that extends Number that can serve
  // to identify this cell to other cells or set behaviors in various
  // landscapes.
  private Number cellSurfaceProtein;

  /**
   * Constructs a new cell with the given genetic code and other information
   *
   * @param output Universe to receive cell I/O output
   * @param id Cell ID (use simulation.nextCellId() for this simulation's next cell id)
   * @param origin Simulation name of origin (use simulation.getName())
   * @param parentId ID of parent cell or 0 if this cell is introduced
   * @param generation Generation (0 for first/introduced)
   * @param initialEnergy Initial energy level
   * @param genome Genetic code
   */
  public Cell(Universe output,long id,String origin,long parentId,long generation,int initialEnergy,Genome genome)
  {
    memory = new int[Archis.CELL_STATE_MEMORY_SIZE];
    input = new IntegerInput[Archis.CHANNEL_COUNT];
    metaInfo = new HashMap(16,0.95F);
    cellSurfaceProtein = null;
    this.id = id;
    this.output = output;
    this.genome = genome;
    this.origin = origin;
    this.generation = generation;
    this.parentId = parentId;

    energy = initialEnergy;
    age = 0L;
    alive = true;
    points = 0;
    lastPoints = 0;
  }

  /**
   * Returns a string describing this cell
   *
   * @return String description
   */
  public String toString()
  {
    return "[Cell #"+id+" from "+origin+"]";
  }

  /**
   * <p>Sets the "cell surface protein" object</p>
   *
   * <p>Typically, this is one of the number classes such as Integer. However,
   * if you wish to do something more elaborate then you can just extend Number
   * and add your own special functionality as well. However, the intValue()
   * method and other Number methods should <i>always</i> return something
   * meaningful.</p>
   *
   * <p>This typically represents an object or numeric value that the cell can
   * set somehow and that defines it's interaction with other cells or with
   * some aspect of a landscape. For example, in Landscape2D cells can set
   * integer values that control their adhesion/communication/energy transfer
   * properties with respect to one another.</p>
   *
   * <p>Set this to null to clear this value completely.</p>
   *
   * @param cellSurfaceProtein Cell surface protein object
   */
  public void setCellSurfaceProtein(Number cellSurfaceProtein)
  {
    this.cellSurfaceProtein = cellSurfaceProtein;
  }

  /**
   * Gets the cell surface protein object
   *
   * @return Cell surface protein object or null if none
   */
  public Number getCellSurfaceProtein()
  {
    return cellSurfaceProtein;
  }

  /**
   * Returns the intValue() of the cell surface protein or 0 if there is none
   *
   * @return Int value of cell surface protein or 0 if none
   */
  public int getCellSurfaceProteinIntValue()
  {
    return ((cellSurfaceProtein == null) ? 0 : cellSurfaceProtein.intValue());
  }

  /**
   * Sets the genome for this cell to a new genome
   *
   * @param newGenome New genome for cell
   */
  public void setGenome(Genome newGenome)
  {
    this.genome = newGenome;
  }

  /**
   * Uses the canonicalize() method in genome to obtain a memory-saving copy
   */
  public void canonicalizeGenome()
  {
    genome = genome.canonicalize();
  }

  /**
   * Gets the number of points earned this turn
   *
   * @return Points earned
   */
  public int getPoints()
  {
    return points;
  }

  /**
   * Gets last round's points total
   *
   * @return Last points total
   */
  public int getLastPoints()
  {
    return lastPoints;
  }

  /**
   * Increments points by the given quantity
   *
   * @param qty Quantity of points to increase (do not use negative values)
   */
  public void incPoints(int qty)
  {
    points += qty;
  }

  /**
   * Resets points to zero and set lastPoints to current points total
   */
  public void clearPoints()
  {
    lastPoints = points;
    points = 0;
  }

  /**
   * Increments energy by a given amount
   *
   * @param amount Amount of energy to add
   */
  public void incEnergy(int amount)
  {
    if (alive)
      energy += amount;
  }

  /**
   * Decrements energy by one, returns whether or not cell is still alive
   *
   * @return Is cell still alive?
   */
  public boolean decEnergy()
  {
    if (alive) {
      if (--energy <= 0) {
        kill(false,"Starvation");
        return false;
      }
    } else --energy;
    return true;
  }

  /**
   * Decrements energy by a given amount
   *
   * @param amount Amount to decrement energy by
   * @return Is cell still alive?
   */
  public boolean decEnergy(int amount)
  {
    if (alive) {
      if ((energy -= amount) <= 0) {
        kill(false,"Starvation");
        return false;
      }
    } else energy -= amount;
    return true;
  }

  /**
   * Sets the input source for a channel on the next run
   *
   * @param channel Input channel
   * @param input Input source
   */
  public void setInput(int channel,IntegerInput input)
  {
    if (alive)
      this.input[channel] = input;
  }

  /**
   * Causes this cell's genome to execute once
   *
   * @throws DeathException Death occurred for some reason
   */
  public void heartbeat()
  {
    if (alive) {
      try {
        int gs = genome.size();
        genome.execute(input,output,this,memory,gs * gs);

        // Reset inputs for next round
        if (input != null) {
          for(int i=0;i<input.length;i++)
            input[i] = null;
        }
      } catch (Throwable t) {
        t.printStackTrace();
        kill(false,"Unexpected exception: "+t.toString());
      }

      ++age;
    }
  }

  /**
   * Kill this cell
   *
   * @param zeroEnergy Set energy to zero? true/false
   * @param reason Reason for death
   */
  public void kill(boolean zeroEnergy,String reason)
  {
    if (alive) {
      alive = false;

      // Allow memory and input to be garbage collected on death to save RAM
      memory = null;
      input = null;

      // Zero energy if requested
      if (zeroEnergy)
        energy = 0;

      // Notify universe of death
      output.deathNotify(this,reason);
    }
  }

  /**
   * Returns whether or not cell is alive
   *
   * @return Is cell alive?
   */
  public boolean alive()
  {
    return alive;
  }

  /**
   * Returns the energy of this cell
   *
   * @return Energy (can be negative! cell may be dead!)
   */
  public int energy()
  {
    return energy;
  }

  /**
   * Returns the age of this cell in heartbeats
   *
   * @return Age in heartbeats
   */
  public long age()
  {
    return age;
  }

  /**
   * Returns the genome object associated with this cell
   *
   * @return Cell's genome (not a copy)
   */
  public Genome genome()
  {
    return genome;
  }

  /**
   * Gets this cell's unique ID
   *
   * @return Unique cell ID
   */
  public long id()
  {
    return id;
  }

  /**
   * Gets the ID of this cell's parent
   *
   * @return Parent ID or 0 if synthetic or random
   */
  public long parentId()
  {
    return parentId;
  }

  /**
   * Returns this cell's generation from zero
   *
   * @return Generation or 0 if synthetic or random
   */
  public long generation()
  {
    return generation;
  }

  /**
   * <p>Gets cell state memory</p>
   *
   * <p>Note that the array returned is not a copy, so any modifications will
   * modify the real state memory for the cell.</p>
   *
   * @return Cell state memory
   */
  public int[] stateMemory()
  {
    return memory;
  }

  /**
   * Gets the simulation that this cell originated from
   *
   * @return Simulation name of cell's ultimate origin
   */
  public String origin()
  {
    return origin;
  }

  /**
   * <p>Sets a piece of meta info</p>
   *
   * <p>
   * Meta-info can be used by conditions to store info about cells in an
   * efficient manner without the use of extra maps.  Meta-info persists for
   * the life of the cell object.
   * </p>
   *
   * @param key Key for meta info
   * @param value Value (any object)
   */
  public void setMetaInfo(Object key,Object value)
  {
    synchronized(metaInfo) {
      metaInfo.put(key,value);
    }
  }

  /**
   * Gets a piece of meta info
   *
   * @param key Key for meta info
   * @return Value or null if not found
   */
  public Object getMetaInfo(Object key)
  {
    // We'll be brave and be unsynchronized here for now...
    // Meta info is not structurally modified often
//    synchronized(metaInfo) {
      return metaInfo.get(key);
//    }
  }

  /**
   * Removes a piece of meta info
   *
   * @param key Key to remove
   * @return Value of key or null if key was not set
   */
  public Object removeMetaInfo(Object key)
  {
    synchronized(metaInfo) {
      return metaInfo.remove(key);
    }
  }
}
