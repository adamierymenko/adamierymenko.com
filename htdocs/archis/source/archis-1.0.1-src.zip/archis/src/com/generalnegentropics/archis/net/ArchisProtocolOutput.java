package com.generalnegentropics.archis.net;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

import java.io.*;
import java.util.zip.Deflater;

/**
 * Protocol output handler (this handles compression and buffering too!)
 *
 * @author Adam Ierymenko
 * @version 1.0
 */

public class ArchisProtocolOutput
{
  /**
   * Suggested block size
   */
  public static final int SUGGESTED_BLOCKSIZE = 32768;

  private OutputStream outStream;
  private byte[] buf,compBuf;
  private int bufPtr;
  private Deflater deflater;

  /**
   * <p>Constructs a new protocol output</p>
   *
   * <p>Note that blockSize should be the same on the sending and receiving
   * ends.  Use SUGGESTED_BLOCKSIZE to ensure this.</p>
   *
   * @param outStream Underlying output stream
   * @param blockSize Block size
   */
  public ArchisProtocolOutput(OutputStream outStream,int blockSize)
  {
    this.outStream = outStream;
    buf = new byte[blockSize];
    compBuf = new byte[blockSize+1024];
    bufPtr = 0;
    deflater = new Deflater(Deflater.DEFAULT_COMPRESSION,false);
  }

  /**
   * Compresses and writes a block
   *
   * @throws IOException I/O error writing block
   */
  private void doWrite()
    throws IOException
  {
    deflater.setInput(buf,0,bufPtr);
    deflater.finish();
    int n = deflater.deflate(compBuf,4,compBuf.length-4);
    compBuf[0] = (byte)(n & 0x000000ff);
    compBuf[1] = (byte)((n >> 8) & 0x000000ff);
    compBuf[2] = (byte)((n >> 16) & 0x000000ff);
    compBuf[3] = (byte)((n >> 24) & 0x000000ff);
    outStream.write(compBuf,0,n+4);
    bufPtr = 0;
    deflater.reset();
  }

  /**
   * Writes a word while escaping special characters
   *
   * @param word String to write
   * @throws IOException I/O error
   */
  private void writeWord(String word)
    throws IOException
  {
    int l = word.length();
    for(int i=0;i<l;i++) {
      char c = word.charAt(i);
      if ((c == '\\')||(c == '\r')||(c == '\n')||(c == '~')) {
        buf[bufPtr++] = '\\';
        if (bufPtr >= buf.length)
          doWrite();
      }
      buf[bufPtr++] = (byte)c;
      if (bufPtr >= buf.length)
        doWrite();
    }
  }

  /**
   * Sends a packet consisting of just one word (like "PONG")
   *
   * @param packetType Packet type word
   * @throws IOException I/O error
   */
  public synchronized void sendPacket(String packetType)
    throws IOException
  {
    writeWord(packetType);
    buf[bufPtr++] = '\n';
    if (bufPtr >= buf.length)
      doWrite();
  }

  /**
   * Sends a packet consisting of just two words: a type and a message
   *
   * @param packetType Packet type word
   * @param packetMessage Packet message word
   * @throws IOException I/O error
   */
  public synchronized void sendPacket(String packetType,String packetMessage)
    throws IOException
  {
    writeWord(packetType);
    buf[bufPtr++] = '~';
    if (bufPtr >= buf.length)
      doWrite();
    writeWord(packetMessage);
    buf[bufPtr++] = '\n';
    if (bufPtr >= buf.length)
      doWrite();
  }

  /**
   * Sends a packet consisting of many words (first should be type word)
   *
   * @param packet Packet contents
   * @throws IOException I/O error
   */
  public synchronized void sendPacket(String[] packet)
    throws IOException
  {
    for(int i=0;i<packet.length;i++) {
      if (i > 0) {
        buf[bufPtr++] = '~';
        if (bufPtr >= buf.length)
          doWrite();
      }
      writeWord(packet[i]);
    }
    buf[bufPtr++] = '\n';
    if (bufPtr >= buf.length)
      doWrite();
  }

  /**
   * Writes any pending bytes and flushes the output stream
   *
   * @throws IOException I/O error
   */
  public synchronized void flush()
    throws IOException
  {
    if (bufPtr > 0)
      doWrite();
    outStream.flush();
  }

  /**
   * Flushes and closes the underlying output stream
   *
   * @throws IOException I/O error
   */
  public synchronized void close()
    throws IOException
  {
    if (bufPtr > 0)
      doWrite();
    outStream.close();
  }
}
