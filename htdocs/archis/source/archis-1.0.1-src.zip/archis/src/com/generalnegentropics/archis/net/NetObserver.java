package com.generalnegentropics.archis.net;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

import java.net.InetAddress;

/**
 * Interface for an observer of basic net events on a NetServer
 *
 * @author Adam Ierymenko
 * @version 1.0
 */

public interface NetObserver
{
  /**
   * Notifies of a client connection
   *
   * @param fromAddress InetAddress that client is connecting from
   * @param fromPort Port that client is connecting from
   */
  void clientConnect(InetAddress fromAddress,int fromPort);

  /**
   * Notifies of a client login
   *
   * @param fromAddress InetAddress that client is connecting from
   * @param fromPort Port that client is connecting from
   * @param simulationName Name of simulation (also serves to identify client)
   * @param clock Current clock at client end
   * @param remoteVersion Client software version
   */
  void clientLogin(InetAddress fromAddress,int fromPort,String simulationName,long clock,String remoteVersion);

  /**
   * Notifies of a client disconnect
   *
   * @param fromAddress InetAddress that client is connecting from
   * @param fromPort Port that client is connecting from
   * @param simulationName Simulation name or null if it never logged in
   */
  void clientDisconnect(InetAddress fromAddress,int fromPort,String simulationName);

  /**
   * A client has completed a tick
   *
   * @param simulationName Name of simulation
   * @param clock Current clock at client end
   */
  void clientTickCompleted(String simulationName,long clock);
}
