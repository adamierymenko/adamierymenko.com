package com.generalnegentropics.archis.utils;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

import java.util.*;
import java.io.*;

/**
 * <p>Implements a logical expression that can be used for boolean logical evaluation</p>
 *
 * <p>This class implements a logical expression of the following form:</p>
 *
 * <p>var1&lt;operator&gt;var2[&lt;& or |&gt;var1&lt;operator&gt;var2]...</p>
 *
 * <p>Operators are:</p>
 * <p>
 * <pre>
 *   = (or ==) - Equality
 *  !=         - Inequality
 *   >         - Greater than
 *   <         - Less than
 *  >=         - Greater than or equal to
 *  <=         - Less than or equal to
 *   ^         - Contains string
 *  !^         - Does not contain string
 * </pre>
 * </p>
 *
 * <p>Parentheses can be used to enclose expressions, groups of expressions, or
 * values in expressions.  Brackets can also be used interchangeably with
 * parentheses.  The \ character can be used to escape anything.</p>
 *
 * <p>Expressions are evaluated linearly.</p>
 *
 * <p>Examples:<br>
 * &nbsp;&nbsp;somevariable==1<br>
 * &nbsp;&nbsp;(somevariable==1)||(someother&gt;=2)<br>
 * &nbsp;&nbsp;somevariable==()                   (Is somevariable empty/nonexistant?)<br>
 * &nbsp;&nbsp;(somevariable)==(1)                (Same as the first one)<br></p>
 *
 * <p>This implementation is immutable and fully threadsafe, so evaluate can be
 * called from multiple threads simultaneously.  Behavior is very similar to
 * MathExpression.</p>
 *
 * @author Adam Ierymenko
 * @version 1.0
 */

public class LogicalExpression implements Serializable
{
  private String stringExpression;
  private String[] variableNames;
  private LinkedList compiledExpression;
  private int myHashCode;

  //
  // Serializability functions
  //
  private void writeObject(java.io.ObjectOutputStream out)
    throws IOException
  {
    char[] tmp = stringExpression.toCharArray();
    for(int i=0;i<tmp.length;i++)
      out.writeChar(tmp[i]);
    out.writeChar((char)0);
  }
  private void readObject(java.io.ObjectInputStream in)
    throws IOException,ClassNotFoundException
  {
    StringBuffer tmp = new StringBuffer(128);
    char x;
    while ((x = in.readChar()) != (char)0)
      tmp.append(x);
    precompile(tmp.toString());
  }

  /**
   * Constructs a new LogicalExpression
   *
   * @param expression Logical expression
   */
  public LogicalExpression(String expression)
  {
    precompile(expression);
  }

  //
  // Used by the precompiler
  //
  private Object getAppropriateObject(String str,HashSet variableNameList)
  {
    if (str == null) {
      variableNameList.add("");
      return "";
    }
    if (isNumber(str)) {
      try {
        return new Double(str);
      } catch (NumberFormatException e) {
        return new Double(0.0);
      }
    } else {
      variableNameList.add(str);
      return str;
    }
  }

  //
  // Internal function to precompile an expression
  //
  private void precompile(String expression)
  {
    char c,lastChar = (char)0;
    StringBuffer currentVar = new StringBuffer(64);
    LinkedList currentExpression = new LinkedList();
    Stack lastExpression = new Stack();
    HashSet variableNameList = new HashSet(32,0.75F);
    Object tmp,tmp2;
    myHashCode = 0xdeadbeef;
    for(int i=0,l=expression.length();i<l;i++) {
      c = expression.charAt(i);
      if (c == (char)0)
        continue;
      else if (lastChar == '\\') {
        myHashCode *= (int)c;
        currentVar.append(c);
        lastChar = 'x';
      } else {
        switch(c) {
          case '\r':
          case '\n':
          case '\\':
          case ' ':
            // Ignore garbage and escape character
            break;
          case '&':
          case '|':
            // AND and OR
            if (c != lastChar) {
              myHashCode += 0x00000800;
              myHashCode += (int)c;
              if (currentVar.length() > 0) {
                currentExpression.add(getAppropriateObject(currentVar.toString(),variableNameList));
                currentVar.delete(0,currentVar.length());
              }
              currentExpression.addLast(new Character(c));
            }
            break;
          case '!':
            // Not (modifier to certain comparators) is handled elsewhere
            break;
          case '=':
            // Equals (or not equals if ! precedes it)
            if (currentVar.length() > 0) {
              currentExpression.add(getAppropriateObject(currentVar.toString(),variableNameList));
              currentVar.delete(0,currentVar.length());
            }
            if (lastChar == '>') {
              myHashCode += 0x08000000;
              currentExpression.addLast(new Character('G'));
            } else if (lastChar == '<') {
              myHashCode += 0x00800000;
              currentExpression.addLast(new Character('L'));
            } else if (lastChar == '!') {
              myHashCode += 0x00080000;
              currentExpression.addLast(new Character('N'));
            } else if (lastChar != '=') {
              myHashCode += 0x00008000;
              currentExpression.addLast(new Character('='));
            }
            break;
          case '>':
          case '<':
            // These are handled elsewhere due to = being a possible postfix
            break;
          case '^':
            myHashCode += 0x80000000;
            if (currentVar.length() > 0) {
              currentExpression.add(getAppropriateObject(currentVar.toString(),variableNameList));
              currentVar.delete(0,currentVar.length());
            }
            if (lastChar == '!')
              currentExpression.addLast(new Character('D'));
            else currentExpression.addLast(new Character('^'));
            break;
          case '(':
          case '[':
            if ((lastChar == '<')||(lastChar == '>')||(lastChar == '!')) {
              myHashCode ^= (int)lastChar;
              if (currentVar.length() > 0) {
                currentExpression.add(getAppropriateObject(currentVar.toString(),variableNameList));
                currentVar.delete(0,currentVar.length());
              }
              currentExpression.addLast(new Character(lastChar));
            }
            lastExpression.push(currentExpression);
            currentExpression = new LinkedList();
            break;
          case ')':
          case ']':
            if (currentVar.length() > 0) {
              currentExpression.add(getAppropriateObject(currentVar.toString(),variableNameList));
              currentVar.delete(0,currentVar.length());
            }
            tmp = lastExpression.isEmpty() ? null : lastExpression.pop();
            if (tmp != null) {
              if (currentExpression.size() > 1)
                tmp2 = currentExpression;
              else if (currentExpression.size() == 0)
                tmp2 = "";
              else tmp2 = currentExpression.getFirst();
              if (tmp2 == null)
                tmp2 = "";
              myHashCode ^= tmp2.hashCode();
              currentExpression = (LinkedList)tmp;
              currentExpression.addLast(tmp2);
            }
            break;
          default:
            if ((lastChar == '<')||(lastChar == '>')||(lastChar == '!')) {
              myHashCode ^= (int)lastChar;
              if (currentVar.length() > 0) {
                currentExpression.add(getAppropriateObject(currentVar.toString(),variableNameList));
                currentVar.delete(0,currentVar.length());
              }
              currentExpression.addLast(new Character(lastChar));
            }
            myHashCode *= (int)c;
            currentVar.append(c);
            break;
        }
        lastChar = c;
      }
    }
    if (currentVar.length() > 0) {
      currentExpression.add(getAppropriateObject(currentVar.toString(),variableNameList));
      currentVar.delete(0,currentVar.length());
    }

    compiledExpression = currentExpression;
    variableNames = new String[variableNameList.size()];
    Iterator vl = variableNameList.iterator();
    int i=0;
    while (vl.hasNext())
      variableNames[i++] = (String)vl.next();
    Arrays.sort(variableNames);
    stringExpression = reformString(compiledExpression);
  }

  //
  // This is our own isNumber function that also counts E and - as being
  // possible parts of a number.
  //
  private boolean isNumber(String s)
  {
    // Otherwise look for non-numeric characters in which numeric characters
    // are any number, + and - (signs), e (exponent), and . (decimal).
    boolean hasNumber = false;
    for(int i=0,l=s.length();i<l;i++) {
      switch(s.charAt(i)) {
        case '0':
        case '1':
        case '2':
        case '3':
        case '4':
        case '5':
        case '6':
        case '7':
        case '8':
        case '9':
        case '.':
          hasNumber = true;
          break;
        case '-':
        case '+':
        case 'e':
        case 'E':
          // Scientific notation-- it only returns true in this case if it also
          // has a number in it.
          break;
        default:
          return false;
      }
    }
    return hasNumber;
  }

  //
  // Trims trailing zeros in decimal numbers
  //
  private String trimDecimal(String s)
  {
    // Return zero for nulls
    if (s == null)
      return "0";

    // Don't do anything to non-decimal numbers
    if (s.indexOf('.') < 0)
      return s;

    // Find last occurrence of non-zero and non-decimal-point
    int i;
    char c;
    for(i=s.length()-1;i>=0;i--) {
      c = s.charAt(i);
      if ((c != '.')&&(c != '0'))
        break;
      else if (c == '.') {
        --i;
        break;
      }
    }

    // This shouldn't happen unless it's like 0.000000 or something
    if (i < 0)
      return "0";

    return s.substring(0,i+1);
  }

  //
  // This is a recursive function used above to reformulate a reduced
  // version of the original string.  The string generated by this is the
  // version returned by toString() and used for serialization.
  //
  private String reformString(LinkedList v)
  {
    StringBuffer r = new StringBuffer(v.size() * 32);
    Object tmp;
    String tmp2;
    Iterator i = v.iterator();
    while (i.hasNext()) {
      tmp = i.next();
      if (tmp instanceof LinkedList) {
        r.append('(');
        r.append(reformString((LinkedList)tmp));
        r.append(')');
      } else if (tmp instanceof Character) {
        char c = ((Character)tmp).charValue();
        switch(c) {
          case 'D':
            r.append("!^");
            break;
          case 'G':
            r.append(">=");
            break;
          case 'L':
            r.append("<=");
            break;
          case 'N':
            r.append("!=");
            break;
          default:
            r.append(c);
        }
      } else {
        tmp2 = tmp.toString();
        if (isNumber(tmp2))
          r.append(trimDecimal(tmp2));
        else {
          if (tmp2.length() == 0)
            r.append("()");
          else {
            for(int i2=0,l=tmp2.length();i2<l;i2++) {
              char c = tmp2.charAt(i2);
              switch(c) {
                case '\\':
                case ' ':
                case '\r':
                case '\n':
                case '=':
                case '^':
                case '<':
                case '>':
                case '(':
                case ')':
                case '[':
                case ']':
                case '!':
                  r.append('\\');
                default:
                  r.append(c);
              }
            }
          }
        }
      }
    }
    return r.toString();
  }

  //
  // Standard hashCode, toString and equals functions
  //
  public int hashCode()
  {
    return myHashCode;
  }
  public String toString()
  {
    return stringExpression;
  }
  public boolean equals(Object o)
  {
    try {
      return (((LogicalExpression)o).stringExpression).equals(stringExpression);
    } catch (Throwable t) {}
    return false;
  }

  //
  // This is the private function that actually does evaluation.  It calls
  // itself to recurse into parentheses in the expression.
  //
  private boolean _evaluate(LinkedList expr,Map variables,boolean caseSensitiveStringComparisons)
    throws LogicalExpressionException
  {
    boolean result = false;
    char lastLogicalOp = '|';
    boolean not = false;
    char lastComparisonOp = (char)0;
    Object lastValue = null;
    Object tmp;
    String tmp2;
    char c;

    Iterator ei = expr.iterator();
    while (ei.hasNext()) {
      tmp = ei.next();
      if (tmp == null)
        tmp = "";
      if (tmp instanceof LinkedList) {
        // If the current position of the iterator is on another linked list,
        // we recurse into it and then modify the result variable according
        // to the last logical op.
        if (lastComparisonOp != (char)0)
          throw new LogicalExpressionException("Subexpression after comparison operation");
        else if (lastValue != null)
          throw new LogicalExpressionException("Subexpression before conclusion of preceding comparison");
        else {
          if (lastLogicalOp == '|')
            result |= (not ? !_evaluate((LinkedList)tmp,variables,caseSensitiveStringComparisons) : _evaluate((LinkedList)tmp,variables,caseSensitiveStringComparisons));
          else if (lastLogicalOp == '&')
            result &= (not ? !_evaluate((LinkedList)tmp,variables,caseSensitiveStringComparisons) : _evaluate((LinkedList)tmp,variables,caseSensitiveStringComparisons));
          not = false;
        }
      } else if (tmp instanceof Character) {
        c = ((Character)tmp).charValue();
        switch(c) {
          case '&':
            // AND
            if (lastComparisonOp != (char)0)
              throw new LogicalExpressionException("Logical operation (AND) following comparison operation");
            else if (lastValue != null)
              throw new LogicalExpressionException("Logical operation (AND) before conclusion of preceding comparison");
            else lastLogicalOp = '&';
            break;
          case '|':
            // OR
            if (lastComparisonOp != (char)0)
              throw new LogicalExpressionException("Logical operation (OR) following comparison operation");
            else if (lastValue != null)
              throw new LogicalExpressionException("Logical operation (OR) before conclusion of preceding comparison");
            else lastLogicalOp = '|';
            break;
          case '=':
          case 'N':
          case '^':
          case 'D':
          case 'G':
          case 'L':
          case '>':
          case '<':
            // Logical comparison operators
            if (lastComparisonOp != (char)0)
              throw new LogicalExpressionException("Two comparison operations in a row");
            else if (lastValue == null)
              throw new LogicalExpressionException("Comparison operation before first value in comparison or illegal chained comparison");
            else lastComparisonOp = c;
            break;
          case '!':
            // Check that structure is valid (this is also checked elsewhere
            // for the ! operator.. it can only occur directly before a
            // parenthetical subexpression).
            if (lastComparisonOp != (char)0)
              throw new LogicalExpressionException("NOT can only occur before subexpressions");
            else not = true;
            break;
        }
      } else {
        // ! is illegal directly before a comparison or after an operator
        // (stuff like != and !^ is handled in precompilation and replaced
        // with special letter operation codes)
        if (not)
          throw new LogicalExpressionException("NOT can only occur before subexpressions");

        // If we're beginning a comparison then we set the first operand of the
        // comparison (lastValue).  Otherwise go ahead and do the comparison
        // using the comparison op (lastComparisonOp) and both values.
        if (lastComparisonOp == (char)0)
          lastValue = tmp;
        else {
          // This shouldn't happen
          if (lastValue == null)
            lastValue = "";

          // Lookup real value of string variable names-- if they are to be
          // compared case-insensitively then we turn the result to lower case.
          if (caseSensitiveStringComparisons) {
            if (tmp instanceof String) {
              tmp2 = (String)tmp;
              tmp = variables.get(tmp2);
              if (tmp == null)
                tmp = tmp2;
              else {
                tmp2 = tmp.toString();
                if (isNumber(tmp2)) {
                  try {
                    tmp = new Double(tmp2);
                  } catch (Throwable t) {
                    tmp = new Double(0.0);
                  }
                } else tmp = tmp2;
              }
            }
            if (lastValue instanceof String) {
              tmp2 = (String)lastValue;
              lastValue = variables.get(tmp2);
              if (lastValue == null)
                lastValue = tmp2;
              else {
                tmp2 = lastValue.toString();
                if (isNumber(tmp2)) {
                  try {
                    lastValue = new Double(tmp2);
                  } catch (Throwable t) {
                    lastValue = new Double(0.0);
                  }
                } else lastValue = tmp2;
              }
            }
          } else {
            if (tmp instanceof String) {
              tmp2 = (String)tmp;
              tmp = variables.get(tmp2);
              if (tmp == null)
                tmp = tmp2.toLowerCase();
              else {
                tmp2 = tmp.toString();
                if (isNumber(tmp2)) {
                  try {
                    tmp = new Double(tmp2);
                  } catch (Throwable t) {
                    tmp = new Double(0.0);
                  }
                } else tmp = tmp2.toLowerCase();
              }
            }
            if (lastValue instanceof String) {
              tmp2 = (String)lastValue;
              lastValue = variables.get(tmp2);
              if (lastValue == null)
                lastValue = tmp2.toLowerCase();
              else {
                tmp2 = lastValue.toString();
                if (isNumber(tmp2)) {
                  try {
                    lastValue = new Double(tmp2);
                  } catch (Throwable t) {
                    lastValue = new Double(0.0);
                  }
                } else lastValue = tmp2.toLowerCase();
              }
            }
          }

          // This is where the actual comparisons are done and then the result
          // is modified according to the last logical op given.  We start the
          // process with an OR since this is functionally equivalent to using
          // a "result = ..." for the first loop.  (This is why lastLogicalOp
          // is initialized to '|' above.)
          switch(lastComparisonOp) {
            case '=':
              // Equals
              if (lastLogicalOp == '|')
                result |= lastValue.equals(tmp);
              else if (lastLogicalOp == '&')
                result &= lastValue.equals(tmp);
              break;
            case 'N':
              // Not equals
              if (lastLogicalOp == '|')
                result |= !lastValue.equals(tmp);
              else if (lastLogicalOp == '&')
                result &= !lastValue.equals(tmp);
              break;
            case '^':
              // Contains string
              if (lastLogicalOp == '|')
                result |= (lastValue.toString().indexOf(tmp.toString()) >= 0);
              else if (lastLogicalOp == '&')
                result &= (lastValue.toString().indexOf(tmp.toString()) >= 0);
              break;
            case 'D':
              // Doesn't contain string
              if (lastLogicalOp == '|')
                result |= (lastValue.toString().indexOf(tmp.toString()) < 0);
              else if (lastLogicalOp == '&')
                result &= (lastValue.toString().indexOf(tmp.toString()) < 0);
              break;
            case 'G':
              // Greater than or equal to
              if (lastLogicalOp == '|') {
                try {
                  result |= (((Comparable)lastValue).compareTo(tmp) >= 0);
                } catch (Throwable t) {
                  result |= false;
                }
              } else if (lastLogicalOp == '&') {
                try {
                  result &= (((Comparable)lastValue).compareTo(tmp) >= 0);
                } catch (Throwable t) {
                  result &= false;
                }
              }
              break;
            case 'L':
              // Less than or equal to
              if (lastLogicalOp == '|') {
                try {
                  result |= (((Comparable)lastValue).compareTo(tmp) <= 0);
                } catch (Throwable t) {
                  result |= false;
                }
              } else if (lastLogicalOp == '&') {
                try {
                  result &= (((Comparable)lastValue).compareTo(tmp) <= 0);
                } catch (Throwable t) {
                  result &= false;
                }
              }
              break;
            case '>':
              // Greater than
              if (lastLogicalOp == '|') {
                try {
                  result |= (((Comparable)lastValue).compareTo(tmp) > 0);
                } catch (Throwable t) {
                  result |= false;
                }
              } else if (lastLogicalOp == '&') {
                try {
                  result &= (((Comparable)lastValue).compareTo(tmp) > 0);
                } catch (Throwable t) {
                  result &= false;
                }
              }
              break;
            case '<':
              // Less than
              if (lastLogicalOp == '|') {
                try {
                  result |= (((Comparable)lastValue).compareTo(tmp) < 0);
                } catch (Throwable t) {
                  result |= false;
                }
              } else if (lastLogicalOp == '&') {
                try {
                  result &= (((Comparable)lastValue).compareTo(tmp) < 0);
                } catch (Throwable t) {
                  result &= false;
                }
              }
              break;
          }

          // Reset comparison state variables
          lastComparisonOp = (char)0;
          lastValue = null;
        }
      }
    }

    // Check for unterminated expressions
    if ((lastValue != null)||(lastComparisonOp != (char)0))
      throw new LogicalExpressionException("Unexpected end of expression");

    return result;
  }

  /**
   * Evaluates this logical expression
   *
   * @param variables Variables to use in evaluation
   * @param caseSensitiveStringComparisons Should string comparisons be case sensitive?
   * @throws LogicalExpressionException Error evaluating expression
   * @return Boolean result of expression
   */
  public boolean evaluate(Map variables,boolean caseSensitiveStringComparisons)
    throws LogicalExpressionException
  {
    return _evaluate(compiledExpression,variables,caseSensitiveStringComparisons);
  }

  //
  // Test and benchmark code
  //
  /*public static void main(String[] argv)
  {
    try {
      HashMap variables = new HashMap();
      String tp = "(1>0|1==0)&&(2>=1)";
      LogicalExpression test = new LogicalExpression(tp);
      System.out.println(test.compiledExpression.toString());
      System.out.println(test.hashCode());
      System.out.println(test.toString());
      System.out.println(test.evaluate(variables,false));
      LogicalExpression test2 = new LogicalExpression(test.toString());
      System.out.println(test2.compiledExpression.toString());
      System.out.println(test2.hashCode());
      System.out.println(test2.toString());
      System.out.println(test2.evaluate(variables,false));
      System.out.println("-----------------------------");
      System.out.println("Evaluation Benchmark...");
      long cnt = 100000L;
      long t = System.currentTimeMillis();
      for(long i=0L;i<cnt;i++)
        test.evaluate(variables,false);
      long t2 = System.currentTimeMillis();
      System.out.println("Took "+(t2-t)+"ms to do "+cnt+" evaluations: "+((double)cnt/((double)(t2-t)/(double)1000))+" evaluations per second");
      System.out.println("Compilation benchmark \""+tp+"\"...");
      cnt = 100000L;
      t = System.currentTimeMillis();
      for(long i=0L;i<cnt;i++)
        test.precompile(tp);
      t2 = System.currentTimeMillis();
      System.out.println("Took "+(t2-t)+"ms to do "+cnt+" compilations: "+((double)cnt/((double)(t2-t)/(double)1000))+" compilations per second");
      System.out.println("-----------------------------");
      LineNumberReader in = new LineNumberReader(new InputStreamReader(System.in));
      for(;;) {
        try {
          System.out.print(": ");
          System.out.flush();
          String tmp = in.readLine();
          LogicalExpression tmp2 = new LogicalExpression(tmp.trim());
          System.out.println("Compiled: "+tmp2.compiledExpression.toString());
          System.out.println("Result: "+tmp2.evaluate(variables,false));
        } catch (Throwable t3) {
          t3.printStackTrace();
          System.out.println();
        }
      }
    } catch (Throwable t) {
      t.printStackTrace();
    }
  } */
}
