package com.generalnegentropics.archis.universe;

//
// Archis Cellular Artificial Life Simulator
// Copyright (C) 2001-2003  Adam Ierymenko
//
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

import com.generalnegentropics.archis.life.*;

/**
 * An interface for classes capable of processing I/O from lifeforms.
 *
 * @author unascribed
 * @version 1.0
 */

public interface IOHandler
{
  /**
   * Gets a description for a channel this I/O handler is designed to handle or null if none
   *
   * @param channel Channel to get description for
   * @return Description of channel
   */
  String getChannelDescription(int channel);

  /**
   * Called to evaluate output from a cell with regard to this environmental condition
   *
   * @param l Cell that produced output
   * @param channel Channel of output
   * @param value Value produced
   */
  void evaluateOutput(Cell l,int channel,int value);
}
