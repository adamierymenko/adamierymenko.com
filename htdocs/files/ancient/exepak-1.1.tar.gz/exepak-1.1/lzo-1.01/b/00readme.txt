Simple make drivers for DOS, Windows, OS/2 and other systems
============================================================

This directory contains a bunch of simple make drivers - I've tried
to make them as foolproof as possible.

To build LZO for your system type `b\OS\COMPILER' in the base directory,
e.g. `b\dos32\wc105' will build the 32-bit DOS Watcom C v10.5 version.

After building do a basic test by running `lzo_test -mlzo COPYING'.
util\check.sh is an example of a more thoroughly test driver.

Please send me your additional/improved versions.


Overview:
---------

b\dos16\bc40.bat        Borland C 4.00
b\dos16\mc70.bat        Microsoft C 7.0
b\dos16\wc105.bat       Watcom C 10.5

b\dos32\dj1.bat         djgpp v1 + gcc 2.6.3                  (1)
b\dos32\dj2.bat         djgpp v2 + gcc 2.7.2.1                (1)
b\dos32\dj2_pgcc.bat    djgpp v2 + Pentium gcc 970725         (1)
b\dos32\emx.bat         emx + gcc 2.7.2                       (1)
b\dos32\wc105.bat       Watcom C 10.5                         (1)

b\os2\emx_aout.cmd      emx A.OUT + gcc 2.7.2                 (1) (2)
b\os2\wc105.cmd         Watcom C 10.5                         (1) (2)

b\tos16\purec.prj       Purec C Sep 20 1991

b\win16\wc105.bat       Watcom C 10.5
b\win16\wc105dll.bat    Watcom C 10.5 DLL

b\win32\cdk.bat         Cygnus Win32 + gcc
b\win32\mc100.bat       Microsoft C 10.0      Visual C 4.0
b\win32\mc100dll.bat    Microsoft C 10.0 DLL
b\win32\wc105.bat       Watcom C 10.5                         (1)
b\win32\wc105dll.bat    Watcom C 10.5 DLL


Notes:
  (1) includes support for i386 assembler versions
  (2) not tested as of version 1.01



Makefiles for DOS, Windows, OS/2 and other systems
==================================================

I've also added "real" Makefiles for many platforms.
You need some freely available tools like GNU `make' and GNU `rm'.

To use them type `make -f b\OS\COMPILER.mak' in the base directory,
e.g. `gnumake -f b\dos32\wc105.mak'.

The Makefiles are equivalent to the build scripts - so don't worry
if you don't have the required utilities.


Overview:
---------
b\dos16\mc70.mak
b\dos16\wc105.mak
b\dos32\dj2.mak
b\dos32\dj2_pgcc.mak
b\dos32\wc105.mak
b\os2\wc105.mak
b\win16\wc105.mak
b\win32\mc100.mak
b\win32\wc105.mak


Tools needed under DOS / Windows 3.1 / Windows 95:
-------------------------------------------------
GNU make        ftp://ftp.simtel.net/pub/simtelnet/gnu/djgpp/v2gnu/mak375b.zip
GNU fileutils   ftp://ftp.simtel.net/pub/simtelnet/gnu/djgpp/v2gnu/fil316b.zip

Tools needed under Windows NT:
------------------------------
GNU make        ftp://ftp.cygnus.com
GNU fileutils   ftp://ftp.cygnus.com

Tools needed under OS2:
-----------------------
GNU make        ftp://hobbes.nmsu.edu/pub/os2/
GNU fileutils   ftp://hobbes.nmsu.edu/pub/os2/


