NOTE:
=====

All build scripts, executables and DLLs should work
both under Windows NT and Windows 95 and probably also
under Windows 3.1 + Win32s.

For best performance I recommend using Watcom C.

