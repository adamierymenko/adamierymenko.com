#define COMPRESS_ID		4

#define DDBITS			1
#define CLEVEL			2
#include "compr1b.h"

