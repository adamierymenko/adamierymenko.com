#define COMPRESS_ID		8

#define DDBITS			2
#define CLEVEL			8
#include "compr1c.h"

