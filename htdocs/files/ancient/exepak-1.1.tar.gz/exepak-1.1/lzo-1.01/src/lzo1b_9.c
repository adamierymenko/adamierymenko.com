#define COMPRESS_ID		9

#define DDBITS			2
#define CLEVEL			9
#include "compr1b.h"

