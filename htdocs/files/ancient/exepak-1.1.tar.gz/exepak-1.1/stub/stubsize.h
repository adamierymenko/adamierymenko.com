/* You must define these to the size of the exepak_stub binary and then
 * recompile or EXEPAK self-extracting binaries will NOT WORK */
#define EXEPAK_STUBSIZE 6508






